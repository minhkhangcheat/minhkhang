#import "Manager/Backup.h"

@implementation Backup

+ (void)createBackup { // Chuyển thành class method
    NSString *documentDir = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
    NSString *backupPath = [documentDir stringByAppendingPathComponent:@"Resources.backup"];
    NSFileManager *fileManager = [NSFileManager defaultManager];

    NSError *backupError;
    if ([fileManager fileExistsAtPath:backupPath]) {
        // Tệp backup đã tồn tại, không cần tạo mới
        return;
    }

    if ([fileManager fileExistsAtPath:[documentDir stringByAppendingPathComponent:@"Resources"]]) {
        // Thư mục gốc tồn tại, tiến hành tạo backup
        if (![fileManager copyItemAtPath:[documentDir stringByAppendingPathComponent:@"Resources"]
                                  toPath:backupPath
                                   error:&backupError]) {
            // Xử lý lỗi khi không thể tạo backup
            NSLog(@"Error creating backup: %@", backupError.localizedDescription);
        } else {
            // Xử lý khi tạo backup thành công
            NSLog(@"Backup created successfully.");
        }
    } else {
        // Thư mục gốc không tồn tại, không thể tạo backup
        NSLog(@"Error: Resources directory not found.");
    }
}


+ (void)deleteBackup {
    NSString *documentDir = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
    NSString *backupPath = [documentDir stringByAppendingPathComponent:@"Resources.backup"];
    NSString *dataPath = [documentDir stringByAppendingPathComponent:@"/"];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    UIAlertController *alertCtrl;

    if ([fileManager fileExistsAtPath:backupPath]) {
        NSError *deleteError;
        if ([fileManager removeItemAtPath:[dataPath stringByAppendingPathComponent:@"/Resources"] error:&deleteError]) {
            NSError *renameError;
            if ([fileManager moveItemAtPath:backupPath
                                     toPath:[dataPath stringByAppendingPathComponent:@"/Resources"]
                                      error:&renameError]) {


               /* alertCtrl = [UIAlertController alertControllerWithTitle:@"ShinAOV"
                                                                 message:@"Khôi phục thành công!"
                                                          preferredStyle:UIAlertControllerStyleAlert];
                UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK"
                                                                   style:UIAlertActionStyleDefault
                                                                 handler:^(UIAlertAction * _Nonnull action) {
                    
                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)),
                                   dispatch_get_main_queue(), ^{
                       // exit(0);
                    });
                }];
                [alertCtrl addAction:okAction];
                */
                [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:alertCtrl animated:YES completion:nil];

            } else {
               // [self showErrorAlert:@"Lỗi Remove Skin 1/3"];
            }
        } else {
           // [self showErrorAlert:@"Lỗi Remove Skin 2/3"];
        }
    } else {
       // [self showErrorAlert:@"Lỗi Remove Skin 3/3"];
    }
}

// Hàm tiện ích hiện alert lỗi
+ (void)showErrorAlert:(NSString *)message {
    UIAlertController *alertCtrl = [UIAlertController alertControllerWithTitle:@"Error"
                                                                        message:message
                                                                 preferredStyle:UIAlertControllerStyleAlert];
    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"Đóng" style:UIAlertActionStyleDefault handler:nil]];
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:alertCtrl animated:YES completion:nil];
}



@end