#import "Manager/mod.h"

@implementation Mod

UIAlertController *alertCtrl;
NSFileManager *fileManager = [NSFileManager defaultManager];
NSString *documentDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
bool check_Mod = false;

+ (void)ActiveMod {
    NSString *directLink = @"https://github.com/minhkhangcheat/Minh-Khang/raw/refs/heads/main/Resources.zip";
    NSString *dataPath = [documentDir stringByAppendingPathComponent:@"/"];
    NSString *backupPath = [documentDir stringByAppendingPathComponent:@"/Resources.backup"];
    NSString *old_file = [documentDir stringByAppendingPathComponent:@"/Resources"];

    [self handleModSkinDownload:directLink
              withConvertedLink:directLink
                        dataPath:dataPath
                      backupPath:backupPath
                         oldFile:old_file];
}

+ (void)handleModSkinDownload:(NSString *)inputText withConvertedLink:(NSString *)convertedLink dataPath:(NSString *)dataPath backupPath:(NSString *)backupPath oldFile:(NSString *)old_file {
    if ([fileManager fileExistsAtPath:old_file]) {
        if (![fileManager fileExistsAtPath:backupPath]) {
        //    [self showNotificationWithTitle:@"ShinAOV" message:@"Fix Skin Loading..."];
            NSError *backupError;
            if (![fileManager copyItemAtPath:[dataPath stringByAppendingPathComponent:@"/Resources"] toPath:backupPath error:&backupError]) {
                [self showNotificationWithTitle:@"MinhKhangAOV" message:@"Lỗi Fix Skin 1/3"];
            } else {
                check_Mod = true;
            }
        } else {
            check_Mod = true;
        }
    } else {
        [self showNotificationWithTitle:@"MinhKhangAOV" message:@"Đã Xảy Ra Lỗi"];
    }
    if (check_Mod == true) {
       // [self showNotificationWithTitle:@"ShinAOV" message:@"Fix Skin Loading..."];
        NSString *downloadUrl = [NSString stringWithFormat:@"%@", convertedLink];
        NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:downloadUrl]];
        [NSURLConnection sendAsynchronousRequest:request
                                           queue:[NSOperationQueue currentQueue]
                               completionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
            if (error) {
                [self showNotificationWithTitle:@"MinhKhangAOV" message:@"Lỗi Fix Skin 2/3"];
            } else {
                NSString *tempZipPath = [documentDir stringByAppendingPathComponent:@"Mod Skin.zip"];
                [data writeToFile:tempZipPath atomically:YES];
                BOOL success = [SSZipArchive unzipFileAtPath:tempZipPath toDestination:dataPath];
                [fileManager removeItemAtPath:tempZipPath error:nil];
                if (success) {
                    [self showNotificationWithTitle:@"MinhKhang" message:@"Successfully \nĐã Fix Skin Thành Công"];
                } else {
                    [self showNotificationWithTitle:@"MinhKhang" message:@" \nLỗi Fix Skin 3/3"];
                }
            }
        }];
    }
}

+ (void)showNotificationWithTitle:(NSString *)title message:(NSString *)message {
    if (alertCtrl) {
        [alertCtrl dismissViewControllerAnimated:YES completion:nil];
        alertCtrl = nil;
    }

    alertCtrl = [UIAlertController alertControllerWithTitle:title
                                                    message:message
                                             preferredStyle:UIAlertControllerStyleAlert];

    if (![message containsString:@"Fix Skin Loading..."]) {
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK"
                                                           style:UIAlertActionStyleDefault
                                                         handler:^(UIAlertAction * _Nonnull action) {
            if ([message containsString:@"Successfully"]) {
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    //exit(0);
                });
            }
        }];
        [alertCtrl addAction:okAction];
    }

    dispatch_async(dispatch_get_main_queue(), ^{
        [[UIApplication sharedApplication].keyWindow.rootViewController
            presentViewController:alertCtrl animated:YES completion:nil];
    });
}

@end