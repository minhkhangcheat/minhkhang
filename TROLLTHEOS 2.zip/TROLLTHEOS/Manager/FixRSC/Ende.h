#pragma once
#include <vector>
#include <optional>
#include <string>
struct Ende {
    std::vector<uint8_t> dict;
    Ende();
    std::optional<std::string> tryDecodeIfZstd(const std::vector<uint8_t>& input);
};
