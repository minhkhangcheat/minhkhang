#pragma once
#ifdef __cplusplus
extern "C" {
#endif
void DrawFixPanelImGui(void);
void StartRestoreAllAsync(void); 
void RestoreAllThenApplySelected(void);
#ifdef __cplusplus
}
#endif
