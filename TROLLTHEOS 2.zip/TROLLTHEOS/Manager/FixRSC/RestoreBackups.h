#pragma once
#include <filesystem>

namespace restore_utils {
struct RestoreStats {
    int total   = 0;
    int restored= 0;
    int failed  = 0;
};

// C++ API (cho .cpp/.mm)
RestoreStats RestoreAllBackupsInDir(const std::filesystem::path& root);
} // namespace restore_utils
extern const std::filesystem::path kResourcesDir;
// C ABI wrapper (tuỳ chọn, để gọi từ .m)
// Trả về số file khôi phục được; root_path là đường dẫn UTF-8.
#ifdef __cplusplus
extern "C" {
#endif
int RestoreAllBackupsInDirC(const char* root_path_utf8);
#ifdef __cplusplus
}
#endif
