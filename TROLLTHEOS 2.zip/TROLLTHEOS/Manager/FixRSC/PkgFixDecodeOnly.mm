
#import <Foundation/Foundation.h>
#if __has_include(<filesystem>)
  #include <filesystem>
  namespace fs = std::filesystem;
#elif __has_include(<experimental/filesystem>)
  #include <experimental/filesystem>
  namespace fs = std::experimental::filesystem;
#else
  #error "Requires <filesystem> (C++17)."
#endif
extern "C" {
  #include "Manager/SSZipArchive/minizip/zip.h"
  #include "Manager/SSZipArchive/minizip/ioapi.h"
} 
#import "Manager/SSZipArchive/SSZipArchive.h"  
#include <zstd.h>
#include <zstd_errors.h>
#include "tinyxml2.h"
#include <filesystem>
#include <fstream>
#include <vector>
#include <string>
#include <optional>
#include <unordered_map>
#include <functional>
#include <regex>

#include "EmbeddedDict.h"     

extern void AddLog(const std::string& msg);

static inline bool endsWithBak(const std::string& s) {
    return s.size() >= 4 && s.rfind(".bak") == s.size() - 4;
}
static inline std::filesystem::path addBakOnce(const std::filesystem::path& p) {
    std::string s = p.string();
    if (endsWithBak(s)) return p;          
    return std::filesystem::path(s + ".bak");
}
static inline std::filesystem::path stripBak(const std::filesystem::path& p) {
    std::string s = p.string();
    if (!endsWithBak(s)) return p;
    s.resize(s.size()-4);
    return std::filesystem::path(s);
}
static std::filesystem::path backupPathFor(const std::filesystem::path& p) {
    return addBakOnce(p);
}
static bool ensureBackupOnce(const std::filesystem::path& p) {
    
    try {
        if (!fs::exists(p)) {
            AddLog(std::string("[FixRSC] backup skipped (not found): ") + p.string());
            return false;
        }
        if (endsWithBak(p.string())) {
            AddLog(std::string("[FixRSC] skip backup for .bak: ") + p.string());
            return true;
        }
        fs::path bak = backupPathFor(p);
        if (fs::exists(bak)) {
            AddLog(std::string("[FixRSC] backup exists: ") + bak.string());
            return true;
        }
        fs::create_directories(bak.parent_path());
        fs::copy_file(p, bak, fs::copy_options::none);
        AddLog(std::string("[FixRSC] backup created: ") + bak.string());
        return true;
    } catch (const std::exception& e) {
        AddLog(std::string("[FixRSC] backup failed: ") + p.string() + " err=" + e.what());
        return false;
    }
}


namespace fs = std::filesystem;
using namespace tinyxml2;

// ===== ZSTD header magic & helpers
static const unsigned char ZSTD_HEADER[] = {0x28,0xB5,0x2F,0xFD};

static inline bool hasZstdHeader(const std::vector<uint8_t>& b){
    return b.size()>=4 && std::equal(std::begin(ZSTD_HEADER), std::end(ZSTD_HEADER), b.begin());
}
static std::optional<size_t> findZstdMagicOffset(const std::vector<uint8_t>& b, size_t maxProbe = 512) {
    size_t n = std::min(b.size(), maxProbe);
    for (size_t i = 0; i + 4 <= n; ++i)
        if (b[i]==0x28 && b[i+1]==0xB5 && b[i+2]==0x2F && b[i+3]==0xFD) return i;
    return std::nullopt;
}

static inline std::vector<uint8_t> readBytes(const fs::path &p) {
    std::ifstream f(p, std::ios::binary);
    return std::vector<uint8_t>((std::istreambuf_iterator<char>(f)), {});
}
static inline void writeText(const fs::path &p, const std::string &s) {
    fs::create_directories(p.parent_path());
    std::ofstream f(p, std::ios::binary);
    f.write(s.data(), (std::streamsize)s.size());
}
static inline std::string readText(const fs::path& p) {
    std::ifstream f(p, std::ios::binary);
    return std::string((std::istreambuf_iterator<char>(f)), {});
}
static std::string firstBytesHex(const std::vector<uint8_t>& v, size_t k=8){
    std::string s; char buf[8];
    k = std::min(k, v.size());
    for (size_t i=0;i<k;i++){ snprintf(buf,sizeof(buf),"%02X", v[i]); s += buf; if(i+1<k) s+=' '; }
    return s;
}

// ===== try convert UTF-16/32-with-BOM -> UTF-8 (for safety)
static bool maybeConvertToUtf8(const std::vector<uint8_t>& raw, std::string& utf8Out) {
    NSStringEncoding enc = 0;
    if (raw.size() >= 2 && raw[0]==0xFF && raw[1]==0xFE) enc = NSUTF16LittleEndianStringEncoding;
    else if (raw.size() >= 2 && raw[0]==0xFE && raw[1]==0xFF) enc = NSUTF16BigEndianStringEncoding;
    else if (raw.size() >= 4 && raw[0]==0xFF && raw[1]==0xFE && raw[2]==0x00 && raw[3]==0x00) enc = NSUTF32LittleEndianStringEncoding;
    else if (raw.size() >= 4 && raw[0]==0x00 && raw[1]==0x00 && raw[2]==0xFE && raw[3]==0xFF) enc = NSUTF32BigEndianStringEncoding;
    else return false;
    NSData* data = [NSData dataWithBytes:raw.data() length:raw.size()];
    NSString* s = [[NSString alloc] initWithData:data encoding:enc];
    if (!s) return false;
    utf8Out = std::string([s UTF8String] ? [s UTF8String] : "");
    return !utf8Out.empty();
}

// ===== ZSTD decode with dict
struct Ende {
    std::vector<uint8_t> dict;
    Ende() { dict.assign(g_zstd_dict, g_zstd_dict + g_zstd_dict_len); }
    std::optional<std::string> tryDecodeIfZstd(const std::vector<uint8_t>& input) {
        if (!hasZstdHeader(input)) return std::nullopt;
        ZSTD_DCtx* dctx = ZSTD_createDCtx();
        if (!dctx) return std::nullopt;
        if (ZSTD_isError(ZSTD_DCtx_loadDictionary(dctx, dict.data(), dict.size()))) {
            ZSTD_freeDCtx(dctx); return std::nullopt;
        }
        unsigned long long rSize = ZSTD_getFrameContentSize(input.data(), input.size());
        if (rSize == ZSTD_CONTENTSIZE_ERROR || rSize == ZSTD_CONTENTSIZE_UNKNOWN)
            rSize = input.size() * 4ull;
        std::string out; out.resize((size_t)rSize);
        size_t dec = ZSTD_decompressDCtx(dctx, out.data(), out.size(), input.data(), input.size());
        ZSTD_freeDCtx(dctx);
        if (ZSTD_isError(dec)) return std::nullopt;
        out.resize(dec);
        return out;
    }
};
static std::optional<std::string> tryDecodeZstdWithOffset(const std::vector<uint8_t>& raw, size_t off, Ende& ende) {
    if (off >= raw.size()) return std::nullopt;
    std::vector<uint8_t> view(raw.begin() + off, raw.end());
    return ende.tryDecodeIfZstd(view);
}

// ===== SSZipArchive helpers
static bool unzipAll(const fs::path& zipPath, const fs::path& outDir) {
    fs::create_directories(outDir);
    NSError* error = nil;
    BOOL ok = [SSZipArchive unzipFileAtPath:[NSString stringWithUTF8String:zipPath.string().c_str()]
                              toDestination:[NSString stringWithUTF8String:outDir.string().c_str()]
                                  overwrite:YES
                                   password:nil
                                      error:&error];
    if (!ok || error) {
        AddLog(std::string("[FixRSC] unzip error: ") + (error ? [[error description] UTF8String] : "unknown"));
        return false;
    }
    return true;
}
static bool zipFolderStore_minizip(const fs::path& folder, const fs::path& outZip) {
    // mở zip (64-bit safe)
    zipFile zf = zipOpen64(outZip.string().c_str(), 0);
    if (!zf) { AddLog("[FixRSC] zipOpen64 failed"); return false; }

    // duyệt tất cả file
    const size_t BUFSZ = 1 << 15;
    std::vector<unsigned char> buf(BUFSZ);

    for (auto &ent : fs::recursive_directory_iterator(folder)) {
        if (!ent.is_regular_file()) continue;

        // tên trong zip: đường dẫn tương đối, dấu "/" forward
        auto rel = fs::relative(ent.path(), folder).generic_string();

        // info (timestamp…) có thể để 0; không bắt buộc
        zip_fileinfo zi{};
        // method = 0 (STORE), level = 0
        int err = zipOpenNewFileInZip3_64(
            zf,
            rel.c_str(),
            &zi,
            NULL, 0, NULL, 0,
            NULL,
            /*method*/ 0,            // STORE
            /*level*/  0,            // Z_NO_COMPRESSION
            0,
            -MAX_WBITS, DEF_MEM_LEVEL, Z_DEFAULT_STRATEGY,
            /*password*/ NULL,
            /*crcForCrypting*/ 0,
            /*zip64*/ (ent.file_size() >= 0xFFFFFFFFULL) ? 1 : 0
        );
        if (err != ZIP_OK) {
            AddLog(std::string("[FixRSC] zipOpenNewFileInZip STORE failed: ") + rel);
            zipClose(zf, NULL);
            return false;
        }

        // ghi dữ liệu file
        FILE* f = fopen(ent.path().string().c_str(), "rb");
        if (!f) {
            AddLog(std::string("[FixRSC] fopen failed: ") + ent.path().string());
            zipCloseFileInZip(zf);
            zipClose(zf, NULL);
            return false;
        }
        size_t n;
        while ((n = fread(buf.data(), 1, BUFSZ, f)) > 0) {
            if (zipWriteInFileInZip(zf, buf.data(), (unsigned int)n) != ZIP_OK) {
                fclose(f);
                zipCloseFileInZip(zf);
                zipClose(zf, NULL);
                AddLog(std::string("[FixRSC] zipWriteInFileInZip failed: ") + rel);
                return false;
            }
        }
        fclose(f);
        zipCloseFileInZip(zf);
    }

    zipClose(zf, NULL);
    return true;
}

// ===== Rules (per file) =====
struct Action {
    std::string type;
    std::string tag;
    std::unordered_map<std::string,std::string> selAttrs;

    std::unordered_map<std::string,std::string> values; // set_attr
    std::vector<std::string> keys;                       // remove_attr
    std::string key, oldv, newv;                         // replace_attr_value
    std::string text;                                    // set_text

    struct ChildSpec { std::string tag; std::unordered_map<std::string,std::string> attrs; std::optional<std::string> text; } child;
    std::string subtreeXml; std::string whereTag; std::unordered_map<std::string,std::string> whereAttrs;
};

struct FileRule {
    // match
    std::string file;       // exact filename
    std::string glob;       // wildcard, supports '*' and '?'
    bool any = false;       // apply to any file
    // payload
    std::vector<Action> actions;
    std::optional<std::string> tmpl; // force template content (optional)
};

static bool wildcardMatch(const std::string& pattern, const std::string& text) {
    // simple glob: * and ?
    std::string regex_pat; regex_pat.reserve(pattern.size()*2);
    regex_pat += '^';
    for (char c: pattern) {
        switch (c) {
            case '*': regex_pat += ".*"; break;
            case '?': regex_pat += "."; break;
            case '.': case '+': case '(': case ')': case '{': case '}':
            case '[': case ']': case '^': case '$': case '|': case '\\':
                regex_pat += '\\'; regex_pat += c; break;
            default: regex_pat += c; break;
        }
    }
    regex_pat += '$';
    return std::regex_match(text, std::regex(regex_pat));
}

static Action loadOneAction(NSDictionary* m) {
    Action a;
    a.type = [[m objectForKey:@"action"] ?: @"" UTF8String];

    NSDictionary* sel=[m objectForKey:@"select"];
    if([sel isKindOfClass:[NSDictionary class]]){
        a.tag = [[sel objectForKey:@"tag"] ?: @"" UTF8String];
        NSDictionary* at=[sel objectForKey:@"attrs"];
        if([at isKindOfClass:[NSDictionary class]]){
            for(NSString* k in at) a.selAttrs[[k UTF8String]] = [[at[k] description] UTF8String];
        }
    }
    NSDictionary* vals=[m objectForKey:@"values"];
    if([vals isKindOfClass:[NSDictionary class]]){
        for(NSString* k in vals) a.values[[k UTF8String]]=[[vals[k] description] UTF8String];
    }
    NSArray* keys=[m objectForKey:@"keys"];
    if([keys isKindOfClass:[NSArray class]]) for(id k in keys) a.keys.push_back([[k description] UTF8String]);
    a.key  = [[[m objectForKey:@"key"] ?: @"" description] UTF8String];
    a.oldv = [[[m objectForKey:@"old"] ?: @"" description] UTF8String];
    a.newv = [[[m objectForKey:@"new"] ?: @"" description] UTF8String];
    a.text = [[[m objectForKey:@"text"] ?: @"" description] UTF8String];

    NSDictionary* cs=[m objectForKey:@"child_spec"];
    if([cs isKindOfClass:[NSDictionary class]]){
        a.child.tag = [[[cs objectForKey:@"tag"] ?: @"" description] UTF8String];
        NSDictionary* ca=[cs objectForKey:@"attrs"];
        if([ca isKindOfClass:[NSDictionary class]]){
            for(NSString* k in ca) a.child.attrs[[k UTF8String]]=[[ca[k] description] UTF8String];
        }
        id t=[cs objectForKey:@"text"]; if(t) a.child.text=std::string([ [t description] UTF8String ]);
    }

    NSDictionary* w=[m objectForKey:@"where_child"];
    if([w isKindOfClass:[NSDictionary class]]){
        a.whereTag = [[[w objectForKey:@"tag"] ?: @"" description] UTF8String];
        NSDictionary* wa=[w objectForKey:@"attrs"];
        if([wa isKindOfClass:[NSDictionary class]]){
            for(NSString* k in wa) a.whereAttrs[[k UTF8String]]=[[wa[k] description] UTF8String];
        }
    }
    a.subtreeXml = [[[m objectForKey:@"subtree_xml"] ?: @"" description] UTF8String];
    return a;
}

static std::vector<FileRule> loadFileRules(NSString* path) {
    NSData* d = [NSData dataWithContentsOfFile:path]; if (!d) { AddLog("[FixRSC] rules file not found"); return {}; }
    NSError* err=nil; id json=[NSJSONSerialization JSONObjectWithData:d options:0 error:&err];
    if (err || !json) { AddLog("[FixRSC] rules JSON parse error"); return {}; }

    NSArray* rulesArr = nil;
    if ([json isKindOfClass:[NSDictionary class]]) rulesArr = json[@"rules"];
    else if ([json isKindOfClass:[NSArray class]]) rulesArr = (NSArray*)json;
    if (![rulesArr isKindOfClass:[NSArray class]]) return {};

    std::vector<FileRule> res;
    for (id it in rulesArr) {
        if (![it isKindOfClass:[NSDictionary class]]) continue;
        NSDictionary* r=(NSDictionary*)it;
        FileRule fr;
        NSDictionary* m=r[@"match"];
        if ([m isKindOfClass:[NSDictionary class]]) {
            fr.file = [[m[@"file"] ?: @"" description] UTF8String];
            fr.glob = [[m[@"glob"] ?: @"" description] UTF8String];
            id any=m[@"any"]; fr.any = any ? [any boolValue] : false;
        }
        NSArray* acts=r[@"actions"];
        if ([acts isKindOfClass:[NSArray class]]) {
            for (id a in acts) if ([a isKindOfClass:[NSDictionary class]]) fr.actions.push_back(loadOneAction((NSDictionary*)a));
        }
        id tpl=r[@"template"]; if (tpl) fr.tmpl = std::string([[tpl description] UTF8String]);
        res.push_back(std::move(fr));
    }
    AddLog("[FixRSC] rules_loaded=" + std::to_string(res.size()));
    return res;
}

// ===== XML helpers
static bool matchNode(XMLElement* e, const std::string& tag, const std::unordered_map<std::string,std::string>& attrs){
    if(!e) return false;
    if(!tag.empty() && tag != e->Name()) return false;
    for(auto& kv: attrs){
        const char* v=e->Attribute(kv.first.c_str());
        if(!v || kv.second!=v) return false;
    }
    return true;
}
static void forEachMatch(XMLElement* root, const std::string& tag, const std::unordered_map<std::string,std::string>& attrs,
                         const std::function<void(XMLElement*)>& fn){
    for (XMLElement* it=root->FirstChildElement(); it; it=it->NextSiblingElement()){
        if (matchNode(it, tag, attrs)) fn(it);
        forEachMatch(it, tag, attrs, fn);
    }
}
static int applyActions(XMLDocument& doc, const std::vector<Action>& acts){
    int applied=0;
    XMLElement* root=doc.RootElement(); if(!root) return 0;
    for(const auto& a: acts){
        if(a.type=="set_attr"){
            forEachMatch(root,a.tag,a.selAttrs,[&](XMLElement* e){
                for(auto& kv:a.values) e->SetAttribute(kv.first.c_str(), kv.second.c_str());
                applied++;
            });
        }else if(a.type=="remove_attr"){
            forEachMatch(root,a.tag,a.selAttrs,[&](XMLElement* e){
                for(auto& k:a.keys) e->DeleteAttribute(k.c_str());
                applied++;
            });
        }else if(a.type=="replace_attr_value"){
            forEachMatch(root,a.tag,a.selAttrs,[&](XMLElement* e){
                const char* v=e->Attribute(a.key.c_str());
                if(v && (a.oldv.empty() || a.oldv==v)){ e->SetAttribute(a.key.c_str(), a.newv.c_str()); applied++; }
            });
        }else if(a.type=="set_text"){
            forEachMatch(root,a.tag,a.selAttrs,[&](XMLElement* e){ e->SetText(a.text.c_str()); applied++; });
        }else if(a.type=="delete_node"){
            std::vector<XMLElement*> dels; forEachMatch(root,a.tag,a.selAttrs,[&](XMLElement* e){ dels.push_back(e); });
            for(auto* e:dels) { doc.DeleteNode(e); applied++; }
        }else if(a.type=="ensure_child"){
            forEachMatch(root,a.tag,a.selAttrs,[&](XMLElement* e){
                bool exists=false;
                for(XMLElement* c=e->FirstChildElement(); c; c=c->NextSiblingElement()){
                    if(matchNode(c,a.child.tag,a.child.attrs)){ exists=true; break; }
                }
                if(!exists){
                    XMLElement* ch=doc.NewElement(a.child.tag.c_str());
                    for(auto& kv:a.child.attrs) ch->SetAttribute(kv.first.c_str(), kv.second.c_str());
                    if(a.child.text) ch->SetText(a.child.text->c_str());
                    e->InsertEndChild(ch); applied++;
                }
            });
        }else if(a.type=="ensure_subtree"){
            XMLDocument sub; if(sub.Parse(a.subtreeXml.c_str())==XML_SUCCESS){
                XMLElement* subRoot=sub.RootElement(); if(!subRoot) continue;
                forEachMatch(root,a.tag,a.selAttrs,[&](XMLElement* parent){
                    bool present=false;
                    for(XMLElement* c=parent->FirstChildElement(); c; c=c->NextSiblingElement()){
                        if( (a.whereTag.empty()||a.whereTag==c->Name()) && matchNode(c,a.whereTag,a.whereAttrs) ){ present=true; break; }
                    }
                    if(!present){
                        XMLElement* cloned=doc.NewElement(subRoot->Name());
                        for(const XMLAttribute* at=subRoot->FirstAttribute(); at; at=at->Next())
                            cloned->SetAttribute(at->Name(), at->Value());
                        parent->InsertEndChild(cloned); applied++;
                    }
                });
            }
        }
    }
    return applied;
}

// ===== find …/<heroId>_*/skill/
static std::vector<fs::path> findSkillDirs(const fs::path &root, const std::string& heroId){
    std::vector<fs::path> hits;
    for (auto &p : fs::recursive_directory_iterator(root)) {
        if (!p.is_directory()) continue;
        if (p.path().filename() == "skill") {
            auto parent = p.path().parent_path().filename().string();
            if (parent.rfind(heroId + "_", 0) == 0) hits.push_back(p.path());
        }
    }
    return hits;
}
static bool isXmlLike(const fs::path& p){
    auto ext = p.extension().string();
    if (ext == ".xml") return true;
    if (ext == ".bytes" && p.stem().extension().string() == ".xml") return true; // *.xml.bytes
    return false;
}
// thay vì static bool restoreFromBackup(const std::filesystem::path& p) cũ
static bool restoreFromBackupFile(const std::filesystem::path& originalMaybeBak) {
    
    try {
        fs::path orig = stripBak(originalMaybeBak);
        fs::path bak  = backupPathFor(orig);
        if (!fs::exists(bak)) {
            AddLog(std::string("[FixRSC] restore failed, .bak not found: ") + bak.string());
            return false;
        }
        fs::copy_file(bak, orig, fs::copy_options::overwrite_existing);
        AddLog(std::string("[FixRSC] restored original from: ") + bak.string());
        fs::remove(bak);
        AddLog(std::string("[FixRSC] deleted backup file: ") + bak.string());
        return true;
    } catch (const std::exception& e) {
        AddLog(std::string("[FixRSC] restore failed: ") + originalMaybeBak.string() + " err=" + e.what());
        return false;
    }
}

// ===== main processor =====
int processOnePkg(const fs::path &pkgPath,
                  const fs::path &rulesPath,
                  const fs::path &outDir,
                  Ende &ende)
{
    // heroId từ tên file: Actor_XXX_Actions.pkg.bytes
    auto stem = pkgPath.stem().stem().string(); // Actor_XXX_Actions
    auto pos1=stem.find('_'); auto pos2=stem.find('_',pos1+1);
    std::string heroId = (pos1!=std::string::npos && pos2!=std::string::npos) ? stem.substr(pos1+1, pos2-pos1-1) : "";
    ensureBackupOnce(pkgPath);
    // 1) extract to temp
    fs::path tmp = fs::temp_directory_path() / ("pkg_fix_" + pkgPath.filename().string());
    if(fs::exists(tmp)) fs::remove_all(tmp);
    fs::create_directories(tmp);
    if(!unzipAll(pkgPath, tmp)) { AddLog("[FixRSC] unzip failed"); return 0; }

    // 2) load file rules
    auto rules = loadFileRules([NSString stringWithUTF8String:rulesPath.string().c_str()]);

    int xml_seen=0, decoded_at0=0, decoded_scan=0, converted_utf=0, parsed=0, changed=0;

    auto matchRuleForFile = [&](const std::string& fn, const FileRule& R)->bool{
        if (R.any) return true;
        if (!R.file.empty() && fn == R.file) return true;
        if (!R.glob.empty() && wildcardMatch(R.glob, fn)) return true;
        return false;
    };

    auto visitXml = [&](const fs::path& xmlPath) {
        if (!fs::is_regular_file(xmlPath) || !isXmlLike(xmlPath)) return;

        auto fn = xmlPath.filename().string();
        std::vector<const FileRule*> targets;
        for (auto &r : rules) if (matchRuleForFile(fn, r)) targets.push_back(&r);
        if (targets.empty()) return; // không có rule cho file này

        xml_seen++;

        auto raw = readBytes(xmlPath);
        bool wrote = false;

        if (hasZstdHeader(raw)) {
            if (auto dec = ende.tryDecodeIfZstd(raw)) { writeText(xmlPath, *dec); decoded_at0++; wrote = true; }
        } else if (auto off = findZstdMagicOffset(raw)) {
            if (auto dec = tryDecodeZstdWithOffset(raw, *off, ende)) { writeText(xmlPath, *dec); decoded_scan++; wrote = true; }
        }

        std::string utf8;
        if (!wrote && maybeConvertToUtf8(raw, utf8)) { writeText(xmlPath, utf8); converted_utf++; wrote = true; }

        std::string txt = readText(xmlPath);
        XMLDocument doc;
        if (doc.Parse(txt.c_str()) != XML_SUCCESS) {
            AddLog(std::string("[FixRSC] parse fail: ") + fn + " head=" + firstBytesHex(raw, 8));
            return;
        }
        parsed++;

        int aSum=0;
        for (auto *r : targets) aSum += applyActions(doc, r->actions);
        if (aSum>0) {
            XMLPrinter pr; pr.PushDeclaration("xml version=\"1.0\" encoding=\"utf-8\"");
            doc.Print(&pr);
            writeText(xmlPath, std::string(pr.CStr()));
            changed += aSum;
        }
        // force template (nếu có)
        for (auto *r : targets) if (r->tmpl) {
            std::string cur = readText(xmlPath);
            if (cur != *r->tmpl) { writeText(xmlPath, *r->tmpl); changed++; }
            break;
        }
    };

    // 3) duyệt *.xml trong …/<heroId>_*/skill/
    auto skillDirs = findSkillDirs(tmp, heroId);
    for (auto &sd : skillDirs)
        for (auto &p : fs::recursive_directory_iterator(sd))
            visitXml(p.path());

    // nếu không thấy file thuộc phạm vi rule nào, log ra để bạn biết
    AddLog("[FixRSC] pkg=" + pkgPath.string() +
           " xml_seen="   + std::to_string(xml_seen) +
           " zstd@0="     + std::to_string(decoded_at0) +
           " zstd@scan="  + std::to_string(decoded_scan) +
           " utf16conv="  + std::to_string(converted_utf) +
           " parsed="     + std::to_string(parsed) +
           " changed="    + std::to_string(changed));

    // 4) repack -> overwrite original
    fs::create_directories(outDir);
    fs::path outPkg = outDir / pkgPath.filename();
    zipFolderStore_minizip(tmp, outPkg);  // nếu đã patch STORE trong SSZipArchive, đây sẽ là STORE
    fs::remove_all(tmp);

    return decoded_at0 + decoded_scan + converted_utf + changed;
}
// --- helper: empty/truncate a file (and optional .bak once)
static void truncateFileWithBackup(const std::filesystem::path& p) {
    
    try {
        if (fs::exists(p)) {
            // tạo .bak 1 lần
            fs::path bak = p; bak += ".bak";
            if (!fs::exists(bak)) {
                std::error_code ec;
                fs::copy_file(p, bak, fs::copy_options::none, ec);
            }
            // truncate về 0 byte
            std::ofstream f(p, std::ios::binary | std::ios::trunc);
            f.close();
            AddLog(std::string("[FixRSC] truncated: ") + p.string());
        } else {
            // nếu chưa có sẵn file, tạo file trống
            fs::create_directories(p.parent_path());
            std::ofstream f(p, std::ios::binary); f.close();
            AddLog(std::string("[FixRSC] created empty: ") + p.string());
        }
    } catch (...) {
        AddLog(std::string("[FixRSC] failed to truncate: ") + p.string());
    }
}

// --- build path: <Documents>/Resources/1.59.1/assetbundle/resourceverificationinfosetall.assetbundle
static std::filesystem::path buildVerificationBundlePath() {
    NSString *docs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
    std::filesystem::path docPath([docs UTF8String]);
    return docPath / "Resources/1.59.1/assetbundle/resourceverificationinfosetall.assetbundle";
}

// --- public C wrapper để UI gọi
extern "C" void empty_resourceverification_assetbundle(void) {
    auto target = buildVerificationBundlePath();
    truncateFileWithBackup(target);
}

// ===== wrapper C cho UI gọi (khỏi cần biết class Ende)
extern "C" int processOnePkg_withDict(const char* pkgPath,
                                      const char* rulesPath,
                                      const char* outDir) {
    Ende ende;
    return processOnePkg(std::filesystem::path(pkgPath),
                         std::filesystem::path(rulesPath),
                         std::filesystem::path(outDir),
                         ende);
}


extern "C" void backup_related_files(const char* pkgPathCStr) {
    std::filesystem::path pkgPath(pkgPathCStr ? pkgPathCStr : "");
    if (!pkgPath.empty()) ensureBackupOnce(pkgPath);
    ensureBackupOnce(buildVerificationBundlePath());
}

extern "C" bool restore_related_files(const char* pkgPathCStr) {
    bool ok = true;
    if (pkgPathCStr && *pkgPathCStr) ok &= restoreFromBackupFile(std::filesystem::path(pkgPathCStr));
    NSString *docs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
    std::filesystem::path docPath([docs UTF8String]);
    ok &= restoreFromBackupFile(docPath / "Resources/1.59.1/assetbundle/resourceverificationinfosetall.assetbundle");
    return ok;
}
