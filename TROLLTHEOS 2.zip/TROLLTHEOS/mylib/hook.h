// Modified by Euclid Jan G.
// hooks big booty latinas to your fishing line
#ifndef hook_h
#define hook_h

#ifdef __cplusplus
extern "C" {
#endif

#include <stdbool.h>

bool hook(void *o[], void *n[], int c);
bool hook_reset(void *o[], void *n[], int c);
bool unhook(void *o[], int c);
bool hook_one_point(void* instance,void* function);
bool unhook_one_point(void* instance);

#ifdef __cplusplus
}
#endif

#endif /* hook_h */