#import "MerO.h"
#import "fishhook.h"
#import <objc/runtime.h>
#import "NSLOGS.h"
#import <CoreFoundation/CoreFoundation.h>
#import <mach/mach.h>
#import <mach-o/loader.h>
#import <mach-o/dyld.h>
#import <stdio.h>
#import <stdlib.h>
#import <unistd.h>
#import <arpa/inet.h>

@interface TimerView()
@property (nonatomic, strong) NSTimer *MerOsdk;
@end

// ===== Biến toàn cục =====
BOOL UnlockSkinVip = NO;
int UnlockedHeroID = 0;
int UnlockedSkinID = 0;
dispatch_once_t hookOnceToken;

// ===== Hook functions =====
int (*orig_fopen)(const char *, const char *);
int hook_fopen(const char *path, const char *mode) {
    if (UnlockSkinVip) {
        NSString *newPath = [NSString stringWithUTF8String:path];
        NSError *error = nil;
        NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"_Skin_(\\d+)_"
                                                                               options:0
                                                                                 error:&error];
        if (error) return orig_fopen(path, mode);
        
        NSTextCheckingResult *match = [regex firstMatchInString:newPath options:0 range:NSMakeRange(0, newPath.length)];
        if (match && match.numberOfRanges > 1) {
            NSRange range = [match rangeAtIndex:1];
            NSString *skinIDStr = [newPath substringWithRange:range];
            int heroID = skinIDStr.intValue / 100;
            if (heroID == UnlockedHeroID) {
                int newNumber = heroID*100 + UnlockedSkinID;
                NSString *replacement = [NSString stringWithFormat:@"_Skin_%d_", newNumber];
                newPath = [regex stringByReplacingMatchesInString:newPath
                                                          options:0
                                                            range:NSMakeRange(0, newPath.length)
                                                     withTemplate:replacement];
                NSLog(@"[Hook] Modified fopen path: %@", newPath);
                return orig_fopen(newPath.UTF8String, mode);
            }
        }
    }
    return orig_fopen(path, mode);
}

int (*orig_memcmp)(const void *, const void *, size_t);
int hook_memcmp(const void *s1, const void *s2, size_t n) { return 0; }

int (*orig_strcmp)(const char *, const char *);
int hook_strcmp(const char *s1, const char *s2) { return 0; }

int (*orig_strcpy)(char *, const char *);
int hook_strcpy(char *dest, const char *src) { return 0; }

@implementation TimerView

+ (void)load {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        TimerView *view = [TimerView Timer];
        [view start];
        UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
        if (keyWindow) {
            [keyWindow addSubview:view];
            NSLog(@"[TimerView] Added to keyWindow.");
        } else {
            NSLog(@"[TimerView] Failed to add view to keyWindow.");
        }
    });
}

+ (instancetype)Timer {
    return [[self alloc] initWithFrame:[UIScreen mainScreen].bounds];
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.userInteractionEnabled = NO;
    }
    return self;
}

- (void)XHLJ {
    UnlockSkinVip = YES;
    
    dispatch_once(&hookOnceToken, ^{
        const char *target_image_name = "anogs";
        const struct mach_header *target_header = NULL;
        intptr_t target_slide = 0;

        uint32_t image_count = _dyld_image_count();
        for (uint32_t i = 0; i < image_count; i++) {
            const char *image_name = _dyld_get_image_name(i);
            if (strstr(image_name, target_image_name)) {
                target_header = _dyld_get_image_header(i);
                target_slide = _dyld_get_image_vmaddr_slide(i);
                break;
            }
        }
        struct rebinding rebindings[] = {
            { "memcmp", hook_memcmp, (void *)&orig_memcmp },
            { "strcmp", hook_strcmp, (void *)&orig_strcmp },
            { "strcpy", hook_strcpy, (void *)&orig_strcpy }
        };
    
        int result = rebind_symbols_image((void *)target_header, target_slide, rebindings, 3);
        if (result != 0) {
            NSLOGS(@"[Hook] Failed to open anti-ban: %d", result);
        } else {
            NSLOGS(@"Anogs đã được bật");
        }
    });
}

- (void)start {
    self.MerOsdk.fireDate = [NSDate distantPast];
    NSLog(@"[TimerView] Timer started.");
}

- (NSTimer *)MerOsdk {
    if (!_MerOsdk) {
        __weak typeof(self) weakSelf = self;
        _MerOsdk = [NSTimer scheduledTimerWithTimeInterval:0.1
                                                   repeats:YES
                                                     block:^(NSTimer * _Nonnull timer) {
            __strong typeof(weakSelf) strongSelf = weakSelf;
            if (UnlockSkinVip) {
                [strongSelf XHLJ];
                NSLog(@"[TimerView] Hook called continuously.");
            }
        }];
    }
    return _MerOsdk;
}

- (void)dealloc {
    [_MerOsdk invalidate];
    _MerOsdk = nil;
    NSLog(@"[TimerView] Timer invalidated and view deallocated.");
}

@end