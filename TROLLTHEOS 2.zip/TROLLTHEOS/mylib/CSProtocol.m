#import "CSProtocol.h"

@implementation HeroSkin

- (instancetype)initWithHeroID:(uint32_t)heroID skinID:(uint32_t)skinID {
    self = [super init];
    if (self) {
        _heroID = heroID;
        _skinID = skinID;
    }
    return self;
}

@end

@implementation CSProtocol

- (instancetype)init {
    self = [super init];
    if (self) {
        _enable = NO;
        _heroSkinDict = [NSMutableDictionary dictionary];
        [self loadHeroSkinArrayFromFile];
    }
    return self;
}

- (void)setEnable:(BOOL)isEnabled {
    _enable = isEnabled;
}

- (BOOL)isEnabled {
    return _enable;
}

- (void)checkAndUpdateHeroSkin:(uint32_t)wheroID skinID:(uint32_t)wskinID {
    NSNumber *key = @(wheroID);
    HeroSkin *existingSkin = self.heroSkinDict[key];
    
    if (existingSkin) {
        existingSkin.skinID = wskinID;
    } else {
        HeroSkin *newSkin = [[HeroSkin alloc] initWithHeroID:wheroID skinID:wskinID];
        self.heroSkinDict[key] = newSkin;
    }
    
    [self saveHeroSkinArrayToFile];
}

- (void)saveHeroSkinArrayToFile {
    NSString *filePath = [self heroSkinFilePath];
    NSMutableString *fileContent = [NSMutableString string];

    for (HeroSkin *heroSkin in self.heroSkinDict.allValues) {
        [fileContent appendFormat:@"%u,%u\n", heroSkin.heroID, heroSkin.skinID];
    }

    NSError *error = nil;
    BOOL success = [fileContent writeToFile:filePath atomically:YES encoding:NSUTF8StringEncoding error:&error];
    
    if (!success) {
        NSLog(@"Error saving file: %@", error.localizedDescription);
    }
}

- (void)loadHeroSkinArrayFromFile {
    NSString *filePath = [self heroSkinFilePath];
    NSError *error = nil;
    NSString *fileContent = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:&error];
    
    if (error || !fileContent) {
        NSLog(@"Error reading file: %@", error.localizedDescription);
        return;
    }
    
    NSArray *lines = [fileContent componentsSeparatedByString:@"\n"];
    for (NSString *line in lines) {
        NSArray *components = [line componentsSeparatedByString:@","];
        if (components.count == 2) {
            uint32_t heroID = (uint32_t)[components[0] intValue];
            uint32_t skinID = (uint32_t)[components[1] intValue];
            HeroSkin *heroSkin = [[HeroSkin alloc] initWithHeroID:heroID skinID:skinID];
            self.heroSkinDict[@(heroID)] = heroSkin;
        }
    }
}

- (BOOL)checkHeroID:(uint32_t)wheroID {
    return self.heroSkinDict[@(wheroID)] != nil;
}

- (void)addHeroSkin:(HeroSkin *)heroSkin {
    if (!self.heroSkinDict[@(heroSkin.heroID)]) {
        self.heroSkinDict[@(heroSkin.heroID)] = heroSkin;
    }
}

- (void)updateHeroSkin:(HeroSkin *)heroSkin {
    self.heroSkinDict[@(heroSkin.heroID)] = heroSkin;
}

- (int)getHeroSkinID:(uint32_t)wheroID {
    HeroSkin *heroSkin = self.heroSkinDict[@(wheroID)];
    return heroSkin ? heroSkin.skinID : 0;
}

#pragma mark - Helper

- (NSString *)heroSkinFilePath {
    NSArray<NSString *> *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    return [paths[0] stringByAppendingPathComponent:@"OSK.hpp"];
}

@end
