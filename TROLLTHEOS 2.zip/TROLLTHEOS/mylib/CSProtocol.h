#import <Foundation/Foundation.h>

@interface HeroSkin : NSObject
@property (nonatomic, assign) uint32_t heroID;
@property (nonatomic, assign) uint32_t skinID;

- (instancetype)initWithHeroID:(uint32_t)heroID skinID:(uint32_t)skinID;
@end

@interface CSProtocol : NSObject
@property (nonatomic, assign) BOOL enable; 
@property (nonatomic, strong) NSMutableDictionary<NSNumber *, HeroSkin *> *heroSkinDict;
@property (nonatomic, assign) uint32_t _heroID; 
@property (nonatomic, assign) uint32_t _skinID; 

- (void)setEnable:(BOOL)isEnabled;
- (BOOL)isEnabled;

- (void)checkAndUpdateHeroSkin:(uint32_t)wheroID skinID:(uint32_t)wskinID;
- (BOOL)checkHeroID:(uint32_t)wheroID;
- (void)addHeroSkin:(HeroSkin *)heroSkin;
- (void)updateHeroSkin:(HeroSkin *)heroSkin;
- (int)getHeroSkinID:(uint32_t)wheroID;

- (void)saveHeroSkinArrayToFile;
- (void)loadHeroSkinArrayFromFile;
@end
