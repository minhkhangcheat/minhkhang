#include <UIKit/UIKit.h>
void NSLOGS(NSString *format, ...) {
    va_list args;
    va_start(args, format);
    NSString *message = [[NSString alloc] initWithFormat:format arguments:args];
    va_end(args);

    dispatch_async(dispatch_get_main_queue(), ^{
        UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
        if (!keyWindow) return;

        UILabel *toastLabel = [[UILabel alloc] init];
        toastLabel.text = message;
        toastLabel.textColor = [UIColor whiteColor];
        toastLabel.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.7];
        toastLabel.textAlignment = NSTextAlignmentCenter;
        toastLabel.font = [UIFont systemFontOfSize:14.0];
        toastLabel.numberOfLines = 0;
        toastLabel.alpha = 0.0;
        toastLabel.layer.cornerRadius = 10;
        toastLabel.clipsToBounds = YES;

        CGFloat padding = 20;
        CGFloat maxWidth = keyWindow.frame.size.width - 2 * padding;
        CGSize maxSize = CGSizeMake(maxWidth, CGFLOAT_MAX);
        CGSize expectedSize = [toastLabel sizeThatFits:maxSize];

        toastLabel.frame = CGRectMake(padding,
                                      keyWindow.frame.size.height - expectedSize.height - 100,
                                      maxWidth,
                                      expectedSize.height + 20);

        [keyWindow addSubview:toastLabel];

        [UIView animateWithDuration:0.4 animations:^{
            toastLabel.alpha = 1.0;
        } completion:^(BOOL finished) {
            [UIView animateWithDuration:0.4 delay:2.0 options:0 animations:^{
                toastLabel.alpha = 0.0;
            } completion:^(BOOL finished) {
                [toastLabel removeFromSuperview];
            }];
        }];
    });
}
