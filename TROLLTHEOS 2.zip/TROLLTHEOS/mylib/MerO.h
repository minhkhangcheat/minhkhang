#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

// ===== Biến toàn cục =====
extern BOOL UnlockSkinVip;
extern int UnlockedHeroID;
extern int UnlockedSkinID;
extern dispatch_once_t hookOnceToken;

// ===== Hook functions =====
extern int (*orig_fopen)(const char *, const char *);
int hook_fopen(const char *path, const char *mode);

extern int (*orig_memcmp)(const void *, const void *, size_t);
int hook_memcmp(const void *s1, const void *s2, size_t n);

extern int (*orig_strcmp)(const char *, const char *);
int hook_strcmp(const char *s1, const char *s2);

extern int (*orig_strcpy)(char *, const char *);
int hook_strcpy(char *dest, const char *src);

// ===== TimerView =====
@interface TimerView : UIView

+ (instancetype)Timer;
- (void)start;

@end

NS_ASSUME_NONNULL_END