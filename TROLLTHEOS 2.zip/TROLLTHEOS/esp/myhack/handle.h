#include "ESP.h"
extern void (*_SkillButtonDown)(void *, void*, int, Vector2);
extern bool (*get_IsHostProfile)();
void CheatHandle()
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
    Attach();
    hideemoji = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LBattleEffectWidget"),oxorany("PlayEmojiEffect"), 4);
    offset[0] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LVActorLinker"),oxorany("SetVisible"), 3);
    offset[1] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LVActorLinker"),oxorany("ForceSetVisible"), 1);
    offset[2] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LVActorLinker"),oxorany("SyncActiveView"), 0);
    offset[3] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("CLobbySystem"),oxorany("OpenWaterMark"), 0);
    
    offset[4] = get_offset(oxorany("Project_d.dll"),oxorany(""),oxorany("CameraSystem"),oxorany("GetZoomRate"), 0);
    offset[5] = get_offset(oxorany("Project_d.dll"),oxorany(""),oxorany("CameraSystem"),oxorany("update"), 0);
    offset[6] = get_offset(oxorany("Project_d.dll"),oxorany(""),oxorany("CameraSystem"),oxorany("OnCameraHeightChanged"), 0);

    offset[7] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("HeroInfoPanel"),oxorany("ShowHeroInfo"), 2);
    offset[8] = get_offset(oxorany("Project_d.dll"),oxorany(""),oxorany("MiniMapHeroInfo"),oxorany("ShowHeroHpInfo"), 1);
    offset[9] = get_offset(oxorany("Project_d.dll"),oxorany(""),oxorany("MiniMapHeroInfo"),oxorany("ShowSkillStateInfo"), 1);
    offset[10] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("HeroSelectBanPickWindow"),oxorany("InitTeamHeroList"), 4);
    offset[11] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("CPlayerProfile"),oxorany("get_IsHostProfile"), 0);
    offset[12] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("PVPLoadingView"),oxorany("checkTeamLaderGradeMax"), 1);
    offset[13] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("PVPLoadingView"),oxorany("OnEnter"), 0);
    offset[14] = get_offset(oxorany("mscorlib.dll"),oxorany("System"),oxorany("String"),oxorany("CreateString"), 3);
    offset[15] = get_offset(oxorany("Project_d.dll"),oxorany("PhoneNotify"),oxorany("PhoneNotifySystem"),oxorany("_OnGameEnd"), 0);
    offset[16] = get_offset(oxorany("Project_d.dll"),oxorany("PhoneNotify"),oxorany("PhoneNotifySystem"),oxorany("_OnGameStart"), 0);
    offset[17] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"), oxorany("LFrameSyncBattleLogic"),oxorany("SendSyncData"), 2);
    offset[18] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.UI"), oxorany("CUIUtility"),oxorany("RemovEspace"), 1);
    offset[19] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"),oxorany("IsNewbieFirstOperateBitSet"), 1);
    offset[20] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"), oxorany("InBattleMsgNetCore"),oxorany("SendInBattleMsg_InputChat"), 2);


    Esp[0]  = get_offset(oxorany("Project_d.dll"),oxorany("Kyrios"),oxorany("KyriosFramework"),oxorany("get_actorManager"), 0);
    Esp[1]  = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("CBattleSystem"),oxorany("get_TheMinimapSys"), 0);
    Esp[2]  = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("CBattleSystem"),oxorany("CvtWorld2UISM"), 1);
    Esp[3]  = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("CBattleSystem"),oxorany("CvtWorld2UIBM"), 1);
    Esp[4] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("CBattleSystem"),oxorany("GetHero_Icon"), 2);
    Esp[5] = get_offset(oxorany("Project_d.dll"),oxorany("Kyrios"),oxorany("KyriosFramework"),oxorany("get_playerCenter"), 0);
    Esp[6] = get_offset(oxorany("Project_d.dll"),oxorany("Kyrios"),oxorany("KyriosFramework"),oxorany("get_hostLogic"), 0);
    Esp[7] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("BattleLogic"),oxorany("GetCurLvelContext"), 0);
    Esp[8] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("SLevelContext"),oxorany("GetGameRoomType"), 0);
    Esp[9] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("SkillSlot"),oxorany("RequestUseSkill"), 0);
    Esp[10] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("SkillSlot"),oxorany("ReadyUseSkill"), 1);
    Esp[11] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("SkillSlot"),oxorany("get_IsCharging"), 0);
    Esp[12]  = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("CBattleSystem"),oxorany("get_FightForm"), 0);
    Esp[13] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("CSkillButtonManager"),oxorany("CanRequestSkill"), 1);
    Esp[14] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("CSkillButtonManager"),oxorany("RequestUseSkillSlot"), 4);
    Esp[15] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("HudComponent3D"),oxorany("SetPlayerName"), 4);
    Esp[16] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("CHeroSelectBaseSystem"),oxorany("GetSelfCamp"), 0);
    Esp[17] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("CHeroSelectBaseSystem"),oxorany("GetTeamHeroCommonInfoList"), 1);
    Esp[18] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("LobbyMsgHandler"),oxorany("ForceKillCrystal"),1);
    Esp[19] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("CRoleInfoManager"),oxorany("GetMasterRoleInfo"), 0);
    Esp[20] = get_offset(oxorany("UnityEngine.CoreModule.dll"),oxorany("UnityEngine"),oxorany("Object"),oxorany("FindObjectOfType"), 1);
    Esp[21] = get_offset(oxorany("mscorlib.dll"),oxorany("System"),oxorany("Type"),oxorany("GetType"), 1);
    Esp[22] = get_offset(oxorany("UnityEngine.CoreModule.dll"),oxorany("UnityEngine"),oxorany("Object"),oxorany("FindObjectsOfType"), 1);
    Esp[23] = get_offset(oxorany("mscorlib.dll"),oxorany("System"),oxorany("Type"),oxorany("ToString"), 0);
    Esp[24] = get_offset(oxorany("UnityEngine.CoreModule.dll"),oxorany("UnityEngine"),oxorany("Resources"),oxorany("FindObjectsOfTypeAll"), 1);
    Esp[25] = get_offset(oxorany("mscorlib.dll"),oxorany("System.Reflection"),oxorany("Assembly"),oxorany("Load"), 1);
    Esp[26] = get_offset(oxorany("mscorlib.dll"),oxorany("System.Reflection"),oxorany("Assembly"),oxorany("GetType"), 1);
    Esp[27] = get_offset(oxorany("UnityEngine.CoreModule.dll"),oxorany("UnityEngine"),oxorany("Object"),oxorany("GetName"), 1);
    Esp[28] = get_offset(oxorany("UnityEngine.CoreModule.dll"),oxorany("UnityEngine"),oxorany("GameObject"),oxorany("get_activeInHierarchy"), 0);
    Esp[29] = get_offset(oxorany("UnityEngine.CoreModule.dll"),oxorany("UnityEngine"),oxorany("GameObject"),oxorany("GetComponentsInternal"), 6);
    Esp[30] = get_offset(oxorany("UnityEngine.CoreModule.dll"),oxorany("UnityEngine"),oxorany("GameObject"),oxorany("GetComponent"), 1);
    Esp[31] = get_offset(oxorany("UnityEngine.CoreModule.dll"),oxorany("UnityEngine"),oxorany("GameObject"),oxorany("GetComponentInChildren"), 1);
    Esp[32] = get_offset(oxorany("UnityEngine.CoreModule.dll"),oxorany("UnityEngine"),oxorany("GameObject"),oxorany("GetComponentInParent"), 1);
    Esp[33] = get_offset(oxorany("UnityEngine.CoreModule.dll"),oxorany("UnityEngine"),oxorany("Object"),oxorany("GetOffsetOfInstanceIDInCPlusPlusObject"), 0);
    Esp[34] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany(""),oxorany("Text2"),oxorany("get_text"), 0);
    Esp[35] = get_offset(oxorany("UnityEngine.CoreModule.dll"),oxorany("UnityEngine"),oxorany("Object"),oxorany("GetInstanceID"), 0);
    Esp[36] = get_offset(oxorany("UnityEngine.CoreModule.dll"),oxorany("UnityEngine"),oxorany("Camera"),oxorany("get_cameraToWorldMatrix"), 0); 
    Esp[37] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("SkillControlIndicator"),oxorany("GetUseSkillPosition"),1);
    Esp[38] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("SkillControlIndicator"),oxorany("GetUseSkillDirection"),1);
    Esp[39] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("BuffSkill"),oxorany("get_SkillID"),0);
    Esp[40] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic.Battle.CommunicateSignal"),oxorany("CommunicateAgent"),oxorany("GetGameTime"),0);
    Esp[41] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("GameInput"),oxorany("CalcDirectionByTouchPosition"),2);
    
    EspField[0] = getFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic.GameKernal"),oxorany("GamePlayerCenter"),oxorany("_players"));
    EspField[1] = getFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("LDataProvider"),oxorany("PlayerBase"),oxorany("PlayerId"));
    EspField[2] = getFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("LDataProvider"),oxorany("PlayerBase"),oxorany("broadcastID"));
    EspField[3] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("ActorManager"),oxorany("HeroActors"));
    EspField[4] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("ActorManager"),oxorany("OrganActors"));
    EspField[5] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("ActorManager"),oxorany("TowerActors"));
    EspField[6] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("ActorManager"),oxorany("MonsterActors"));
    EspField[7] = getFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LLogicCore"),oxorany("instances"));
    EspField[8] = getFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LDeskBase"),oxorany("<DeskBattleLogic>k__BackingField"));
    EspField[9] = getFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LBattleLogic"),oxorany("<gameActorMgr>k__BackingField"));
    EspField[10] = getFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LGameActorMgr"),oxorany("HeroActors"));
    EspField[11] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("FightForm"),oxorany("<m_skillButtonManager>k__BackingField"));
    EspField[12] = getFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("LDataProvider"),oxorany("PlayerBase"),oxorany("Name"));
    EspField[13] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Kyrios"),oxorany("VHostLogic"),oxorany("<HostPlayerId>k__BackingField"));
    EspField[15]  = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("CBattleSystem"),oxorany("m_isInBattle"));
    EspField[16]  = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("CSkillButtonManager"),oxorany("m_currentSkillSlotType"));
    EspField[17]  = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("SkillControlIndicator"),oxorany("skillSlot"));
    EspField[18]  = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("SkillSlot"),oxorany("SlotType"));
    EspField[19] = getFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LGameActorMgr"),oxorany("MonsterActors"));
	EspField[20] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("ActorLinker"),oxorany("isMoving"));
	EspField[21] = getFieldOffset(oxorany("Project_d.dll"),oxorany(""),oxorany("CameraSystem"),oxorany("zoomRateFromAge"));
    EspField[22]  = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("CBattleSystem"),oxorany("<TheBattleEquipSystem>k__BackingField"));
    EspField[23] = getFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("LDataProvider"),oxorany("PlayerBase"),oxorany("PersonalButtonID"));
    EspField[24] = getFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("LDataProvider"),oxorany("PlayerBase"),oxorany("usingSoldierSkinID"));

    ActorLinkerOff[0] = get_offset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("ActorLinker"),oxorany("IsHostPlayer"),0);
    ActorLinkerOff[1] = get_offset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("ActorLinker"),oxorany("IsHostCamp"),0);
    ActorLinkerOff[2] = get_offset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("ActorLinker"),oxorany("get_objType"),0);
    ActorLinkerOff[3] = get_offset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("ActorLinker"),oxorany("get_objCamp"),0);
    ActorLinkerOff[4] = get_offset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("ActorLinker"),oxorany("get_position"),0);
    ActorLinkerOff[5] = get_offset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("ActorLinker"),oxorany("get_HPBarVisible"),0);
    ActorLinkerOff[6] = get_offset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("ActorLinker"),oxorany("get_ObjID"),0);
    ActorLinkerOff[7] = get_offset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("ActorLinker"),oxorany("get_bVisible"),0);
    ActorLinkerOff[8] = get_offset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("ActorLinker"),oxorany("AsHero"),0);
    ActorLinkerOff[9] = get_offset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("ActorLinker"),oxorany("get_playerId"),0);
    ActorLinkerOff[10] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("HudComponent3D"),oxorany("get_ValueCompChangeActor"), 0);
    ActorLinkerOff[11] = get_offset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("ValueLinkerComponent"),oxorany("get_actorHp"),0);
    ActorLinkerOff[12] = get_offset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("ValueLinkerComponent"),oxorany("get_actorHpTotal"),0);
    ActorLinkerOff[13] = get_offset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("ValueLinkerComponent"),oxorany("get_actorSoulLevel"),0);
    
    ActorLinkerOffField[0] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("ActorLinker"),oxorany("ValueComponent"));
    ActorLinkerOffField[1] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("ActorLinker"),oxorany("HudControl"));
    ActorLinkerOffField[2] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("ActorLinker"),oxorany("CharInfo"));
    ActorLinkerOffField[3] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("ActorLinker"),oxorany("ObjLinker"));
    ActorLinkerOffField[4] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("ActorLinker"),oxorany("EquipLinkerComp"));
    ActorLinkerOffField[5] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("ActorLinker"),oxorany("SkillControl"));
    ActorLinkerOffField[6] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("SkillComponent"),oxorany("SkillSlotArray"));
    ActorLinkerOffField[7] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("SkillSlot"),oxorany("skillIndicator"));
    ActorLinkerOffField[8] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("SkillControlIndicator"),oxorany("curindicatorDistance"));
    ActorLinkerOffField[9] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("SkillControlIndicator"),oxorany("useSkillDirection"));
    ActorLinkerOffField[10] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("SkillControlIndicator"),oxorany("useSkillPosition"));
    ActorLinkerOffField[11] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("ActorConfig"),oxorany("ConfigID"));
    ActorLinkerOffField[12] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("HeroWrapperData"),oxorany("heroWrapSkillData_1"));
    ActorLinkerOffField[13] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("HeroWrapperData"),oxorany("heroWrapSkillData_2"));
    ActorLinkerOffField[14] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("HeroWrapperData"),oxorany("heroWrapSkillData_3"));
    ActorLinkerOffField[15] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("HeroWrapperData"),oxorany("heroWrapSkillData_5"));
    ActorLinkerOffField[16] = getFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Share"),oxorany("HeroWrapSkillData"),oxorany("Skill1SlotCD"));
    ActorLinkerOffField[17] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("ActorLinker"),oxorany("BuffControl"));
    ActorLinkerOffField[18] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("BuffLinkerComponent"),oxorany("SpawnedBuffList"));
    ActorLinkerOffField[19] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("SkillComponent"),oxorany("curSkilSlot"));
    ActorLinkerOffField[20] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("SkillControlIndicator"),oxorany("useOffsetPosition"));
    ActorLinkerOffField[21] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("SkillControlIndicator"),oxorany("useSkillPosition"));
    ActorLinkerOffField[22] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("HeroWrapperData"),oxorany("heroWrapSkillData_ex3"));

    LActorRootOff[0] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LActorRoot"),oxorany("get_forward"),0);
    LActorRootOff[1] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LActorRoot"),oxorany("get_location"),0);
    LActorRootOff[2] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LActorRoot"),oxorany("AsHero"),0);
    LActorRootOff[3] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LActorRoot"),oxorany("GiveMyEnemyCamp"),0);
    LActorRootOff[4] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LActorRoot"),oxorany("get_bActive"),0);
    LActorRootOff[5] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LActorRoot"),oxorany("get_ObjID"),0);
    LActorRootOff[6] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LObjWrapper"),oxorany("get_IsDeadState"),0);
    LActorRootOff[7] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LObjWrapper"),oxorany("IsAutoAI"),0);
    LActorRootOff[8] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("ValuePropertyComponent"),oxorany("get_actorHp"),0);
    LActorRootOff[9] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("ValuePropertyComponent"),oxorany("get_actorHpTotal"),0);
    LActorRootOff[10] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LActorRoot"),oxorany("get_PlayerMovement"),0);
    LActorRootOff[11] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LEquipComponent"),oxorany("BuyEquip"),3);
    LActorRootOff[12] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LEquipComponent"),oxorany("SellEquip"),1);
    LActorRootOff[13] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LEquipComponent"),oxorany("GetEquips"),0);
    LActorRootOff[14] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("ValuePropertyComponent"),oxorany("get_actorSoulLevel"), 0);
    LActorRootOff[15] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("ValuePropertyComponent"),oxorany("get_actorEp"), 0);
    LActorRootOff[16] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("ValuePropertyComponent"),oxorany("get_actorEpTotal"), 0);
    LActorRootOff[17] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LSkillComponent"),oxorany("GetSkillSlot"), 1);
    LActorRootOff[18] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("SkillSlot"),oxorany("get_RealSkillObj"), 0);
    LActorRootOff[19] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("PlayerMovement"),oxorany("get_speed"),0);
    LActorRootOff[20] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LFrameSyncBattlePooledClassObject"),oxorany("get_battleLogic"),0);
    LActorRootOff[21] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("CBattleSystem"),oxorany("Update"),0);

    LActorRootOffField[0] = getFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LActorRoot"),oxorany("ValueComponent"));
    LActorRootOffField[1] = getFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LActorRoot"),oxorany("ActorControl"));
    LActorRootOffField[2] = getFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LActorRoot"),oxorany("EquipComponent"));
    LActorRootOffField[3] = getFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LActorRoot"),oxorany("EquipComponent"));
    LActorRootOffField[4] = getFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LActorRoot"),oxorany("SkillControl"));
    LActorRootOffField[5] = getFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LActorRoot"),oxorany("ObjLinker"));
    LActorRootOffField[6] = getFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("SkillSlot"),oxorany("<CurSkillCD>k__BackingField"));
    LActorRootOffField[7] = getFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LActorRoot"),oxorany("HorizonMarker"));
    LActorRootOffField[8] = getFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LBattleLogic"),oxorany("<spectatorMgr>k__BackingField"));
    LActorRootOffField[9] = getFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LVActorLinker"),oxorany("Visible"));
    LActorRootOffField[10] = getFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LHeroWrapper"),oxorany("CommunicateAgentCtrl"));


    MinimapOffField[0] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("MinimapSys"),oxorany("mMapTransferData"));
    MinimapOffField[1] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("MinimapSys"),oxorany("curMapType"));
    MinimapOffField[2] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("MinimapSys/CMapTransferData"),oxorany("mmFinalScreenSize"));
    MinimapOffField[3] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("MinimapSys/CMapTransferData"),oxorany("mmFinalScreenPos"));
    MinimapOffField[4] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("MinimapSys/CMapTransferData"),oxorany("bmFinalScreenPos"));
    MinimapOffField[5] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("MinimapSys/CMapTransferData"),oxorany("bmFinalScreenSize"));
    MinimapOffField[6] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.Framework"),oxorany("GameFramework"),oxorany("newResolutionMode"));

    Cam[0] = get_offset(oxorany("UnityEngine.CoreModule.dll"),oxorany("UnityEngine"),oxorany("Camera"),oxorany("get_main"), 0);
    Cam[1] = get_offset(oxorany("UnityEngine.CoreModule.dll"),oxorany("UnityEngine"),oxorany("Camera"),oxorany("WorldToScreenPoint"), 1);
    Cam[2] = get_offset(oxorany("UnityEngine.CoreModule.dll"),oxorany("UnityEngine"),oxorany("Camera"),oxorany("WorldToViewportPoint"), 1);
    Cam[3] = get_offset(oxorany("UnityEngine.CoreModule.dll"),oxorany("UnityEngine"),oxorany("Camera"),oxorany("get_fieldOfView"), 0);
    Cam[4] = get_offset(oxorany("UnityEngine.CoreModule.dll"),oxorany("UnityEngine"),oxorany("Camera"),oxorany("set_fieldOfView"), 1);
    Il2CppHookImpl("Project_d.dll", "", "CameraSystem", (void *)CameraSystem_Update, (void *)&_CameraSystem_Update, "Update", 0);

    ModSkin[0] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.Framework"),oxorany("GameDataMgr"),oxorany("IsSkinAvailable"),1);
    ModSkin[1] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("CRoleInfo"),oxorany("IsCanUseSkin"), 2);
    ModSkin[2] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("CRoleInfo"),oxorany("GetHeroWearSkinId"), 1);	
    ModSkin[3] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("CRoleInfo"),oxorany("IsPrimeFreeSkin"), 2);
    ModSkin[4] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("HeroSelectNormalWindow"),oxorany("OnClickSelectHeroSkin"), 2);
    ModSkin[5] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("HeroSelectNormalWindow"),oxorany("RefreshHeroPanel"), 3);
    ModSkin[6] = get_offset(oxorany("AovTdr.dll"),oxorany("CSProtocol"),oxorany("COMDT_HERO_COMMON_INFO"),oxorany("unpack"),2);
    ModSkin[7] = get_offset(oxorany("AovTdr.dll"),oxorany("ResData"),oxorany("ResHeroSkin"),oxorany("unpack"),2);
    ModSkin[8] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("PersonalButton"),oxorany("IsOpen"), 0);
    ModSkin[9] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("PersonalButton"),oxorany("get_PersonalBtnId"), 0);
    ModSkin[10] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("PersonalButton"),oxorany("RefreshPersonalButtonForBattle"), 0);
    ModSkinOffField[0] = getFieldOffset(oxorany("AovTdr.dll"),oxorany("CSProtocol"),oxorany("COMDT_HERO_COMMON_INFO"),oxorany("dwHeroID"));
    ModSkinOffField[1] = getFieldOffset(oxorany("AovTdr.dll"),oxorany("CSProtocol"),oxorany("COMDT_HERO_COMMON_INFO"),oxorany("wSkinID"));
    ModSkinOffField[2] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("CHeroSelectNormalSystem"),oxorany("_heroSelectNormalWindowScript"));
    ModSkinOffField[3] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("CHeroSelectBanPickSystem"),oxorany("m_banPickStep"));
    ModSkinOffField[4] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("CHeroSelectBanPickSystem"),oxorany("banHeroIDList"));
    ModSkinOffField[5] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("CHeroSelectBaseSystem"),oxorany("m_isInHeroSelectState"));
    
    ModRankOffField[0] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"),oxorany("m_rankScore"));
    ModRankOffField[1] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"),oxorany("m_rankHistoryHighestScore"));
    ModRankOffField[2] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"),oxorany("m_rankShowGrade"));
    ModRankOffField[3] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"),oxorany("m_rankHistoryHighestShowGrade"));
    ModRankOffField[4] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"),oxorany("m_rankSeasonHighestShowGrade"));
    ModRankOffField[5] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"),oxorany("mTotalReachRankSTimes"));
    ModRankOffField[6] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"),oxorany("m_rankClass"));
    ModRankOffField[7] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"),oxorany("m_rankHistoryHighestClass"));
    ModRankOffField[8] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"),oxorany("m_rankSeasonHighestClass"));
    ModRankOffField[9] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"),oxorany("m_Name"));
    ModRankOffField[10] = getFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"), oxorany("CLadderSystem"),oxorany("currentRankDetail"));
    ModRankOffField[11] = getFieldOffset(oxorany("AovTdr.dll"),oxorany("CSProtocol"), oxorany("COMDT_RANKDETAIL"),oxorany("dwScore"));
    

    Antiban[0] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LFrameSynchr"),oxorany("UpdateFrameLater"), 0);
    Antiban[1] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LSynchrReport"),oxorany("EnqueHashValueByFrameNum"), 2);
    Antiban[2] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LSynchrReport"),oxorany("OnHashCheckRsp"), 1);
    Antiban[3] = get_offset(oxorany("Project_d.dll"),oxorany(""),oxorany("FirebasePush"),oxorany("handleReportInfoResult"), 1);
    Antiban[4] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Statistics"),oxorany("BattleStatistic"),oxorany("CreateReportData"), 5);
    Antiban[5] = get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Statistics"),oxorany("BattleStatistic"),oxorany("CreateDestroyReportData"), 3);
    Antiban[6] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("LobbyMsgHandler"),oxorany("HandleGameSettle"), 4);
   

	Skill[5] = get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("CSkillButtonManager"),oxorany("SkillButtonDown"), 3);


    GetZoomRate = (float (*)(void*))((uintptr_t)offset[4]);
    //LoadJsonFromGitHub();
    //LoadModNutFromGitHub();
    OnCameraHeightChanged = (void (*)(void*))((uintptr_t)offset[6]);

    get_talentSystem = (void* (*)(void*))((uintptr_t)get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"), oxorany("LSkillComponent"),oxorany("get_talentSystem"), 0));
    GetGoldCoinInBattle = (int (*)(void*))((uintptr_t)get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"), oxorany("ValuePropertyComponent"),oxorany("GetGoldCoinInBattle"), 0));
    GetEquipActiveSkillCD = (int (*)(void*, int))((uintptr_t)get_offset(oxorany("Project_d.dll"),oxorany("Kyrios.Actor"),oxorany("VEquipLinkerComponent"),oxorany("GetEquipActiveSkillCD"),1));
    GetTalentCDTime = (int (*)(void*, int))((uintptr_t)get_offset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("TalentSystem"),oxorany("GetTalentCDTime"), 1));
    SendBuyEquipFrameCommand = (void (*)(void*,int,bool))((uintptr_t)get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("CBattleEquipSystem"),oxorany("SendBuyEquipFrameCommand"),2));
    SendSellEquipFrameCommand = (void (*)(void*,int))((uintptr_t)get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("CBattleEquipSystem"),oxorany("SendSellEquipFrameCommand"),1));
    SendPlayerChoseEquipSkillCommand = (void (*)(void*,int))((uintptr_t)get_offset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("CBattleEquipSystem"),oxorany("SendPlayerChoseEquipSkillCommand"),1));
	
    _SkillButtonDown = (void (*)(void *, void*, int, Vector2))((uintptr_t)Skill[5]);
    SendEmojiDanceCommandByIndex = (void (*)(void*, int)) get_offset(("Project_d.dll"), ("Assets.Scripts.GameLogic"), ("EffectPlayComponent"), ("SendEmojiDanceCommandByIndex"), 1);

    get_IsHostProfile = (bool (*)())((uintptr_t)offset[11]);//kk
    SetVisible = (bool (*)(void *, COM_PLAYERCAMP, bool, bool))((uintptr_t)offset[0]);
    IsSkinAvailable = (bool (*)(int))((uintptr_t)ModSkin[0]);
    CanUseSkin = (bool (*)(void *,int,int))((uintptr_t)ModSkin[1]);
    GetHeroWearSkinId = (int (*)(void *,int))((uintptr_t)ModSkin[2]);
    RefreshHeroPanel = (void (*)(void *,bool,bool,bool))((uintptr_t)ModSkin[5]);
    old_unpack = (int32_t (*)(void *, void *, int32_t))((uintptr_t)ModSkin[6]);
    //IsOpenButton = (bool (*)())((uintptr_t)ModSkin[8]);
   // get_PersonalBtnId = (int (*)())((uintptr_t)ModSkin[9]);
    get_actorManager = (void* (*)())((uintptr_t)Esp[0]); 
    get_TheMinimapSys = (void* (*)(void*))((uintptr_t)Esp[1]);
    CvtWorld2UISM = (Vector2(*)(void *,Vector3))((uintptr_t)Esp[2]);
    CvtWorld2UIBM = (Vector2(*)(void *,Vector3))((uintptr_t)Esp[3]);
    GetHero_Icon = (MonoString* (*)(void *,int,int))((uintptr_t)Esp[4]);
    get_playerCenter = (void* (*)())((uintptr_t)Esp[5]);
    get_VHostLogic = (void* (*)())((uintptr_t)Esp[6]);
    GetCurLvelContext = (void* (*)(void *))((uintptr_t)Esp[7]);
    GetGameRoomType = (int (*)(void *))((uintptr_t)Esp[8]);
    Reqskill = (bool (*)(void *))((uintptr_t)Esp[9]);
    Reqskill2 = (bool (*)(void *,bool))((uintptr_t)Esp[10]);
    get_IsCharging = (bool (*)(void *))((uintptr_t)Esp[11]);
    get_FightForm = (void* (*)(void *))((uintptr_t)Esp[12]);
    CanRequestSkill = (bool (*)(void*,int))((uintptr_t)Esp[13]);
    RequestUseSkillSlot = (bool (*)(void*,int, int, uint, int))((uintptr_t)Esp[14]);
    SetPlayerName = (void (*)(void*, MonoString*, MonoString*, bool, MonoString*))((uintptr_t)Esp[15]);
    GetSelfCamp = (int (*)(void *))((uintptr_t)Esp[16]);
    GetTeamHeroCommonInfoList = (List<void**>* (*)(void *,int))((uintptr_t)Esp[17]);
    ForceKillCrystal = (void (*)(int))((uintptr_t)Esp[18]);
    GetMasterRoleInfo = (void* (*)(void *))((uintptr_t)Esp[19]);
    FindObjectOfType = (void* (*)(void*))((uintptr_t)Esp[20]);
    GetTypeName = (void* (*)(MonoString*))((uintptr_t)Esp[21]);
    FindObjectsOfType = (Array<void*>* (*)(void*))((uintptr_t)Esp[22]);
    ToStringUnity = (MonoString* (*)(void*))((uintptr_t)Esp[23]);
    FindObjectsOfTypeAll = (Array<void*>* (*)(void*))((uintptr_t)Esp[24]);
    assemblyLoad = (void* (*)(MonoString*))((uintptr_t)Esp[25]);
    assemblyGetType = (void* (*)(void*,MonoString*))((uintptr_t)Esp[26]);
    Object_get_name = (MonoString* (*)(void*))((uintptr_t)Esp[27]);
    get_activeInHierarchy = (bool (*)(void*))((uintptr_t)Esp[28]);
    GetComponents = (Array<void*>* (*)(void*,void*,bool,bool,bool,bool,void*))((uintptr_t)Esp[29]);
    GetComponent = (void* (*)(void*,void*))((uintptr_t)Esp[30]);
    GetComponentInChildren = (void* (*)(void*,void*))((uintptr_t)Esp[31]);
    GetComponentInParent = (void* (*)(void*,void*))((uintptr_t)Esp[32]);
    GetOffsetOfInstanceIDInCPlusPlusObject = (int (*)())((uintptr_t)Esp[33]);
    get_text = (MonoString* (*)(void*))((uintptr_t)Esp[34]);
    GetInstanceID = (void* (*)(void*))((uintptr_t)Esp[35]);
    //get_cameraToWorldMatrix = (Matrix (*)(void*))((uintptr_t)Esp[36]);
    get_SkillID = (int (*)(void*))((uintptr_t)Esp[39]);
    GetGameTime = (int (*)(void*))((uintptr_t)Esp[40]);
    CalcDirectionByTouchPosition = (VInt3 (*)(void*,Vector2,Vector2))((uintptr_t)Esp[41]);
    
    ActorLinker_IsHostPlayer = (bool (*)(void *))((uintptr_t)ActorLinkerOff[0]);     
    ActorLinker_IsHostCamp = (bool (*)(void *))((uintptr_t)ActorLinkerOff[1]);  
    ActorLinker_ActorTypeDef = (int (*)(void *))((uintptr_t)ActorLinkerOff[2]);    
    ActorLinker_COM_PLAYERCAMP = (int (*)(void *))((uintptr_t)ActorLinkerOff[3]); 
    ActorLinker_getPosition = (Vector3(*)(void *))((uintptr_t)ActorLinkerOff[4]);
    ActorLinker_get_ObjID = (int (*)(void *))((uintptr_t)ActorLinkerOff[6]); 
    ActorLinker_get_bVisible = (bool (*)(void *))((uintptr_t)ActorLinkerOff[7]);
    ActorLinker_AsHero = (void*(*)(void*))((uintptr_t)ActorLinkerOff[8]);
    ActorLinker_get_playerId = (int (*)(void *))((uintptr_t)ActorLinkerOff[9]);
    get_ValueCompChangeActor = (void* (*)(void*))((uintptr_t)ActorLinkerOff[10]);
    ValueLinkerComponent_get_actorHp = (int (*)(void *))((uintptr_t)ActorLinkerOff[11]);
    ValueLinkerComponent_get_actorHpTotal = (int (*)(void *))((uintptr_t)ActorLinkerOff[12]);
    ValueLinkerComponent_get_actorSoulLevel = (int (*)(void*))((uintptr_t)ActorLinkerOff[13]);

    LActorRoot_get_forward = (VInt3(*)(void *))((uintptr_t)LActorRootOff[0]);
    LActorRoot_get_location = (VInt3(*)(void *))((uintptr_t)LActorRootOff[1]); 
    LActorRoot_LHeroWrapper = (void* (*)(void *))((uintptr_t)LActorRootOff[2]);
    LActorRoot_COM_PLAYERCAMP = (int (*)(void *))((uintptr_t)LActorRootOff[3]); 
    LActorRoot_get_bActive = (bool (*)(void *))((uintptr_t)LActorRootOff[4]); 
    LActorRoot_get_ObjID = (int (*)(void *))((uintptr_t)LActorRootOff[5]);
    LObjWrapper_get_IsDeadState = (bool (*)(void *))((uintptr_t)LActorRootOff[6]); 
    LObjWrapper_IsAutoAI = (bool (*)(void *))((uintptr_t)LActorRootOff[7]);
    ValuePropertyComponent_get_actorHp = (int (*)(void *))((uintptr_t)LActorRootOff[8]);    
    ValuePropertyComponent_get_actorHpTotal = (int (*)(void *))((uintptr_t)LActorRootOff[9]); 
    LActorRoot_get_PlayerMovement = (void* (*)(void*))((uintptr_t)LActorRootOff[10]);
    LEquipComponent_BuyEquip = (void (*)(void*,int,bool,bool))((uintptr_t)LActorRootOff[11]);
    LEquipComponent_SellEquip = (void (*)(void*,int))((uintptr_t)LActorRootOff[12]);
    LEquipComponent_GetEquips = (void* (*)(void*))((uintptr_t)LActorRootOff[13]);    
    ValuePropertyComponent_get_actorSoulLevel = (int (*)(void *))((uintptr_t)LActorRootOff[14]); 
    ValuePropertyComponent_get_actorEp = (int (*)(void *))((uintptr_t)LActorRootOff[15]);    
    ValuePropertyComponent_get_actorEpTotal = (int (*)(void *))((uintptr_t)LActorRootOff[16]); 
    GetSkillSlot = (void* (*)(void*,int))((uintptr_t)LActorRootOff[17]);
    get_RealSkillObj = (void* (*)(void*))((uintptr_t)LActorRootOff[18]);
    get_speed = (int (*)(void*))((uintptr_t)LActorRootOff[19]);
    get_battleLogic = (void* (*)(void*))((uintptr_t)LActorRootOff[20]);


    //CBattleSystem_Update = (void* (*)(void*))((uintptr_t)LActorRootOff[21]);￼

    CBattleSystem_Update = (void* (*)(void*))((uintptr_t)LActorRootOff[21]);

    get_main = (void* (*)())((uintptr_t)Cam[0]);
    WorldToScreenPoint = (Vector3 (*)(void*, Vector3))((uintptr_t)Cam[1]);
    WorldToViewportPoint = (Vector3 (*)(void*, Vector3))((uintptr_t)Cam[2]);
    get_fieldOfView = (float (*)(void*))((uintptr_t)Cam[3]);
    set_fieldOfView = (void (*)(void*, float))((uintptr_t)Cam[4]);

    
   // CreateReportData = (void* (*)(void*, uint, unsigned long long, bool, bool, bool))((uintptr_t)Antiban[4]);
   // CreateDestroyReportData = (void (*)(void*, uint, void*, bool))((uintptr_t)Antiban[5]);
   // HandleGameSettle = (void (*)(void*,bool, bool, Byte, void*))((uintptr_t)Antiban[6]);


    daloadoffset = true;
    });
}