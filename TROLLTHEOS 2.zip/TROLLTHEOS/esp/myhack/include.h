
#include "LoadView/Includes.h"

#include <iostream>
#include <fstream>
#include <sys/types.h>
#include <sys/sysctl.h>
#include <Foundation/Foundation.h>
#include <libgen.h>
#include <mach-o/dyld.h>
#include <mach-o/fat.h>
#include <mach-o/loader.h>
#include <mach/vm_page_size.h>
#include <unistd.h>
#include <array>
#include <deque>
#include <map>
#include <vector>
#include <algorithm>
#include <set>
#include <string>
#import <unordered_map>
#include <CoreFoundation/CoreFoundation.h>
#include <limits>
#import <UIKit/UIKit.h>
#include <chrono>



#import "imgui/stb_image.h"
#import "imgui/imgui_toggle.h"
#import "imgui/imgui_additional.h"
#import "imgui/bdvt.h"
#import "imgui/json.hpp"

#import "../Utils/hack/Function.h"
#import "../Utils/EspManager.h"
#import "../Utils/hack/VInt3.h"
#import "../Utils/hack/Vector2.h"
#import "../Utils/hack/Vector3.h"
#import "../Utils/hack/Quaternion.h"
#import "../Utils/ESP.h"
#import "../Utils/Unity.h"

#import "../hok/NakanoYotsuba.h"

#import "mylib/Il2cpp.h"
#import "mylib/mahoa.h"
#import "mylib/stb_image.h"
#import "../mylib/CSProtocol.h"
#import "../mylib/MonoString.h"
#import "../mylib/hook.h"
#import "../mylib/Herolib.h"
#include "mylib/NSLOGS.h"


#include "imgui/fonts/Icon.h"
#include "imgui/fonts/Iconcpp.h"
#include "imgui/fonts/ico_font.h"
#include "imgui/fonts/zzz.h"
#include "imgui/fonts/ProFont.h"

#include "Manager/FixRSC/UiFixPanel.h"
#include "Manager/FixRSC/RestoreBackups.h"
using namespace restore_utils;


#import <sstream>
using namespace std::chrono;
using namespace std;

#define STB_IMAGE_IMPLEMENTATION
#define Color1 ImVec4(160.0f / 255.0f, 200.0f / 255.0f, 0.0f / 255.0f, 1.0f)
#define Color2 ImVec4(120.0f / 255.0f, 120.0f / 255.0f, 120.0f / 255.0f, 1.0f)
#define Color3 ImVec4(0.0f / 255.0f, 0.0f / 255.0f, 0.0f / 255.0f, 1.0f)
#define Color4 ImVec4(0.38f, 0.38f, 0.38f, 1.0f)
#define Color5 ImVec4(155.0f / 255.0f, 192.0f / 255.0f, 0.0f / 255.0f, 1.0f)
#define Color6 ImVec4(205.0f / 255.0f, 250.0f / 255.0f, 0.0f / 255.0f, 1.0f)
#define Color7 ImVec4(160.0f / 255.0f, 160.0f / 255.0f, 160.0f / 255.0f, 1.0f)
#define Color8 ImVec4(50.0f / 255.0f, 50.0f / 255.0f, 50.0f / 255.0f, 1.0f)
#define Color9 ImVec4(0.38f, 0.38f, 0.38f, 1.00f)
#define Color10 ImColor(205 / 255.0f,249 / 255.0f, 0 / 255.0f)
#define Colorwhite ImVec4(1.0f, 1.0f, 1.0f, 1.0f)

#define timer(sec) dispatch_after(dispatch_time(DISPATCH_TIME_NOW, sec * NSEC_PER_SEC), dispatch_get_main_queue(), ^

#define iPhonePlus ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1242, 2208), [[UIScreen mainScreen] currentMode].size) : NO)

#define kWidth [UIScreen mainScreen].bounds.size.width
#define kHeight [UIScreen mainScreen].bounds.size.height
#define kWidth  [UIScreen mainScreen].bounds.size.width
#define kHeight [UIScreen mainScreen].bounds.size.height
#define kScale [UIScreen mainScreen].nativeScale
#define screenHeight [UIScreen mainScreen].bounds.size.height
#define screenWidth [UIScreen mainScreen].bounds.size.width


int solan = 0;
int goldcoin = 0;
bool giap = true;
bool bangsuongactive = true;
bool liem = true;
bool thuongkhung = true;
bool nhamthuan = true;
bool hercules = true;
int lastId = -1;
int stt = 0;
bool fullslot = false;
bool checktime = false;
uint16_t ItemID[6];
bool muaitem = false;
bool doiitem = false;

int skillIdCd;

static auto lastCall = std::chrono::steady_clock::now();
static int step = 0;
static size_t currentIndex = 0;
static void* lastActorManager = NULL;
static std::vector<void*> effectQueue;
static std::vector<void*> effectQueue2;

int delayspam = 10;
static int spamMode = 0;
static bool spamemoji = false;
static bool Bhideemoji = false;
bool daloadoffset = false;
int counttime = 0;
static int refreshRate = 0;
NSTimer *updateTimer;
ImFont *_espFont;
ImFont *_iconFont;

static bool MenDeal = false;
UIWindow *mainWindow1;
static ImGuiDrawView *sharedInstance = nil;
NSUserDefaults *saveSetting = [NSUserDefaults standardUserDefaults];
void* CBattle_Instance = nullptr;
void* CRoleInfoManager_Instance = nullptr;
void* GameInput_Instance = nullptr;
void* LLogicCore_Instance = nullptr;
void* LBattleLogic = nullptr;

void* BattleSystem = nullptr;
void* LGameActorMgr_Instance = nullptr;
void* BattleLogic_Instance = nullptr;
bool m_isInHeroSelectState = false;
void *Req5 = nullptr;
void *Req6 = nullptr;
void *Req0 = nullptr;
void *Req1 = nullptr;
void *Req2 = nullptr;
void *Req3 = nullptr;
void *Req9 = nullptr;
int Req6_slotype = 0;
bool BugSkillDistance = false;
bool CancelAnimationElsu = false;
bool hookcancel = false;
float debugDistanceSub = 0;
void* Skill[50];

void* hideemoji;
bool isHookedEmoji = false;

Vector3 useSkillDirection1,useSkillDirection2,useSkillDirection3;
bool showlsd = true;
bool fixskin = false;
bool HackMap = true;
bool HackSao = false;
bool wingame = false;
bool Hacksaoenable = false;
bool ingame = false;
bool resetcam = false;
bool isFirst = true;
bool isFirstrun = true;
bool hookaim = false;
bool hookcamera = false;
bool Camstraight = false;    
bool load_offset = false;
int ActiveTab = 1;
bool EspMonster = false;
bool IgnoreInvisibleMon = false;
bool showMinimapMon = false;
bool showMonsterHp = false;
bool VipMon = false;
bool ESPEnable = true;
bool StreamerMode = false;
bool PlayerLine = false;
bool PlayerTalent = false;
bool CustomIconBT = false;
bool AimbotNew = false;
float CustomX = 1.0f;
float CustomY = 1.0f;
bool Drawicon = false;
static ImVec2 manhinh;
bool customIcon = false;
float customIconSize = 1.0f;
float boxWidthScreen = 0;
float customIconPOS = 0;
float iconradius =0;
bool PlayerBox = false;
bool Circle3D = false;
bool unlocknut = true;
bool unlockskin = false;
int heroid = 0;
int Skinid = 0;
int heroid2 = 0;
int skinid2 = 0;
bool PlayerDistance = false;
bool PlayerName = false;
bool showMinimap = false;
bool hiencooldowns = false;
bool PlayerAlert = false;
bool IgnoreInvisible = false;
float MinimapX = 1;
float MinimapY = 1;
float MinimapSizeX = 1;
float MinimapSizeY = 1;
bool AimbotEnable = false;
bool Aimhook = false;
bool MANUALAIM = false;
bool enableSkill1 = false;
bool enableSkill2 = false;
bool enableSkill3 = false;
bool RangeSkill = false;
float speedSkill1 = 1.0f;
float speedSkill2 = 1.0f;
float speedSkill3 = 1.0f;
float RangeSkill1 = 1.0f;
float RangeSkill2 = 1.0f;
float RangeSkill3 = 1.0f;
bool Rangeauto = false;
float RangeSkill1auto = 1.0f;
float RangeSkill2auto = 1.0f;
float RangeSkill3auto = 1.0f;
bool AutoBP = false;
bool AutoBS = false;
bool AutoTT = false;
bool rongta = false;
int currentTimer = 0;
bool CeaserOnly = false;
bool SliderCamera = false;
float Camera = 1.0f;
bool lockcam = false;
float AutoBPHp = 13.7f;
float AutoBSHp = 50.0f;
size_t MinimapOffField[10];
void* Cam[10];
void* offset[50];
void* Esp[50];
size_t EspField[50];
void* ActorLinkerOff[50];
size_t ActorLinkerOffField[50];
void* LActorRootOff[50];
size_t LActorRootOffField[50];
void* ModSkin[20];
size_t ModSkinOffField[20];
size_t ModRankOffField[20];
void* Antiban[20]; 
int MapType = 1;
bool ManualMinimap = false;
Vector2 MinimapOrg;
Vector2 MinimapPos;
Vector2 MinimapSizeImGUi;
Vector2 BigmapSizeImGUi;
Vector2 BigmapPos;
Vector2 MinimapSize;
Vector2 BigmapSize;
Vector2 minimapPos;
Vector2 bigmapPos;
float MinimapCenterX;
float MinimapCenterY;
float BigmapCenterX;
float BigmapCenterY;
float MinimapScale = 1;
int roomtype = 0;
bool isFliped = false;
int settingmode = 1;
int myTeam = 1;
int KillMode, NameMode = 0, LinhMode = 0;
bool KillNotify = true;
int ButtonModeID = 0;
int selectedValue1 = 0;
int ButtonID;
int mode = 0, aimType = 0, drawType = 2, skillSlot;
bool fakerank = false;
int sosao = 1;
int rankht = 1;
int topnumber = 1;
bool ChangeName = false;
int currentHeroId = 0;
int currentSkinId = 0; 
std::string customname = "Minh Khang Đẹp Trai";
bool AutoWin = false;
bool AntiBandAcc = true;
map<uint64_t, Vector3> previousEnemyPositions;
bool isHookedSkin = false;
bool isHookedButton = false;
bool isHackMap = false;
bool isHooked = true;
bool CheckAntiBand = false;

float lerp(float a, float b, float t) {
    return a + t * (b - a);
}

ImVec4 lerp(const ImVec4& a, const ImVec4& b, float t) {
    return ImVec4(lerp(a.x, b.x, t), lerp(a.y, b.y, t), lerp(a.z, b.z, t), lerp(a.w, b.w, t));
}

monoString *CreateMonoString(const char *str) {
    int length = (int)strlen(str);
    int startIndex = 0;
    monoString *(*String_CreateString)(void *instance, const char *str, int startIndex, int length) = (monoString *(*)(void *, const char *, int, int))((uintptr_t)offset[14]);
    return String_CreateString(NULL, str, startIndex, length);
}
CSProtocol *protocol = [[CSProtocol alloc] init];

// Biến màu từ code1
const ImVec4 neonPink = ImVec4(1.00f, 0.00f, 0.50f, 1.00f);
const ImVec4 neonCyan = ImVec4(0.00f, 1.00f, 1.00f, 1.00f);
const ImVec4 neonGreen = ImVec4(0.00f, 1.00f, 0.30f, 1.00f);
const ImVec4 neonBlue = ImVec4(0.20f, 0.50f, 1.00f, 1.00f);
const ImVec4 darkBackground = ImVec4(0.05f, 0.05f, 0.08f, 0.98f);
const ImVec4 midBackground = ImVec4(0.10f, 0.10f, 0.15f, 0.98f);
const ImVec4 lightBackground = ImVec4(0.15f, 0.15f, 0.20f, 1.00f);
const ImVec4 greyText = ImVec4(0.60f, 0.60f, 0.65f, 1.00f);
const ImVec4 whiteText = ImVec4(0.95f, 0.95f, 1.00f, 1.00f);
const ImVec4 brightAccent = neonCyan;
const ImVec4 secondaryAccent = neonPink;

namespace BrandTheme {
    const ImVec4 BackgroundDark = ImVec4(0.08f, 0.09f, 0.11f, 0.98f);
    const ImVec4 BackgroundMedium = ImVec4(0.12f, 0.13f, 0.16f, 0.98f); 
    const ImVec4 BackgroundLight = ImVec4(0.16f, 0.17f, 0.20f, 1.00f);
    const ImVec4 FrameBg = ImVec4(0.10f, 0.11f, 0.13f, 1.00f);   
    const ImVec4 FrameBgHovered = ImVec4(0.14f, 0.15f, 0.18f, 1.00f); 
    const ImVec4 FrameBgActive = ImVec4(0.18f, 0.19f, 0.22f, 1.00f); 
    const ImVec4 TitleBg = BackgroundDark;                           
    const ImVec4 TitleBgActive = ImVec4(0.0f, 0.45f, 0.48f, 1.00f);   
    const ImVec4 TitleBgCollapsed = BackgroundDark;
    const ImVec4 AccentColor = ImVec4(0.0f, 0.55f, 0.60f, 1.00f);    
    const ImVec4 AccentHover = ImVec4(0.0f, 0.65f, 0.70f, 1.00f);   
    const ImVec4 AccentActive = ImVec4(0.0f, 0.75f, 0.80f, 1.00f);     
    const ImVec4 SecondaryAccent = ImVec4(0.85f, 0.35f, 0.20f, 1.00f);
    const ImVec4 SecondaryHover = ImVec4(0.90f, 0.40f, 0.25f, 1.00f);
    const ImVec4 SecondaryActive = ImVec4(0.95f, 0.45f, 0.30f, 1.00f);
    const ImVec4 TextPrimary = ImVec4(0.90f, 0.91f, 0.92f, 1.00f);  
    const ImVec4 TextSecondary = ImVec4(0.65f, 0.66f, 0.68f, 1.00f);  
    const ImVec4 TextDisabled = ImVec4(0.45f, 0.46f, 0.48f, 1.00f); 
    const ImVec4 TextHeader = AccentColor; 
    const float BaseRounding = 8.0f;        
    const float FrameRounding = 6.0f;
    const float GrabRounding = 4.0f;
    const float WindowBorderSize = 0.0f;    
    const float FrameBorderSize = 1.0f;    
    const ImVec2 ItemSpacing = ImVec2(8, 6);   
    const ImVec2 ItemInnerSpacing = ImVec2(6, 6);
    const float ScrollbarSize = 12.0f;
    const float GrabMinSize = 12.0f;
}


void StyleImGui(){
    ImGuiStyle& style = ImGui::GetStyle();
    ImVec4* colors = style.Colors;

    colors[ImGuiCol_Text] = BrandTheme::TextPrimary;
    colors[ImGuiCol_TextDisabled] = BrandTheme::TextDisabled;
    colors[ImGuiCol_WindowBg] = BrandTheme::BackgroundDark;
    colors[ImGuiCol_ChildBg] = ImVec4(0,0,0,0); 
    colors[ImGuiCol_PopupBg] = BrandTheme::BackgroundMedium;
    colors[ImGuiCol_Border] = BrandTheme::FrameBgHovered;
    colors[ImGuiCol_BorderShadow] = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
    colors[ImGuiCol_FrameBg] = BrandTheme::FrameBg;
    colors[ImGuiCol_FrameBgHovered] = BrandTheme::FrameBgHovered;
    colors[ImGuiCol_FrameBgActive] = BrandTheme::FrameBgActive;
    colors[ImGuiCol_TitleBg] = BrandTheme::TitleBg;
    colors[ImGuiCol_TitleBgActive] = BrandTheme::TitleBgActive;
    colors[ImGuiCol_TitleBgCollapsed] = BrandTheme::TitleBgCollapsed;
    colors[ImGuiCol_MenuBarBg] = BrandTheme::BackgroundMedium;
    colors[ImGuiCol_ScrollbarBg] = BrandTheme::BackgroundDark;
    colors[ImGuiCol_ScrollbarGrab] = BrandTheme::FrameBgHovered;
    colors[ImGuiCol_ScrollbarGrabHovered] = BrandTheme::FrameBgActive;
    colors[ImGuiCol_ScrollbarGrabActive] = BrandTheme::AccentColor;
    colors[ImGuiCol_CheckMark] = BrandTheme::AccentColor;
    colors[ImGuiCol_SliderGrab] = BrandTheme::AccentColor;
    colors[ImGuiCol_SliderGrabActive] = BrandTheme::AccentActive;
    colors[ImGuiCol_Button] = BrandTheme::AccentColor; 
    colors[ImGuiCol_ButtonHovered] = BrandTheme::AccentHover;
    colors[ImGuiCol_ButtonActive] = BrandTheme::AccentActive;
    colors[ImGuiCol_Header] = BrandTheme::FrameBg;
    colors[ImGuiCol_HeaderHovered] = BrandTheme::FrameBgHovered;
    colors[ImGuiCol_HeaderActive] = BrandTheme::AccentColor;
    colors[ImGuiCol_Separator] = BrandTheme::FrameBgHovered;
    colors[ImGuiCol_SeparatorHovered] = BrandTheme::AccentColor;
    colors[ImGuiCol_SeparatorActive] = BrandTheme::AccentActive;
    colors[ImGuiCol_ResizeGrip] = BrandTheme::FrameBg;
    colors[ImGuiCol_ResizeGripHovered] = BrandTheme::FrameBgHovered;
    colors[ImGuiCol_ResizeGripActive] = BrandTheme::AccentColor;
    colors[ImGuiCol_Tab] = BrandTheme::FrameBg;
    colors[ImGuiCol_TabHovered] = BrandTheme::FrameBgHovered;
    colors[ImGuiCol_TabActive] = BrandTheme::AccentColor;
    colors[ImGuiCol_TabUnfocused] = BrandTheme::FrameBg;
    colors[ImGuiCol_TabUnfocusedActive] = BrandTheme::FrameBgHovered; 
    colors[ImGuiCol_PlotLines] = BrandTheme::AccentColor;
    colors[ImGuiCol_PlotLinesHovered] = BrandTheme::AccentHover;
    colors[ImGuiCol_PlotHistogram] = BrandTheme::AccentColor;
    colors[ImGuiCol_PlotHistogramHovered] = BrandTheme::AccentHover;
    colors[ImGuiCol_TableHeaderBg] = BrandTheme::FrameBg;
    colors[ImGuiCol_TableBorderStrong] = BrandTheme::BackgroundLight; 
    colors[ImGuiCol_TableBorderLight] = BrandTheme::FrameBgHovered;  
    colors[ImGuiCol_TableRowBg] = ImVec4(0.00f, 0.00f, 0.00f, 0.00f); 
    colors[ImGuiCol_TableRowBgAlt] = ImVec4(1.00f, 1.00f, 1.00f, 0.04f);
    colors[ImGuiCol_TextSelectedBg] = ImVec4(BrandTheme::AccentColor.x, BrandTheme::AccentColor.y, BrandTheme::AccentColor.z, 0.35f);
    colors[ImGuiCol_DragDropTarget] = ImVec4(BrandTheme::AccentColor.x, BrandTheme::AccentColor.y, BrandTheme::AccentColor.z, 0.90f);
    colors[ImGuiCol_NavHighlight] = BrandTheme::AccentColor; 
    colors[ImGuiCol_NavWindowingHighlight] = ImVec4(BrandTheme::AccentColor.x, BrandTheme::AccentColor.y, BrandTheme::AccentColor.z, 0.70f);
    colors[ImGuiCol_NavWindowingDimBg] = ImVec4(0.20f, 0.20f, 0.20f, 0.20f);
    colors[ImGuiCol_ModalWindowDimBg] = ImVec4(BrandTheme::BackgroundDark.x, BrandTheme::BackgroundDark.y, BrandTheme::BackgroundDark.z, 0.6f);

    style.WindowRounding = BrandTheme::BaseRounding;
    style.FrameRounding = BrandTheme::FrameRounding;
    style.PopupRounding = BrandTheme::FrameRounding; 
    style.ScrollbarRounding = BrandTheme::FrameRounding;
    style.GrabRounding = BrandTheme::GrabRounding;
    style.TabRounding = BrandTheme::FrameRounding; 
    style.ChildRounding = BrandTheme::BaseRounding * 0.5f; 

    style.WindowBorderSize = BrandTheme::WindowBorderSize;
    style.FrameBorderSize = BrandTheme::FrameBorderSize;
    style.PopupBorderSize = BrandTheme::FrameBorderSize; 
    style.ChildBorderSize = 0.0f;
    style.ScrollbarSize = BrandTheme::ScrollbarSize;
    style.GrabMinSize = BrandTheme::GrabMinSize;
    style.Alpha = 1.0f;
}

void StyleImGuiMinhKhang()
{
    ImGuiStyle& style = ImGui::GetStyle();
    ImVec4* colors = style.Colors;

    // ===== GLASS BACKGROUND (WINDOW = NỀN = CHILD = POPUP) =====
    ImVec4 glassBg = ImVec4(0.05f, 0.05f, 0.06f, 0.92f);

    // ===== TAB HỒNG SÁNG =====
    ImVec4 tabBg     = ImVec4(0.95f, 0.35f, 0.70f, 0.90f);
    ImVec4 tabHover  = ImVec4(1.00f, 0.45f, 0.78f, 1.00f);
    ImVec4 tabActive = ImVec4(1.00f, 0.25f, 0.65f, 1.00f);

    // ===== BUTTON GLASS + VIỀN TRẮNG =====
    ImVec4 buttonBg     = ImVec4(0.08f, 0.08f, 0.10f, 0.55f);
    ImVec4 buttonHover  = ImVec4(0.12f, 0.12f, 0.14f, 0.75f);
    ImVec4 buttonActive = ImVec4(0.15f, 0.15f, 0.18f, 0.85f);
    ImVec4 whiteBorder  = ImVec4(1.0f, 1.0f, 1.0f, 0.35f);

    // ===== SLIDER =====
    ImVec4 frameBg       = ImVec4(0.15f, 0.15f, 0.18f, 1.0f);
    ImVec4 sliderGrab    = ImVec4(0.35f, 0.65f, 1.0f, 1.0f);
    ImVec4 sliderGrabAct = ImVec4(0.20f, 0.50f, 0.95f, 1.0f);

    // ===== TEXT =====
    colors[ImGuiCol_Text]         = ImVec4(0.95f, 0.95f, 0.97f, 1.0f);
    colors[ImGuiCol_TextDisabled] = ImVec4(0.55f, 0.55f, 0.6f, 1.0f);

    // ===== WINDOW / BACKGROUND (DÙNG CHUNG 1 MÀU) =====
    colors[ImGuiCol_WindowBg]    = glassBg;
    colors[ImGuiCol_ChildBg]     = glassBg;
    colors[ImGuiCol_PopupBg]     = glassBg;
    colors[ImGuiCol_ScrollbarBg] = glassBg;

    colors[ImGuiCol_Border]        = whiteBorder;
    colors[ImGuiCol_BorderShadow] = ImVec4(0,0,0,0);

    // ===== BUTTON =====
    colors[ImGuiCol_Button]        = buttonBg;
    colors[ImGuiCol_ButtonHovered] = buttonHover;
    colors[ImGuiCol_ButtonActive]  = buttonActive;

    // ===== FRAME / SLIDER TRACK =====
    colors[ImGuiCol_FrameBg]        = frameBg;
    colors[ImGuiCol_FrameBgHovered] = ImVec4(0.18f, 0.18f, 0.22f, 1.0f);
    colors[ImGuiCol_FrameBgActive]  = ImVec4(0.22f, 0.22f, 0.28f, 1.0f);

    colors[ImGuiCol_SliderGrab]       = sliderGrab;
    colors[ImGuiCol_SliderGrabActive] = sliderGrabAct;

    // ===== CHECKBOX =====
    colors[ImGuiCol_CheckMark] = sliderGrab;

    // ===== TAB / HEADER =====
    colors[ImGuiCol_Header]        = tabBg;
    colors[ImGuiCol_HeaderHovered] = tabHover;
    colors[ImGuiCol_HeaderActive]  = tabActive;

    colors[ImGuiCol_Tab]                = tabBg;
    colors[ImGuiCol_TabHovered]         = tabHover;
    colors[ImGuiCol_TabActive]          = tabActive;
    colors[ImGuiCol_TabUnfocused]       = ImVec4(0.15f, 0.10f, 0.12f, 0.8f);
    colors[ImGuiCol_TabUnfocusedActive] = tabBg;

    // ===== SCROLLBAR =====
    colors[ImGuiCol_ScrollbarGrab]        = ImVec4(0.25f,0.25f,0.30f,1.0f);
    colors[ImGuiCol_ScrollbarGrabHovered] = tabHover;
    colors[ImGuiCol_ScrollbarGrabActive]  = tabActive;

    // ===== RESIZE =====
    colors[ImGuiCol_ResizeGrip]        = tabActive;
    colors[ImGuiCol_ResizeGripHovered] = tabHover;
    colors[ImGuiCol_ResizeGripActive]  = sliderGrabAct;

    // ================= GEOMETRY (VUÔNG BO GÓC) =================
    style.WindowRounding    = 14.0f;
    style.ChildRounding     = 14.0f;
    style.FrameRounding     = 8.0f;   // vuông bo góc
    style.GrabRounding      = 6.0f;
    style.PopupRounding     = 14.0f;
    style.TabRounding       = 10.0f;
    style.ScrollbarRounding = 10.0f;

    style.FramePadding     = ImVec2(14, 8);
    style.ItemSpacing      = ImVec2(12, 10);
    style.ItemInnerSpacing = ImVec2(8, 6);

    style.WindowBorderSize = 1.0f;
    style.FrameBorderSize  = 1.4f;   // viền trắng nổi
    style.PopupBorderSize  = 1.0f;

    style.ScrollbarSize    = 14.0f;
    style.GrabMinSize      = 12.0f;

    style.WindowTitleAlign = ImVec2(0.5f, 0.5f);
    style.IndentSpacing    = 18.0f;

    style.AntiAliasedLines = true;
    style.AntiAliasedFill  = true;
    style.Alpha = 1.0f;
}




void CustomText(const char* label) {
    // ImGui::PushStyleColor(ImGuiCol_Text, Color7);
    //màu xanh lá cây đậm
     ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.13f, 0.75f, 0.55f, 1.00f));
    //Text("");
    ImGui::Text(label);
    ImGui::PopStyleColor(1);
}


bool CustomTextInput(const char* label, std::string& text, bool integerOnly, UIView* parentView)
{
    static std::unordered_map<std::string, UITextField*> fieldMap;
    std::string textInputID = std::string(label);   // bỏ (uintptr_t)&text để key ổn định

    static std::unordered_map<std::string, std::string> lastValueMap;
    if (lastValueMap[textInputID] != text) {
        lastValueMap[textInputID] = text;
    }

    ImGui::Text("%s", label);
    ImGui::SameLine();

    ImVec2 posPx = ImGui::GetCursorScreenPos();
    ImVec2 sizePx = ImVec2(150, ImGui::GetTextLineHeightWithSpacing());

    ImGui::SetItemAllowOverlap();
    ImGui::InvisibleButton(textInputID.c_str(), sizePx);
    bool active = ImGui::IsItemActive();
    bool clicked = ImGui::IsItemClicked();

    // pixel -> point
    CGFloat scale = [UIScreen mainScreen].scale;
    CGRect frame = CGRectMake(posPx.x / scale, posPx.y / scale, sizePx.x / scale, sizePx.y / scale);

    if (fieldMap.find(textInputID) == fieldMap.end()) {
        UITextField* tf = [[UITextField alloc] initWithFrame:frame];
        tf.text = [NSString stringWithUTF8String:text.c_str()];
        tf.borderStyle = UITextBorderStyleRoundedRect;
        tf.keyboardType = integerOnly ? UIKeyboardTypeNumberPad : UIKeyboardTypeDefault;
        tf.autocorrectionType = UITextAutocorrectionTypeNo;
        tf.clearButtonMode = UITextFieldViewModeWhileEditing;
        tf.hidden = NO;
        [parentView addSubview:tf];
        fieldMap[textInputID] = tf;
    }

    UITextField* tf = fieldMap[textInputID];
    tf.frame = frame;

    // Focus theo click
    if (clicked && ![tf isFirstResponder]) {
        [tf becomeFirstResponder];
    }
    // Nếu click ra ngoài thì bỏ focus
    if (!ImGui::IsItemHovered() && ImGui::IsMouseClicked(0) && [tf isFirstResponder]) {
        [tf resignFirstResponder];
    }

    NSString* currentText = tf.text ?: @"";
    std::string newText = [currentText UTF8String];

    // lọc số khi integerOnly
    if (integerOnly) {
        std::string filtered;
        for (char c : newText) {
            if (c >= '0' && c <= '9') filtered.push_back(c);
        }
        if (filtered != newText) {
            newText = filtered;
            tf.text = [NSString stringWithUTF8String:filtered.c_str()];
        }
    }

    if (newText != text) {
        text = newText;
        lastValueMap[textInputID] = newText;
        return true;
    }

    return false;
}
struct EquipSkill {
    int id;
    int cooldown;
    int index;
};
enum EquipID {
    CauBangSuong  = 1242,  // Cầu Băng Sương
    ThuanNhamThach  = 1340,  // Thuẫn Nham Thạch
    ThuongKhungKiem  = 1149,  // Thương Khung Kiếm
    GiapHoiSinh  = 1337,  // Giáp Hồi Sinh
    LiemDoatMenh  = 11271, // Liềm Đoạt Mệnh
    HerculesThinhNo  = 1328,  // Hercules Thịnh Nộ

    DaiDiaThanKhien  = 16211, // Đại Địa Thần Khiên
    DaiDiaMaNhan  = 16212, // Đại Địa Ma Nhãn
    DaiDiaThanToc  = 16213, // Đại Địa Thần Tốc
    DaiDiaMoTroi  = 16214, // Đại Địa Mở Trói
    DaiDiaHoiHuyet  = 16215, // Đại Địa Hồi Huyết

    LietHoaThanKhien  = 16231, // Liệt Hỏa Thần Khiên
    LietHoaMaNhan  = 16232, // Liệt Hỏa Ma Nhãn
    LietHoaThanToc  = 16233, // Liệt Hỏa Thần Tốc
    LietHoaMoTroi  = 16234, // Liệt Hỏa Mở Trói
    LietHoaHoiHuyet  = 16235, // Liệt Hỏa Hồi Huyết

    CungTaMa  = 1145,  // Cung Tà Ma
    XaNhatCung  = 1148   // Xạ Nhật Cung
};
struct ItemData {
    int stt;
    int id;
    int cost;
    int sellPrice;
    int cd;
    int lastSold;
    int cdRemain;
    int index; // slot hiện tại (-1 nếu chưa có)
    int lastbuy;
    bool shouldBuy;
    int cdmax;
};
vector<ItemData> items = {
    {1,EquipID::GiapHoiSinh, 2400, 1440, 0, 0, 0, -1, 0, true,150},  // Giáp hồi sinh
    {2,EquipID::CauBangSuong, 2200, 1320, 0, 0, 0, -1, 0, true,75}, // Cầu băng sương
    {3,EquipID::LiemDoatMenh, 2000, 1200, 0, 0, 0, -1, 0, true,90}, // Liềm đoạt mệnh
    {4,EquipID::ThuongKhungKiem, 2120, 1272, 0, 0, 0, -1, 0, true,90}, // Thương khung kiếm
    {5,EquipID::ThuanNhamThach, 1980, 1188, 0, 0, 0, -1, 0, true,60},  // Thuẫn Nham Thạch
    {6,EquipID::HerculesThinhNo, 2080, 1248, 0, 0, 0, -1, 0, true,60}, // Hercules thịnh nộ
    {7,EquipID::CungTaMa, 2250, 1350, 0, 0, 0, -1, 0, true,60},
    {8,EquipID::XaNhatCung, 2000, 1200, 0, 0, 0, -1, 0, true,60},
    
};

struct ItemOption {
    const char* name;
    ItemData item;
};
static const ItemOption itemOptions[] = {
    { "Giáp Hồi sinh", items[0]},
    { "Cầu Băng Sương", items[1]},
    { "Liềm Đoạt Mệnh", items[2]},
    { "Thương Khung Kiếm", items[3]},
    { "Thuẫn Nham Thạch", items[4]},
    { "Hercules Thịnh Nộ", items[5]},
    { "Cung Tà Ma", items[6]},
    { "Xạ Nhật Cung", items[7]}
};
const int ITEM_COUNT = sizeof(itemOptions) / sizeof(ItemOption);
const int COMBO_COUNT = 8;
static int selectedIndices[COMBO_COUNT] = { 0, 1, 2, 3, 4, 5, 6, 7 };
static bool isEnabled[COMBO_COUNT] = { true, true, true, true, true, true,true,true};
vector<ItemData> BuildSelectedItemsVector(vector<ItemData>& items,int selectedIndices[COMBO_COUNT],bool isEnabled[COMBO_COUNT]) 
{
    vector<ItemData> selectedItems;
    for (int i = 0; i < COMBO_COUNT; ++i) {
        if (isEnabled[i] && selectedIndices[i] >= 0) {
            int indexInItems = selectedIndices[i];
            if (indexInItems >= 0 && indexInItems < items.size()) {
                selectedItems.push_back(items[indexInItems]);
            }
        }
    }
    return selectedItems;
}
void ShowSequentialItemCombosWithCheckbox() {
    for (int comboIdx = 0; comboIdx < COMBO_COUNT; ++comboIdx) {
        std::set<int> usedBefore;
        for (int i = 0; i < comboIdx; ++i) {
            if (isEnabled[i] && selectedIndices[i] >= 0)
                usedBefore.insert(selectedIndices[i]);
        }

        std::vector<int> validIndices;
        for (int i = 0; i < COMBO_COUNT; ++i) {
            if (usedBefore.find(i) == usedBefore.end())
                validIndices.push_back(i);
        }

        ImGui::PushID(comboIdx);
        std::string comboLabel    = "##combo" + std::to_string(comboIdx + 1);
        std::string checkboxLabel = "##check" + std::to_string(comboIdx + 1);

        if (ImGui::Checkbox(checkboxLabel.c_str(), &isEnabled[comboIdx])) {
            [sharedInstance saveSetting];
        }
        ImGui::SameLine();

        // Disable combo khi checkbox off (cách tương thích version cũ)
        const bool disabled = !isEnabled[comboIdx];
        if (disabled) {
            ImGui::PushItemFlag(ImGuiItemFlags_Disabled, true);
            ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ImGui::GetStyle().Alpha * 0.5f);
        }

        const char* previewValue =
            (selectedIndices[comboIdx] >= 0)
                ? itemOptions[selectedIndices[comboIdx]].name
                : "Chọn vật phẩm";

        if (ImGui::BeginCombo(comboLabel.c_str(), previewValue)) {
            for (int idx = 0; idx < (int)validIndices.size(); ++idx) {
                int itemIdx = validIndices[idx];
                bool isSelected = (selectedIndices[comboIdx] == itemIdx);
                if (ImGui::Selectable(itemOptions[itemIdx].name, isSelected)) {
                    selectedIndices[comboIdx] = itemIdx;
                    // Bỏ chọn trùng ở các combo sau
                    for (int j = comboIdx + 1; j < COMBO_COUNT; ++j)
                        if (selectedIndices[j] == itemIdx) selectedIndices[j] = -1;
                        [sharedInstance saveSetting];
                }
                if (isSelected) ImGui::SetItemDefaultFocus();
            }
            ImGui::EndCombo();
        }

        if (disabled) {
            ImGui::PopStyleVar();
            ImGui::PopItemFlag();
        }

        ImGui::PopID();
    }
}

bool CustomSliderInt(const char* label, int* v, int v_min, int v_max,
                     const char* format = "%d", ImGuiSliderFlags flags = 0) {
    ImGui::PushStyleColor(ImGuiCol_Text, BrandTheme::TextPrimary);
    ImGui::PushStyleColor(ImGuiCol_FrameBg, BrandTheme::FrameBg);
    ImGui::PushStyleColor(ImGuiCol_FrameBgHovered, BrandTheme::FrameBgHovered);
    ImGui::PushStyleColor(ImGuiCol_FrameBgActive, BrandTheme::FrameBgActive);
    ImGui::PushStyleColor(ImGuiCol_SliderGrab, BrandTheme::AccentColor);
    ImGui::PushStyleColor(ImGuiCol_SliderGrabActive, BrandTheme::AccentActive);
    ImGui::PushStyleVar(ImGuiStyleVar_GrabRounding, BrandTheme::GrabRounding);

    bool changed = ImGui::SliderInt(label, v, v_min, v_max, format, flags);

    ImGui::PopStyleVar();
    ImGui::PopStyleColor(6);

    if (changed) {
        [sharedInstance saveSetting];
    }
    return changed;
}

void CustomSwitch(const char* label, bool* v) {
    ImGuiStyle& style = ImGui::GetStyle();
    ImDrawList* draw_list = ImGui::GetWindowDrawList();
    ImVec2 p = ImGui::GetCursorScreenPos();
    float height = ImGui::GetFrameHeight();
    float width = height * 1.8f; 
    float radius = height * 0.5f;
    float knob_radius = radius * 0.8f; 
    float switch_padding = height * 0.1f;
    float outline_thickness = 1.5f;

    ImGui::InvisibleButton(label, ImVec2(width, height));
    if (ImGui::IsItemClicked()) {
        *v = !*v;
        [sharedInstance saveSetting]; 
    }

    float t = *v ? 1.0f : 0.0f;
    float current_t = ImGui::GetStateStorage()->GetFloat(ImGui::GetID(label), t);
    if (current_t != t) {
        float move_speed = ImGui::GetIO().DeltaTime * 10.0f; 
        current_t = lerp(current_t, t, move_speed);
        if (fabs(current_t - t) < 0.01f) {
            current_t = t;
        }
        ImGui::GetStateStorage()->SetFloat(ImGui::GetID(label), current_t);
    }

    ImVec4 bg_color_off = BrandTheme::FrameBg;
    ImVec4 bg_color_on = BrandTheme::AccentColor;
    ImVec4 knob_color_off = BrandTheme::TextSecondary;
    ImVec4 knob_color_on = BrandTheme::BackgroundDark; 
    ImVec4 border_color = BrandTheme::BackgroundLight; 

    ImVec4 current_bg_color = lerp(bg_color_off, bg_color_on, current_t);
    ImVec4 current_knob_color = lerp(knob_color_off, knob_color_on, current_t);

    draw_list->AddRectFilled(p, ImVec2(p.x + width, p.y + height), ImGui::GetColorU32(current_bg_color), radius);
    draw_list->AddRect(p, ImVec2(p.x + width, p.y + height), ImGui::GetColorU32(border_color), radius, ImDrawFlags_None, outline_thickness);

    ImVec2 knob_center = ImVec2(
        lerp(p.x + radius, p.x + width - radius, current_t),
        p.y + radius
    );
    draw_list->AddCircleFilled(knob_center, knob_radius - switch_padding, ImGui::GetColorU32(current_knob_color), 20);
    draw_list->AddCircle(knob_center, knob_radius - switch_padding, ImGui::GetColorU32(border_color), 20, outline_thickness * 0.75f);

    ImGui::SameLine(0, style.ItemInnerSpacing.x);
    ImGui::PushStyleColor(ImGuiCol_Text, BrandTheme::TextPrimary);
    ImGui::TextUnformatted(label);
    ImGui::PopStyleColor();
}

void CustomSectionHeader(const char* label) {
    ImGui::PushStyleColor(ImGuiCol_Text, BrandTheme::TextHeader);
    ImGui::Text(label);
    ImGui::PopStyleColor();
    ImGui::Separator(); 
    ImGui::Spacing();
}

bool CustomSliderFloat(const char* label, float* v, float v_min, float v_max, const char* format = "%.3f", ImGuiSliderFlags flags = 0) {
    ImGui::PushStyleColor(ImGuiCol_Text, BrandTheme::TextPrimary);
    ImGui::PushStyleColor(ImGuiCol_FrameBg, BrandTheme::FrameBg);
    ImGui::PushStyleColor(ImGuiCol_FrameBgHovered, BrandTheme::FrameBgHovered);
    ImGui::PushStyleColor(ImGuiCol_FrameBgActive, BrandTheme::FrameBgActive);
    ImGui::PushStyleColor(ImGuiCol_SliderGrab, BrandTheme::AccentColor);
    ImGui::PushStyleColor(ImGuiCol_SliderGrabActive, BrandTheme::AccentActive);
    ImGui::PushStyleVar(ImGuiStyleVar_GrabRounding, BrandTheme::GrabRounding); 

    bool changed = ImGui::SliderFloat(label, v, v_min, v_max, format, flags);

    ImGui::PopStyleVar();
    ImGui::PopStyleColor(6);

    if (changed) {
        [sharedInstance saveSetting]; 
    }
    return changed;
}

void CustomTextNeon(const char* label) {
    ImGui::PushStyleColor(ImGuiCol_Text, neonGreen);
    ImGui::Text(label);
    ImGui::PopStyleColor(1);
}

void DrawFPSGauge(ImDrawList* draw_list, ImVec2 center, float radius, float current_fps, float max_fps) {
    const float thickness = radius * 0.2f;
    const float start_angle = -M_PI_2;
    const float end_angle = start_angle + 2 * M_PI;
    const int num_segments = 50;

    float fps_ratio = fmaxf(0.0f, fminf(1.0f, current_fps / max_fps));
    float fps_angle = start_angle + fps_ratio * (2 * M_PI);

    draw_list->PathClear();
    for (int i = 0; i <= num_segments; ++i) {
        float angle = start_angle + ((float)i / (float)num_segments) * (end_angle - start_angle);
        draw_list->PathLineTo(ImVec2(center.x + cosf(angle) * radius, center.y + sinf(angle) * radius));
    }
    draw_list->PathStroke(ImGui::GetColorU32(midBackground), false, thickness);

    if (fps_ratio > 0.0f) {
        draw_list->PathClear();
        int fps_segments = (int)(num_segments * fps_ratio);
        for (int i = 0; i <= fps_segments; ++i) {
            float angle = start_angle + ((float)i / (float)num_segments) * (2 * M_PI);
            draw_list->PathLineTo(ImVec2(center.x + cosf(angle) * radius, center.y + sinf(angle) * radius));
        }
        if (fps_segments < num_segments) {
            draw_list->PathLineTo(ImVec2(center.x + cosf(fps_angle) * radius, center.y + sinf(fps_angle) * radius));
        }
        draw_list->PathStroke(ImGui::GetColorU32(brightAccent), false, thickness);
    }

    char fps_text[16];
    snprintf(fps_text, sizeof(fps_text), "%.0f", current_fps);
    ImVec2 text_size = ImGui::CalcTextSize(fps_text);
    ImGui::PushStyleColor(ImGuiCol_Text, whiteText);
    draw_list->AddText(ImVec2(center.x - text_size.x * 0.5f, center.y - text_size.y * 0.5f), ImGui::GetColorU32(whiteText), fps_text);
    ImGui::PopStyleColor();
}

NSString* GetDocumentsPath() {
    return NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
}
void SaveToFile(const string& content) {
    NSString *filePath = [GetDocumentsPath() stringByAppendingPathComponent:@"Test.txt"];
    ofstream outFile([filePath UTF8String], ios::app);
    if (outFile.is_open()) {
        outFile << content << endl;
    }
}
void SaveToFile(int value) {
    SaveToFile("giatri: " + to_string(value));
}
typedef struct {
    float minScale;
    float maxScale;
    int minHeight;
    int maxHeight;
    int minWidth;
    int maxWidth;
    float scaleValue;
} DeviceScaleConfig;

DeviceScaleConfig scaleConfigs[] = {
    // Case 1: iPhone X & XS & 11 Pro (ưu tiên cao nhất)
    {3.0f, 3.0f, 375, 375, 812, 812, 0.5253f},
    
    // Case 2: iPhone XR
    {2.19f, 2.23f, 375, 375, 812, 812, 5.0f/7},
    
    // Case 3: iPhone 7, 8, SE 2020, 2022
    {2.0f, 2.0f, 375, 375, 667, 667, 719.0f/750},
    
    // Case 4: iPhone 12
    {3.0f, 3.0f, 390, 390, 844, 844, 0.505f},
    
    // Case 5: iPhone 7 Plus
    {2.59f, 2.62f, 414, 414, 736, 736, 2.0f/3},

    // Case 6: iPhone 13/14 Pro
    {3.0f, 3.0f, 0, 400, 0, 9999, 0.5f},
    
    // Case 7: General case (ưu tiên thấp nhất)
    {2.0f, 2.0f, 0, 500, 0, 9999, 0.0f}
};
float FindScaleConfig(float currentScale, int height, int width) {
    for(int i = 0; i < sizeof(scaleConfigs)/sizeof(scaleConfigs[0]); i++) {
        DeviceScaleConfig config = scaleConfigs[i];
        
        bool scaleMatch = (currentScale >= config.minScale) && (currentScale <= config.maxScale);
        bool heightMatch = (height >= config.minHeight) && (height <= config.maxHeight);
        bool widthMatch = (width >= config.minWidth) && (width <= config.maxWidth);
        
        if(scaleMatch && heightMatch && widthMatch) {
           if(i == sizeof(scaleConfigs)/sizeof(scaleConfigs[0]) - 1) {
                return (5.0f * (currentScale + 2)) /14;
            }
            return config.scaleValue *kScale;
        }
    }
    return (5.0f * (currentScale + 1)) /14; // Default value
}
struct EntityInfo {
    Vector3 myPos;
	Vector3 enemyPos;
	Vector3 moveForward;
	int ConfigID;
	float bullettime;
    float Ranger;
    int currentSpeed; 
};
EntityInfo EnemyTarget1;
EntityInfo EnemyTarget2;
EntityInfo EnemyTarget3;


static int selectedbutton = 0;
//using json = nlohmann::json;
static int selectedValue2 = 0;

/*
static int modenotify = 0;
static int TypeKill = 0; 
static std::unordered_map<int, int> autoTypeKillMap;
static std::vector<std::string> options2;
static std::vector<int> typeKillValues;
static bool isJsonLoaded = false;
void LoadJsonFromGitHub() {
    NSString* urlString = @"https://raw.githubusercontent.com/shinplus999/shin/refs/heads/main/KillNotify.json";
    NSURL* url = [NSURL URLWithString:urlString];
    NSURLSession* session = [NSURLSession sharedSession];
    
    NSURLSessionDataTask* task = [session dataTaskWithURL:url completionHandler:^(NSData* data, NSURLResponse* response, NSError* error) {
        if (error) {
            NSLog(@"Failed to load JSON: %@", error);
            return;
        }

        NSString* jsonString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        try {
            json j = json::parse([jsonString UTF8String]);
            autoTypeKillMap.clear();
            options2.clear();
            typeKillValues.clear();

            for (auto& [key, value] : j.items()) {
                int keyInt = std::stoi(key);
                int id = value["id"].get<int>();
                std::string name = value["name"].get<std::string>();
                autoTypeKillMap[keyInt] = id;
                options2.push_back(name);
                typeKillValues.push_back(id);
            }
            isJsonLoaded = true;
            NSLog(@"Successfully");
        } catch (const std::exception& e) {
            NSLog(@"Error: %s", e.what());
        }
    }];
    [task resume];
}

static int modMode = 1;
static int selectedbutton = 0;
static std::vector<std::string> modNutOptions;
static std::vector<int> modNutValues;
static bool isModNutLoaded = false;
void LoadModNutFromGitHub() {
    NSString* urlString = @"https://raw.githubusercontent.com/shinplus999/shin/refs/heads/main/AttackButton.json";
    NSURL* url = [NSURL URLWithString:urlString];
    NSURLSession* session = [NSURLSession sharedSession];
    
    NSURLSessionDataTask* task = [session dataTaskWithURL:url completionHandler:^(NSData* data, NSURLResponse* response, NSError* error) {
        if (error) {
            NSLog(@"Failed to load JSON: %@", error);
            return;
        }

        NSString* jsonString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        try {
            json j = json::parse([jsonString UTF8String]);
            modNutOptions.clear();
            modNutValues.clear();

            for (auto& item : j) {
                int id = item["id"].get<int>();
                std::string name = item["name"].get<std::string>();
                modNutOptions.push_back(name);
                modNutValues.push_back(id);
            }
            isModNutLoaded = true;
            NSLog(@"Successfully");
        } catch (const std::exception& e) {
            NSLog(@"Error: %s", e.what());
        }
    }];
    [task resume];
}
*/
void DrawHeroSkinInfo() {
    ImGui::Text("Hero ID: %u", currentHeroId);
    ImGui::SameLine();
    ImGui::Text("Skin ID: %u", currentSkinId);
}

static inline void OpenURL_iOS(const char* url_cstr) {
    NSString *s = [NSString stringWithUTF8String:url_cstr ?: ""];
    NSURL *u = [NSURL URLWithString:s];
    if (!u) return;
    UIApplication *app = [UIApplication sharedApplication];
    if (@available(iOS 10.0, *)) {
        [app openURL:u options:@{} completionHandler:nil];
    } else {
        [app openURL:u];
    }
}

struct Texture {
    id<MTLTexture> texture; 
    float height;
    float width;
};
id<MTLTexture> LoadImageFromMemory(id<MTLDevice> device, unsigned char* image_data, size_t image_size) {
    CFDataRef imageData = CFDataCreate(kCFAllocatorDefault, image_data, image_size);
    CGDataProviderRef dataProvider = CGDataProviderCreateWithCFData(imageData);
    CGImageRef cgImage = CGImageCreateWithPNGDataProvider(dataProvider, NULL, false, kCGRenderingIntentDefault);
    CFRelease(imageData);
    CGDataProviderRelease(dataProvider);
    if (!cgImage) {
        return nil;
    }
    NSError *error = nil;
    MTKTextureLoader *textureLoader = [[MTKTextureLoader alloc] initWithDevice:device];
    NSDictionary *options = @{MTKTextureLoaderOptionSRGB : @(NO)};
    id<MTLTexture> texture = [textureLoader newTextureWithCGImage:cgImage options:options error:&error];

    if (error) {
        CGImageRelease(cgImage);
        return nil;
    }
    CGImageRelease(cgImage);
    return texture;
}
std::vector<unsigned char> Base64Decode(const std::string &in) {
    std::string base64_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::vector<unsigned char> out;
    std::vector<int> T(256, -1);
    for (int i = 0; i < 64; i++) T[base64_chars[i]] = i;

    int val = 0, valb = -8;
    for (unsigned char c : in) {
        if (T[c] == -1) break;
        val = (val << 6) + T[c];
        valb += 6;
        if (valb >= 0) {
            out.push_back(char((val >> valb) & 0xFF));
            valb -= 8;
        }
    }
    return out;
}
id<MTLTexture> LoadTextureFromBase64(id<MTLDevice> device, const std::string& base64) {
    // 1. Giải mã Base64 thành dữ liệu nhị phân
    std::vector<unsigned char> decodedData = Base64Decode(base64);

    // 2. Load ảnh từ bộ nhớ
    int width, height, channels;
    unsigned char* imageData = stbi_load_from_memory(decodedData.data(), decodedData.size(), &width, &height, &channels, 4);
    if (!imageData) {
        NSLog(@"[Error] Failed to load image from Base64");
        return nil;
    }

    // 3. Tạo descriptor cho texture
    MTLTextureDescriptor* descriptor = [[MTLTextureDescriptor alloc] init];
    descriptor.pixelFormat = MTLPixelFormatRGBA8Unorm;
    descriptor.width = width;
    descriptor.height = height;
    descriptor.usage = MTLTextureUsageShaderRead;

    // 4. Tạo texture Metal
    id<MTLTexture> texture = [device newTextureWithDescriptor:descriptor];
    if (texture) {
        // Sao chép dữ liệu ảnh vào texture
        MTLRegion region = {{0, 0, 0}, {static_cast<NSUInteger>(width), static_cast<NSUInteger>(height), 1}};
        [texture replaceRegion:region mipmapLevel:0 withBytes:imageData bytesPerRow:width * 4];
    } else {
        NSLog(@"[Error] Failed to create texture");
    }

    // 5. Giải phóng bộ nhớ ảnh
    stbi_image_free(imageData);

    return texture;
}
vector<Texture> textures;
void AddTexturesFromImageData(id<MTLDevice> device) {
    for (const auto& heroData : heroArray) {
        Texture tex;
        tex.texture = LoadImageFromMemory(device, heroData.data, heroData.size);
        if(tex.texture == nil) continue;
        tex.width = tex.texture.width;
        tex.height = tex.texture.height;
        textures.push_back(tex);
    }
}