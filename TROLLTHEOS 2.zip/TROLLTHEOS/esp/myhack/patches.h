#include "include.h"
//
/*
bool (*PlayEmojiEffect)(void *ins, int emojiType, int emojiIndex, int emojiSubType, uint emojiCfgId);
bool _PlayEmojiEffect(void *ins, int emojiType, int emojiIndex, int emojiSubType, uint emojiCfgId){
    if(ins != NULL && Bhideemoji){       
        return true;
        }
        unhook_one_point(hideemoji);
        bool result = PlayEmojiEffect(ins, emojiType, emojiIndex, emojiSubType, emojiCfgId);
        hook_one_point(hideemoji,(void*)_PlayEmojiEffect);
    return result;
}
*/


void (*RefreshHeroPanel)(void *instance,bool v1,bool v2,bool v3);
bool (*IsSkinAvailable)(int configID);
bool _IsSkinAvailable(int configID)
{
	if(unlockskin)
	{
		return true;
	}
    unhook_one_point(ModSkin[0]);
    bool result = IsSkinAvailable(configID);
    hook_one_point(ModSkin[0],(void*)_IsSkinAvailable);
    return result;
}
bool (*CanUseSkin)(void *instance,int heroID,int skinID);
bool _CanUseSkin(void *instance,int heroID,int skinID)
{
	if(instance != NULL && unlockskin)
	{
		[protocol setEnable:YES];
		protocol._heroID = heroID;
		protocol._skinID = skinID;
		return true;
	}
    unhook_one_point(ModSkin[1]);
    bool result = CanUseSkin(instance,heroID,skinID);
    hook_one_point(ModSkin[1],(void*)_CanUseSkin);
    return result;  
}
void UpdateTypeKill(int currentHeroId,int currentSkinId);
void UpdateButtonID(int currentHeroId,int currentSkinId);
int (*GetHeroWearSkinId)(void *instance,int heroID);
int _GetHeroWearSkinId(void *instance,int heroID){
	currentHeroId = heroID;
    int skinid;
	if(unlockskin){
    skinid = protocol._skinID;
	} else {
		skinid = GetHeroWearSkinId(instance,heroID);
	}
    unhook_one_point(ModSkin[2]);
    currentSkinId = skinid;
    UpdateTypeKill(currentHeroId, currentSkinId);
    UpdateButtonID(currentHeroId, currentSkinId);
    hook_one_point(ModSkin[2],(void*)_GetHeroWearSkinId);
    return skinid;
}
int32_t (*old_unpack)(void* instance, void* srcBuf, int32_t cutVer);
bool g_unpack_installed = false;

inline uint32_t getdwHeroID_inline(void* p) {
    return p ? *(uint32_t*)((uintptr_t)p + 0x10) : 0;
}
inline uint16_t getwSkinID_inline(void* p) {
    return p ? *(uint16_t*)((uintptr_t)p + 0x42) : 0;
}
inline void setwSkinID_inline(void* p, uint16_t id) {
    if (p) *(uint16_t*)((uintptr_t)p + 0x42) = id;
}

int32_t unpack_postcall(void* instance, void* srcBuf, int32_t cutVer) {

    unhook_one_point(ModSkin[6]);

    int32_t ret = old_unpack ? old_unpack(instance, srcBuf, cutVer) : 0;

    if (unlockskin && instance && [protocol isEnabled]) {
        const uint32_t heroID = getdwHeroID_inline(instance);
        const uint16_t oldSkin = getwSkinID_inline(instance);

        if (protocol._heroID > 0 && heroID == (uint32_t)protocol._heroID && protocol._skinID > 0) {
            setwSkinID_inline(instance, (uint16_t)protocol._skinID);
        } else if ([protocol checkHeroID:heroID]) {
            int saved = [protocol getHeroSkinID:heroID];
            if (saved > 0) setwSkinID_inline(instance, (uint16_t)saved);
        } else {
            [protocol checkAndUpdateHeroSkin:heroID skinID:oldSkin];
        }
    }

    hook_one_point(ModSkin[6], (void*)unpack_postcall);
    return ret;
}



static bool modnotify = true;
struct Optionz {
    std::string name;
    int value;
    int typeKill;
};

bool modbutton = true;
struct OptionZ {
    std::string name;
    int value;
    int ButtonID;
};

static std::vector<Optionz> options2;
static std::vector<OptionZ> options1;

NSArray *loadJSON(NSString *urlString) {
    NSURL *url = [NSURL URLWithString:urlString];
    NSData *data = [NSData dataWithContentsOfURL:url];
    if (!data) return nil;
    NSError *error;
    NSArray *jsonArray = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
    if (error) return nil;
    return jsonArray;
}

void loadOptionsOnline() {

    NSArray *arrz = loadJSON(@"https://raw.githubusercontent.com/minhkhangcheat/Minh-Khang/refs/heads/main/AttackButton_MinhKhang.json");
    if (!arrz) return;
    options1.clear();
    for (NSDictionary *dictz in arrz) {
        OptionZ optz;
        optz.name = [dictz[@"name"] UTF8String];
        optz.value = [dictz[@"value"] intValue];
        optz.ButtonID = [dictz[@"ButtonID"] intValue];
        options1.push_back(optz);
    }

    NSArray *arr = loadJSON(@"https://raw.githubusercontent.com/minhkhangcheat/Minh-Khang/refs/heads/main/KillNotify_MinhKhang.json");
    if (!arr) return;
    options2.clear();
    for (NSDictionary *dict in arr) {
        Optionz oct;
        oct.name = [dict[@"name"] UTF8String];
        oct.value = [dict[@"value"] intValue];
        oct.typeKill = [dict[@"typeKill"] intValue];
        options2.push_back(oct);
    }
}


void DrawModNotify() {
    if (options2.empty()) return;
    std::vector<const char*> items;
    for (auto &oct : options2) items.push_back(oct.name.c_str());
    if(ImGui::Combo("Thông Báo", &selectedValue2, items.data(), (int)items.size())){
    UpdateTypeKill(currentHeroId, currentSkinId);
    }
}
void UpdateTypeKill(int heroId, int skinId) {
    currentHeroId = heroId;
    currentSkinId = skinId;
    if (selectedValue2 == 1) {
        int heroSkinId = currentHeroId * 100 + currentSkinId;
        for (size_t i = 2; i < options2.size(); i++) {
            if (options2[i].value == heroSkinId) {
                KillMode = options2[i].typeKill;
                return;
            }
        }
        KillMode = 0;
    } else {
        KillMode = options2[selectedValue2].typeKill;
    }
}

void UpdateButtonID(int heroId, int skinId) {
    currentHeroId = heroId;
    currentSkinId = skinId;
    if (selectedValue1 == 1) {
        int heroSkinId = currentHeroId * 100 + currentSkinId;
        for (size_t i = 2; i < options1.size(); i++) {
            if (options1[i].value == heroSkinId) {
                ButtonModeID = options1[i].ButtonID;
                return;
            }
        }
        ButtonModeID = 0;
    } else {
        ButtonModeID = options1[selectedValue1].ButtonID;
    }
}

void DrawModButton() {
    if (options1.empty()) return;
    std::vector<const char*> items;
    for (auto &optz : options1) items.push_back(optz.name.c_str());
    if(ImGui::Combo("Nút Bấm", &selectedValue1, items.data(), (int)items.size())){
    UpdateButtonID(currentHeroId, currentSkinId);
    }
}

void (*OnCameraHeightChanged)(void *instance);
void (*_CameraSystem_Update)(void *instance);
void CameraSystem_Update(void *instance)
{
    if (lockcam)
    {
        return;
    }
        if (instance != NULL) {
        OnCameraHeightChanged(instance);
    }
     _CameraSystem_Update(instance);
}

float(*GetZoomRate)(void* instance);
float _GetZoomRate(void* instance)
{ 
    float original = *(float*)((uintptr_t)instance + EspField[21]);
	if (instance != NULL && SliderCamera)
	{	
		return original + Camera;
	}
    return original;
}

enum COM_PLAYERCAMP {
    ComPlayercampMid = 0,
    ComPlayercamp1 = 1,
    ComPlayercamp2 = 2,
    ComPlayercamp3 = 3,
    ComPlayercamp4 = 4,
    ComPlayercamp5 = 5,
    ComPlayercamp6 = 6,
    ComPlayercamp7 = 7,
    ComPlayercamp8 = 8,
    ComPlayercampCount = 9,
    ComPlayercampOb = 10,
    ComPlayercampInvalid = 254,
    ComPlayercampAll = 255
};

bool (*SetVisible)(void *instance, COM_PLAYERCAMP camp, bool bVisible, bool forceSync);
bool _SetVisible(void *instance, COM_PLAYERCAMP camp, bool bVisible, bool forceSync) {
    if (instance && HackMap) {
        bVisible  = true;
        forceSync = false;
    }
    unhook_one_point(offset[0]);
    bool result = SetVisible(instance, camp, bVisible, forceSync);
    hook_one_point(offset[0],(void*)_SetVisible);
    return result;
}

Vector3 (*GetUseSkillDirection)(void* instance,bool isUseSkill);
Vector3 _GetUseSkillDirection(void* instance,bool isUseSkill)
{
    if(instance != NULL && AimbotEnable)
    {
        void* SkillSlot = *(void**)((uintptr_t)instance + EspField[17]);
        if(SkillSlot != NULL)
        {
            int SkillSlotType = *(int*)((uintptr_t)SkillSlot + EspField[18]);
            if(SkillSlotType == 1)
            {
                if (EnemyTarget1.bullettime > 0.0f && EnemyTarget1.myPos != Vector3::zero() && EnemyTarget1.enemyPos != Vector3::zero() && (!MANUALAIM || (MANUALAIM && enableSkill1))) {
                    return calculateSkillDirection(EnemyTarget1.myPos,EnemyTarget1.enemyPos,EnemyTarget1.moveForward,EnemyTarget1.currentSpeed,EnemyTarget1.bullettime,EnemyTarget1.Ranger);
                }
            }
            else if(SkillSlotType == 2)
            {
                if (EnemyTarget2.bullettime > 0.0f && EnemyTarget2.myPos != Vector3::zero() && EnemyTarget2.enemyPos != Vector3::zero() && (!MANUALAIM || (MANUALAIM && enableSkill2))) {
                    return calculateSkillDirection(EnemyTarget2.myPos,EnemyTarget2.enemyPos,EnemyTarget2.moveForward,EnemyTarget2.currentSpeed,EnemyTarget2.bullettime,EnemyTarget2.Ranger);
                }
            }
            else if(SkillSlotType == 3)
            {
                if (EnemyTarget3.bullettime > 0.0f && EnemyTarget3.myPos != Vector3::zero() && EnemyTarget3.enemyPos != Vector3::zero() && (!MANUALAIM || (MANUALAIM && enableSkill3))) {
                    return calculateSkillDirection(EnemyTarget3.myPos,EnemyTarget3.enemyPos,EnemyTarget3.moveForward,EnemyTarget3.currentSpeed,EnemyTarget3.bullettime,EnemyTarget3.Ranger);
                }
            }
        }
    }
    return *(Vector3*) ((uintptr_t)instance + ActorLinkerOffField[9]);
}
Vector3 (*GetUseSkillPosition)(void* instance,bool isUseSkill);
Vector3 _GetUseSkillPosition(void* instance,bool isUseSkill)
{
    if(instance != NULL && AimbotEnable)
    {
        void* SkillSlot = *(void**)((uintptr_t)instance + EspField[17]);
        if(SkillSlot != NULL)
        {
            int SkillSlotType = *(int*)((uintptr_t)SkillSlot + EspField[18]);
            if(SkillSlotType == 1)
            {
                if (EnemyTarget1.bullettime > 0.0f && EnemyTarget1.myPos != Vector3::zero() && EnemyTarget1.enemyPos != Vector3::zero() && (!MANUALAIM || (MANUALAIM && enableSkill1))) {
                    return calculateSkillPosition(EnemyTarget1.myPos,EnemyTarget1.enemyPos,EnemyTarget1.moveForward,EnemyTarget1.currentSpeed,EnemyTarget1.bullettime,EnemyTarget1.Ranger);
                }
            }
            else if(SkillSlotType == 2)
            {
                if (EnemyTarget2.bullettime > 0.0f && EnemyTarget2.myPos != Vector3::zero() && EnemyTarget2.enemyPos != Vector3::zero() && (!MANUALAIM || (MANUALAIM && enableSkill2))) {
                    return calculateSkillPosition(EnemyTarget2.myPos,EnemyTarget2.enemyPos,EnemyTarget2.moveForward,EnemyTarget2.currentSpeed,EnemyTarget2.bullettime,EnemyTarget2.Ranger);
                }
            }
            else if(SkillSlotType == 3)
            {
                if (EnemyTarget3.bullettime > 0.0f && EnemyTarget3.myPos != Vector3::zero() && EnemyTarget3.enemyPos != Vector3::zero() && (!MANUALAIM || (MANUALAIM && enableSkill3))) {
                    return calculateSkillPosition(EnemyTarget3.myPos,EnemyTarget3.enemyPos,EnemyTarget3.moveForward,EnemyTarget3.currentSpeed,EnemyTarget3.bullettime,EnemyTarget3.Ranger);
                }
            }
        }
    }
    return *(Vector3*) ((uintptr_t)instance + ActorLinkerOffField[10]);
}



/*
void InitRandomSeed()
{
    srand((unsigned int)time(NULL)); 
}

uint32_t RandomPlayerId()
{
    return 10000 + (rand() % 900000);
}

unsigned long long RandomPlayerUid()
{
    return 100000000000000 + (rand() % 900000000000000); 
}
bool goi = false;
void* (*CreateReportData)(void *instance, uint playerId, unsigned long long playerUid, bool bGMWin, bool bWin, bool isMultiGame);
void* _CreateReportData(void *instance, uint playerId, unsigned long long playerUid, bool bGMWin, bool bWin, bool isMultiGame)
{
    if (instance != NULL && HackSao && bWin == false) {
        bGMWin = true;
        bWin = true;
        isMultiGame = false;;
        playerId = RandomPlayerId();
        playerUid = RandomPlayerUid();
        NSLOGS(@"ĐÃ gọi tới CreateReportData");
        goi = true;
    }
    unhook_one_point(Antiban[4]);
    void* result = CreateReportData(instance, playerId, playerUid, bGMWin, bWin, isMultiGame);
    hook_one_point(Antiban[4],(void*)_CreateReportData);
    return result;
}

void (*CreateDestroyReportData)(void *instance, uint playerId, void *commonData, bool bGMWin);
void _CreateDestroyReportData(void *instance, uint playerId, void *commonData, bool bGMWin)
{
    if (instance != NULL && HackSao && goi) { 
        bGMWin = true;
        playerId = RandomPlayerId();
        NSLOGS(@"ĐÃ gọi tới CreateReportData và CreateDestroyReportData");
    }
    unhook_one_point(Antiban[5]);
    CreateDestroyReportData(instance, playerId, commonData, bGMWin);
    hook_one_point(Antiban[5],(void*)_CreateDestroyReportData);
}
void (*HandleGameSettle)(void* instance,bool bSuccess, bool bShouldDisplayWinLose, Byte GameResult,void* svrData);
void _HandleGameSettle(void* instance,bool bSuccess, bool bShouldDisplayWinLose, Byte GameResult, void* svrData)
{
    if (HackSao && instance) { 
        if(GameResult == 1)
        {
            bSuccess = false;
            bShouldDisplayWinLose = false;
            GameResult = (Byte)1;
            svrData = NULL; 
        }
    }
    unhook_one_point(Antiban[6]);
    HandleGameSettle(instance,bSuccess, bShouldDisplayWinLose, GameResult, svrData);
    hook_one_point(Antiban[6],(void*)_HandleGameSettle);
}

void hookhidemoji()
{
    hook_one_point(hideemoji,(void*)_PlayEmojiEffect);
    isHookedEmoji = true;
}
void unhookhidemoji()
{
    unhook_one_point(hideemoji);
    isHookedEmoji = false;
}
*/

void hook_no_org()
{ 
    hook_reset(
    (void *[]) {
        // (void *)((uintptr_t)ModSkin[0]),
        (void *)((uintptr_t)ModSkin[1]),
        (void *)((uintptr_t)ModSkin[2]),
        (void *)((uintptr_t)ModSkin[6])
    },
    (void *[]) {
        // (void *)_IsHaveHeroSkin,
        (void *)_CanUseSkin,
        (void *)_GetHeroWearSkinId,
        (void *)unpack_postcall
        },
    3);
    //isHookedSkin = true;
}
void un_hook_no_org()
{
    unhook(
    (void *[]) {
        // (void *)((uintptr_t)ModSkin[0]),
        (void *)((uintptr_t)ModSkin[1]),
        (void *)((uintptr_t)ModSkin[2]),
        (void *)((uintptr_t)ModSkin[6])
    },
    3);
    //isHookedSkin = false;
}

/*
void hook_no_orgbutton()
{
    hook(
    (void *[]) {
        (void *)((uintptr_t)ModSkin[8]),
        (void *)((uintptr_t)ModSkin[9])
    },
    (void *[]) {
        (void *)_IsOpenButton,
        (void *)_get_PersonalBtnId
        },
    2);
    isHookedButton = true;

}
void un_hook_no_orgbutton()
{
    unhook(
    (void *[]) {
        (void *)((uintptr_t)ModSkin[8]),
        (void *)((uintptr_t)ModSkin[9])
    },
    2);
    isHookedButton = false;

}
*/

