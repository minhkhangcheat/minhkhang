#import "myhack/handle.h"
#import "xyz/Dis.h"


struct Snowflake {
    float x, y, size, speed, drift;
};

#define SNOW_COUNT 100
static Snowflake snowflakes[SNOW_COUNT];
static bool snowInit = false;
static bool showSnow = false;


void (*_SkillButtonDown)(void *, void*, int, Vector2) = nullptr;
bool (*get_IsHostProfile)() = nullptr;

void TriggerHapticFeedback() {
    if (@available(iOS 10.0, *)) {
        UIImpactFeedbackGenerator *generator = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
        [generator prepare];
        [generator impactOccurred];
    }
}

@interface ImGuiDrawView () <MTKViewDelegate>
@property (nonatomic, strong) id <MTLDevice> device;
@property (nonatomic, strong) id <MTLCommandQueue> commandQueue;
@property (nonatomic) int activeTab;
@property (nonatomic) int targetTab;
@property (nonatomic) float tabAnimationProgress;
@property (nonatomic) float lastTabSwitchTime;
@property (nonatomic, assign) float currentFPS;
@end
UIView *view;
UIView* parentView = [UIApplication sharedApplication].keyWindow.rootViewController.view;

NSFileManager *fileManager1 = [NSFileManager defaultManager];
NSString *documentDir1 = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];

@implementation ImGuiDrawView

void RenderSnowInMenu(ImDrawList* drawList) {
    ImVec2 pos = ImGui::GetWindowPos();   // Vị trí góc trên bên trái của Menu
    ImVec2 size = ImGui::GetWindowSize(); // Kích thước của Menu

    // Khởi tạo hạt tuyết nếu chưa có
    if (!snowInit) {
        for (int i = 0; i < SNOW_COUNT; i++) {
            snowflakes[i].x = (float)(rand() % (int)size.x);
            snowflakes[i].y = (float)(rand() % (int)size.y);
            snowflakes[i].size = (float)(rand() % 3 + 1); // Kích thước nhỏ hơn thường đẹp hơn (1-4px)
            snowflakes[i].speed = (float)(rand() % 15 + 5) / 10.0f; // Tốc độ rơi
        }
        snowInit = true;
    }

    // Thời gian để tạo hiệu ứng đung đưa
    float time = (float)ImGui::GetTime();

    for (int i = 0; i < SNOW_COUNT; i++) {
        // Tạo chuyển động ngang nhẹ nhàng dựa trên hàm Sin
        float drift = sinf(time + i) * 0.5f; 
        snowflakes[i].x += drift;

        // Tính toán vị trí thực tế trên màn hình
        ImVec2 snowPos = ImVec2(pos.x + snowflakes[i].x, pos.y + snowflakes[i].y);

        // Vẽ hạt tuyết (Sử dụng màu trắng có độ trong suốt)
        drawList->AddCircleFilled(snowPos, snowflakes[i].size, IM_COL32(255, 255, 255, 180));

        // Cập nhật vị trí rơi
        snowflakes[i].y += snowflakes[i].speed;

        // Kiểm tra nếu hạt tuyết rơi quá đáy menu hoặc bay quá cạnh bên
        if (snowflakes[i].y > size.y) {
            snowflakes[i].y = -5; // Xuất hiện lại từ phía trên đỉnh
            snowflakes[i].x = (float)(rand() % (int)size.x);
        }
        
        // Giữ hạt tuyết trong giới hạn chiều ngang của Menu
        if (snowflakes[i].x < 0) snowflakes[i].x = size.x;
        if (snowflakes[i].x > size.x) snowflakes[i].x = 0;
    }
}

NSMutableDictionary *heroTextures;

- (void)Guest {
    NSString *encrypteURL = @"https://t.me/zynix32307/";
    NSURL *url = [NSURL URLWithString:encrypteURL];
    NSData *icontb = [NSData dataWithContentsOfURL:url];
    UIImage *img5 = [UIImage imageWithData:icontb];

    [FTNotificationIndicator showNotificationWithImage:img5 title:@"Minh Khang" message:@"Waiting for account logout confirmation..."];

    timer(0.1) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Do you want to delete it?" message:nil preferredStyle:UIAlertControllerStyleAlert];

        UIAlertAction *huy = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {}];

        UIAlertAction *tieptuc = [UIAlertAction actionWithTitle:@"Continue" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            NSString *encrypteURL = @"https://img.upanh.tv/...";
            NSURL *url = [NSURL URLWithString:encrypteURL];
            NSData *icontb = [NSData dataWithContentsOfURL:url];
            UIImage *img5 = [UIImage imageWithData:icontb];

            [FTNotificationIndicator showNotificationWithImage:img5 title:@"Minh Khang" message:@"Logging out. The game will close in 3 seconds."];

            [[NSFileManager defaultManager] removeItemAtPath:[NSString stringWithFormat:@"%@/Documents/beetalk_session.db", NSHomeDirectory()] error:nil];
            exit(3);
        }];

        [tieptuc setValue:[UIColor redColor] forKey:@"titleTextColor"];
        [alert addAction:huy];
        [alert addAction:tieptuc];

        [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:alert animated:true completion:nil];
    });
}


+ (instancetype)sharedInstance {
    return sharedInstance;
}

- (instancetype)initWithNibName:(nullable NSString *)nibNameOrNil bundle:(nullable NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    _device = MTLCreateSystemDefaultDevice();
    _commandQueue = [_device newCommandQueue];
    _activeTab = 1;
    _targetTab = 1;
    _tabAnimationProgress = 1.0f;
    _lastTabSwitchTime = -1.0f;
    if (!_device) abort();
    AddTexturesFromImageData(_device);
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO &io = ImGui::GetIO();
   // StyleImGui();
    StyleImGuiMinhKhang();
    ImFontConfig config;
    ImFontConfig icons_config;
    config.FontDataOwnedByAtlas = false;
    icons_config.MergeMode = true;
    icons_config.PixelSnapH = true;
    icons_config.OversampleH = 2;
    icons_config.OversampleV = 2;
    static const ImWchar icons_ranges[] = {0xf000, 0xf3ff, 0};

    //_espFont = io.Fonts->AddFontFromMemoryTTF(profont_data, profont_size, 40.0f, &config, io.Fonts->GetGlyphRangesVietnamese());    

    _espFont = io.Fonts->AddFontFromMemoryCompressedTTF((void *)zzz_compressed_data, zzz_compressed_size, 40.0f, NULL, io.Fonts->GetGlyphRangesVietnamese());

    _iconFont = io.Fonts->AddFontFromMemoryCompressedTTF(font_awesome_data, font_awesome_size, 40.0f, &icons_config, icons_ranges);

    _iconFont->FontSize = 5;
    io.FontGlobalScale = 0.35f;

    ImGui_ImplMetal_Init(_device);
    return self;
}

+ (void)showChange:(BOOL)open {
    MenDeal = open;
}

+ (BOOL)isMenuShowing {
    return MenDeal;
}

- (MTKView *)mtkView {
    return (MTKView *)self.view;
}

- (void)loadView {
    CGFloat w = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.width;
    CGFloat h = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.height;
    self.view = [[MTKView alloc] initWithFrame:CGRectMake(0, 0, w, h)];
}

-(void)loadsetting{
    if (true) {
        ESPEnable = [saveSetting boolForKey:@"ESPEnable"];
        EspMonster = [saveSetting boolForKey:@"EspMonster"];
        IgnoreInvisibleMon = [saveSetting boolForKey:@"IgnoreInvisibleMon"];
        showMinimapMon = [saveSetting boolForKey:@"showMinimapMon"];
        showMonsterHp = [saveSetting boolForKey:@"showMonsterHp"];
        VipMon = [saveSetting boolForKey:@"VipMon"];
        PlayerLine = [saveSetting boolForKey:@"PlayerLine"];
        PlayerBox = [saveSetting boolForKey:@"PlayerBox"];
        Circle3D = [saveSetting boolForKey:@"Circle3D"];
        PlayerTalent = [saveSetting boolForKey:@"PlayerTalent"];
        CustomIconBT = [saveSetting boolForKey:@"CustomIconBT"];
        CustomX = [saveSetting floatForKey:@"CustomX"];
        CustomY = [saveSetting floatForKey:@"CustomY"];
        PlayerName = [saveSetting boolForKey:@"PlayerName"];
        PlayerDistance = [saveSetting boolForKey:@"PlayerDistance"];
        PlayerAlert = [saveSetting boolForKey:@"PlayerAlert"];
        Drawicon = [saveSetting boolForKey:@"Drawicon"];
        customIcon = [saveSetting boolForKey:@"customIcon"];
        customIconSize = [saveSetting floatForKey:@"customIconSize"];
        if(customIconSize == 0) {
            customIconSize = 1.0f;
        }
        customIconPOS = [saveSetting floatForKey:@"customIconPOS"];
        hiencooldowns = [saveSetting boolForKey:@"hiencooldowns"];
        IgnoreInvisible = [saveSetting boolForKey:@"IgnoreInvisible"];
        AimbotEnable = [saveSetting boolForKey:@"AimbotEnable"];
        MANUALAIM = [saveSetting boolForKey:@"MANUALAIM"];
        Aimhook = [saveSetting boolForKey:@"Aimhook"];
        HackSao = [saveSetting boolForKey:@"HackSao"];
        enableSkill1 = [saveSetting boolForKey:@"enableSkill1"];
        enableSkill2 = [saveSetting boolForKey:@"enableSkill2"];
        enableSkill3 = [saveSetting boolForKey:@"enableSkill3"];
        speedSkill1 = [saveSetting floatForKey:@"speedSkill1"];
        speedSkill2 = [saveSetting floatForKey:@"speedSkill2"];
        speedSkill3 = [saveSetting floatForKey:@"speedSkill3"];
        RangeSkill1 = [saveSetting floatForKey:@"RangeSkill1"];
        RangeSkill2 = [saveSetting floatForKey:@"RangeSkill2"];
        RangeSkill3 = [saveSetting floatForKey:@"RangeSkill3"];
        Rangeauto = [saveSetting boolForKey:@"Rangeauto"];
        AimbotNew = [saveSetting boolForKey:@"AimbotNew"];
        showMinimap = [saveSetting boolForKey:@"showMinimap"];
        StreamerMode = [saveSetting boolForKey:@"StreamerMode"];
        SliderCamera = [saveSetting boolForKey:@"SliderCamera"];
        Camstraight = [saveSetting boolForKey:@"Camstraight"];
        Camera = [saveSetting floatForKey:@"Camera"];
        aimType = [saveSetting integerForKey:@"aimType"];
        drawType = [saveSetting integerForKey:@"drawType"];
        AutoBP = [saveSetting boolForKey:@"AutoBP"];
        AutoBS = [saveSetting boolForKey:@"AutoBS"];
        AutoBPHp = [saveSetting floatForKey:@"AutoBPHp"];
        AutoBSHp = [saveSetting floatForKey:@"AutoBSHp"];
        AutoTT = [saveSetting boolForKey:@"AutoTT"];
        rongta = [saveSetting boolForKey:@"rongta"];
        ChangeName = [saveSetting boolForKey:@"ChangeName"];
        NSString *customnameStr = [saveSetting stringForKey:@"customname"];
        if (customnameStr) {
            customname = [customnameStr UTF8String];
        }
        NameMode = [saveSetting integerForKey:@"NameMode"];
        LinhMode = [saveSetting integerForKey:@"LinhMode"];
        KillMode = [saveSetting integerForKey:@"KillMode"];
        ButtonModeID = [saveSetting integerForKey:@"ButtonModeID"];
        selectedValue2 = [saveSetting integerForKey:@"selectedValue2"];
        ManualMinimap = [saveSetting boolForKey:@"ManualMinimap"];
        MinimapX = [saveSetting floatForKey:@"MinimapX"];
        MinimapY = [saveSetting floatForKey:@"MinimapY"];
        MinimapSizeX = [saveSetting floatForKey:@"MinimapSizeX"];
        MinimapSizeY = [saveSetting floatForKey:@"MinimapSizeY"];
        unlockskin = [saveSetting boolForKey:@"unlockskin"];
        unlocknut = [saveSetting boolForKey:@"unlocknut"];
        selectedValue1 = [saveSetting integerForKey:@"selectedValue1"];
        heroid2 = [saveSetting integerForKey:@"heroid2"];
        skinid2 = [saveSetting integerForKey:@"skinid2"];
    }
}

-(void)saveSetting{
    [saveSetting setBool:ESPEnable forKey:@"ESPEnable"];
    [saveSetting setBool:EspMonster forKey:@"EspMonster"];
    [saveSetting setBool:VipMon forKey:@"VipMon"];
    [saveSetting setBool:IgnoreInvisibleMon forKey:@"IgnoreInvisibleMon"];
    [saveSetting setBool:showMinimapMon forKey:@"showMinimapMon"];
    [saveSetting setBool:showMonsterHp forKey:@"showMonsterHp"];
    [saveSetting setBool:PlayerLine forKey:@"PlayerLine"];
    [saveSetting setBool:PlayerBox forKey:@"PlayerBox"];
    [saveSetting setBool:Circle3D forKey:@"Circle3D"];
    [saveSetting setBool:PlayerTalent forKey:@"PlayerTalent"];
    [saveSetting setBool:CustomIconBT forKey:@"CustomIconBT"];
    [saveSetting setFloat:CustomX forKey:@"CustomX"];
    [saveSetting setFloat:CustomY forKey:@"CustomY"];
    [saveSetting setBool:PlayerName forKey:@"PlayerName"];
    [saveSetting setBool:PlayerDistance forKey:@"PlayerDistance"];
    [saveSetting setBool:PlayerAlert forKey:@"PlayerAlert"];
    [saveSetting setBool:Drawicon forKey:@"Drawicon"];
    [saveSetting setBool:customIcon forKey:@"customIcon"];
    [saveSetting setFloat:customIconSize forKey:@"customIconSize"];
    [saveSetting setFloat:customIconPOS forKey:@"customIconPOS"];
    [saveSetting setBool:hiencooldowns forKey:@"hiencooldowns"];
    [saveSetting setBool:IgnoreInvisible forKey:@"IgnoreInvisible"];
    [saveSetting setBool:AimbotEnable forKey:@"AimbotEnable"];
    [saveSetting setBool:MANUALAIM forKey:@"MANUALAIM"];
    [saveSetting setBool:Aimhook forKey:@"Aimhook"];
    [saveSetting setBool:HackSao forKey:@"HackSao"];
    [saveSetting setBool:enableSkill1 forKey:@"enableSkill1"];
    [saveSetting setBool:enableSkill2 forKey:@"enableSkill2"];
    [saveSetting setBool:enableSkill3 forKey:@"enableSkill3"];
    [saveSetting setFloat:speedSkill1 forKey:@"speedSkill1"];
    [saveSetting setFloat:speedSkill2 forKey:@"speedSkill2"];
    [saveSetting setFloat:speedSkill3 forKey:@"speedSkill3"];
    [saveSetting setFloat:RangeSkill1 forKey:@"RangeSkill1"];
    [saveSetting setFloat:RangeSkill2 forKey:@"RangeSkill2"];
    [saveSetting setFloat:RangeSkill3 forKey:@"RangeSkill3"];
    [saveSetting setBool:AimbotNew forKey:@"AimbotNew"];
    [saveSetting setBool:Rangeauto forKey:@"Rangeauto"];
    [saveSetting setBool:showMinimap forKey:@"showMinimap"];
    [saveSetting setBool:StreamerMode forKey:@"StreamerMode"];  
    [saveSetting setBool:SliderCamera forKey:@"SliderCamera"];
    [saveSetting setBool:Camstraight forKey:@"Camstraight"];
    [saveSetting setFloat:Camera forKey:@"Camera"];
    [saveSetting setInteger:aimType forKey:@"aimType"];
    [saveSetting setInteger:drawType forKey:@"drawType"];
    [saveSetting setBool:AutoBP forKey:@"AutoBP"];
    [saveSetting setBool:AutoBS forKey:@"AutoBS"];
    [saveSetting setFloat:AutoBPHp forKey:@"AutoBPHp"];
    [saveSetting setFloat:AutoBSHp forKey:@"AutoBSHp"];
    [saveSetting setBool:AutoTT forKey:@"AutoTT"];
    [saveSetting setBool:rongta forKey:@"rongta"];
    [saveSetting setBool:ChangeName forKey:@"ChangeName"];
    if (!customname.empty()) {
        NSString *customnameStr = [NSString stringWithUTF8String:customname.c_str()];
        if (customnameStr) {
            [saveSetting setObject:customnameStr forKey:@"customname"];
        }
    }
    [saveSetting setInteger:NameMode forKey:@"NameMode"];
    [saveSetting setInteger:LinhMode forKey:@"LinhMode"];
    [saveSetting setInteger:KillMode forKey:@"KillMode"];
    [saveSetting setInteger:ButtonModeID forKey:@"ButtonModeID"];
    [saveSetting setInteger:selectedValue2 forKey:@"selectedValue2"];
    [saveSetting setBool:ManualMinimap forKey:@"ManualMinimap"];
    [saveSetting setFloat:MinimapX forKey:@"MinimapX"];
    [saveSetting setFloat:MinimapY forKey:@"MinimapY"];
    [saveSetting setFloat:MinimapSizeX forKey:@"MinimapSizeX"];
    [saveSetting setFloat:MinimapSizeY forKey:@"MinimapSizeY"];
    [saveSetting setBool:unlockskin forKey:@"unlockskin"];
    [saveSetting setBool:unlocknut forKey:@"unlocknut"];
    [saveSetting setInteger:selectedValue1 forKey:@"selectedValue1"];
    [saveSetting setInteger:heroid2 forKey:@"heroid2"];
    [saveSetting setInteger:skinid2 forKey:@"skinid2"];
    [saveSetting synchronize];
}

-(void)resetSetting{
    ESPEnable = false;
    PlayerLine = false;
    PlayerBox = false;
    Circle3D = false;
    PlayerTalent = false;
    PlayerName = false;
    PlayerDistance = false;
    PlayerAlert = false;
    Drawicon = false;
    customIcon = false;
    HackSao = false;
    customIconSize = 1.0f;
    customIconPOS = 0;
    hiencooldowns = false;
    IgnoreInvisible = false;
    AimbotEnable = false;
    showMinimap = false;
    StreamerMode = false;
    Aimhook = false;
    Camera = 0.0f;
    unlockskin = false;
    SliderCamera = false;
    Rangeauto = false;
    Camstraight = false;
    mode = 0;
    aimType = 1;
    drawType = 0;
    AutoBP = false;
    AutoBS = false;
    AutoTT = false;
    rongta = false;
    AutoWin = false;
    ChangeName = false;
    MANUALAIM = false;
    RangeSkill = false;
    AimbotNew = false;
    enableSkill1 = false;
    enableSkill2 = false;
    enableSkill3 = false;
    speedSkill1 = 0.0f;
    speedSkill2 = 0.0f;
    speedSkill3 = 0.0f;
    RangeSkill1 = 0.0f;
    RangeSkill2 = 0.0f;
    RangeSkill3 = 0.0f;
    fakerank = false;
    sosao = 0;
    rankht = 0;
    topnumber = 0;
    MinimapX = 0.0f;
    MinimapY = 0.0f;
    MinimapSizeX = 0.0f;
    MinimapSizeY = 0.0f;
    MinimapOrg = Vector2(0.0f, 0.0f);
    MinimapPos = Vector2(0.0f, 0.0f);
    MinimapSizeImGUi = Vector2(0.0f, 0.0f);
    CustomIconBT = false;
    CustomX = 1.0f;
    CustomY = 1.0f;
    ManualMinimap = false;
    EspMonster = false;
    VipMon = false;
    IgnoreInvisibleMon = false;
    showMinimapMon = false;
    showMonsterHp = false;
    unlocknut = false;
    LinhMode = 0;
    ButtonModeID = 0;
    customname = "";
}

- (void)viewDidLoad {
    [super viewDidLoad];
    loadOptionsOnline();
/*
    ImDrawList* draw = ImGui::GetBackgroundDrawList();
if (CheckAntiBand){
    draw->AddText(ImVec2(20, 20), IM_COL32(0, 255, 0, 255), "AntiBand: ON");
}
else
{
    draw->AddText(ImVec2(20, 20), IM_COL32(255, 0, 0, 255), "AntiBand: OFF");
}
*/

    self.mtkView.device = self.device;
    if (!self.mtkView.device) {
        return;
    }
    self.mtkView.delegate = self;
    sharedInstance = self;
    self.mtkView.clearColor = MTLClearColorMake(0, 0, 0, 0);
    self.mtkView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
    self.mtkView.clipsToBounds = YES;
    [self loadsetting];
    CheatHandle();
   // InitRandomSeed();
}

- (void)drawInMTKView:(MTKView *)view {

    

    hideRecordTextfield.secureTextEntry = StreamerMode;
    ImGuiIO &io = ImGui::GetIO();
    io.DisplaySize.x = view.bounds.size.width;
    io.DisplaySize.y = view.bounds.size.height;
    CGFloat framebufferScale = view.window.screen.nativeScale ?: UIScreen.mainScreen.nativeScale;
    io.DisplayFramebufferScale = ImVec2(framebufferScale, framebufferScale);
    static double lastTime = 0.0;
    double currentTime = CACurrentMediaTime();
    io.DeltaTime = (lastTime > 0.0) ? (float)(currentTime - lastTime) : (1.0f / 60.0f);
    lastTime = currentTime;
    self.currentFPS = io.Framerate;

    id<MTLCommandBuffer> commandBuffer = [self.commandQueue commandBuffer];
    static id<MTLTexture> bg_texture = nil;

/*
    if (bg_texture == nil) {
        NSString *base64String = lqmbconfig;
        std::string base64_std_string([base64String UTF8String]);
        bg_texture = LoadTextureFromBase64(self.device, base64_std_string);
    }

*/

    if (MenDeal == true) {
        [self.view setUserInteractionEnabled:YES];
        [self.view.superview setUserInteractionEnabled:YES];
        [menuTouchView setUserInteractionEnabled:YES];
    } else if (MenDeal == false) {
        [self.view setUserInteractionEnabled:NO];
        [self.view.superview setUserInteractionEnabled:NO];
        [menuTouchView setUserInteractionEnabled:NO];
    }

    MTLRenderPassDescriptor* renderPassDescriptor = view.currentRenderPassDescriptor;
    if (renderPassDescriptor != nil) {
        id <MTLRenderCommandEncoder> renderEncoder = [commandBuffer renderCommandEncoderWithDescriptor:renderPassDescriptor];
        [renderEncoder pushDebugGroup:@"ImGui Jane"];
        ImGui_ImplMetal_NewFrame(renderPassDescriptor);
        ImGui::NewFrame();


CGFloat width = 580;//chiêu ngang
        CGFloat height = 330;//chiều cao
        ImGui::SetNextWindowPos(ImVec2((kWidth - width) / 2, (kHeight - height) / 2), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowSize(ImVec2(width, height), ImGuiCond_FirstUseEver);

        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{});

        const float animationDuration = 0.25f;
        float timeSinceSwitch = (_lastTabSwitchTime > 0) ? (ImGui::GetTime() - _lastTabSwitchTime) : animationDuration;
        _tabAnimationProgress = fminf(1.0f, timeSinceSwitch / animationDuration);
        if (_tabAnimationProgress >= 1.0f && _activeTab != _targetTab) {
            _activeTab = _targetTab;
            TriggerHapticFeedback();
            [self saveSetting];
        }

        if (MenDeal == true) {
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 0.07f, 0.57f, 1.0f));
            ImGui::Begin(
    oxorany("Minh Khang"), &MenDeal,
ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize);
ImGui::PopStyleColor();

if (showSnow) {
    RenderSnowInMenu(ImGui::GetWindowDrawList());
}
            ImGui::Columns(2);
            ImGui::SetColumnOffset(1, 120);
            ImGui::Spacing();
            {
                ImVec4 colorInactive = ImGui::GetStyle().Colors[ImGuiCol_Button];
                ImVec4 colorActive = brightAccent;
                ImVec4 colorHover = ImGui::GetStyle().Colors[ImGuiCol_ButtonHovered];
                int tabs[] = {1, 2, 3, 4, 5, 6};
                const char* tabLabels[] = {ICON_FA_LOW_VISION, ICON_FA_CROSSHAIRS, ICON_FA_ROCKET, ICON_FA_COGS, ICON_FA_SHOPPING_BAG, ICON_FA_BUG};
                ImVec2 buttonSize = ImVec2(100, 25);
                for (int i = 0; i < 6; ++i) {
                    int tabId = tabs[i];
                    bool isCurrentActiveReal = (_activeTab == tabId);
                    bool isTarget = (_targetTab == tabId);
                    bool isAnimatingOut = (isCurrentActiveReal && !isTarget && _tabAnimationProgress < 1.0f);
                    bool isAnimatingIn = (isTarget && !isCurrentActiveReal && _tabAnimationProgress < 1.0f);
                    ImVec4 buttonColor = colorInactive;
                    float t_color = 0.0f;
                    if (isTarget) {
                        t_color = (isCurrentActiveReal && !isAnimatingOut) ? 1.0f : _tabAnimationProgress;
                        buttonColor = lerp(colorInactive, colorActive, t_color);
                    } else if (isAnimatingOut) {
                        t_color = 1.0f - _tabAnimationProgress;
                        buttonColor = lerp(colorInactive, colorActive, t_color);
                    }
                    ImGui::PushStyleColor(ImGuiCol_Button, buttonColor);
                    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, lerp(colorHover, ImVec4(colorActive.x*1.1f, colorActive.y*1.1f, colorActive.z*1.1f, colorActive.w), t_color));
                    ImGui::PushStyleColor(ImGuiCol_ButtonActive, lerp(colorActive, secondaryAccent, t_color));
                    ImVec4 textColor = isTarget ? ImVec4(0.0f, 0.0f, 0.0f, 1.0f) : whiteText;
                    ImGui::PushStyleColor(ImGuiCol_Text, textColor);
                    if (ImGui::Button(tabLabels[i], buttonSize)) {
                        if (_targetTab != tabId) {
                            _targetTab = tabId;
                            _lastTabSwitchTime = ImGui::GetTime();
                        }
                    }
                    ImGui::PopStyleColor(4);
                    ImGui::Spacing();
                }

                ImGui::Spacing();
                ImGui::Spacing();
/*
                ImVec2 sidebarCursor = ImGui::GetCursorScreenPos();
                float availableSidebarWidth = ImGui::GetColumnWidth();
                float gaugeRadius = std::max(10.0f, availableSidebarWidth * 0.3f);
                ImVec2 gaugeCenter = ImVec2(sidebarCursor.x + availableSidebarWidth * 0.5f, sidebarCursor.y + gaugeRadius + 15);
                DrawFPSGauge(ImGui::GetWindowDrawList(), gaugeCenter, gaugeRadius, self.currentFPS, 120.0f);
                ImGui::SetCursorScreenPos(ImVec2(sidebarCursor.x, gaugeCenter.y + gaugeRadius + 10));
*/
                //ImGui::Text(oxorany("Minh Khang H4X"));
                //ImGui::Text(oxorany("%.1f FPS"), self.currentFPS);

            }
         
            ImGui::NextColumn();
            {
                
                float contentAlpha = 1.0f;
                int tabToRender = _activeTab;
                if (_activeTab != _targetTab && _tabAnimationProgress < 1.0f) {
                    tabToRender = _targetTab;
                    contentAlpha = _tabAnimationProgress;
                } else {
                    tabToRender = _activeTab;
                    contentAlpha = 1.0f;
                }
                ImGui::PushStyleVar(ImGuiStyleVar_Alpha, contentAlpha);
                
                float contentWidth = ImGui::GetColumnWidth() - ImGui::GetStyle().WindowPadding.x;
     
if (tabToRender == 1) {

    static int ESP_Tab = 0; // 0 = Player | 1 = Monster

    CustomTextNeon(ICON_FA_LOW_VISION " ESP");

    // ===== TAB BUTTON =====
    ImGui::BeginChild("##ESP_TAB_BTN", ImVec2(contentWidth, ImGui::GetFrameHeightWithSpacing() * 1.2f), false);


    if (ImGui::Button("PLAYER", ImVec2(contentWidth * 0.48f, 0)))
        ESP_Tab = 0;
    ImGui::SameLine();
    if (ImGui::Button("MONSTER", ImVec2(contentWidth * 0.48f, 0)))
        ESP_Tab = 1;
    ImGui::EndChild();

    // ========================= PLAYER =========================
    if (ESP_Tab == 0) {

        ImGui::BeginChild("##khung0", ImVec2(contentWidth, ImGui::GetFrameHeightWithSpacing() * 2.0f), false, ImGuiWindowFlags_NoScrollbar);


        ImGui::Checkbox("ESP Enable", &ESPEnable);
        ImGui::SameLine(125);
        ImGui::Checkbox("MiniMap", &showMinimap);
        ImGui::SameLine(210);
        ImGui::Checkbox("Ẩn Hack", &StreamerMode);
        ImGui::SameLine(310);
        ImGui::Checkbox(" K Vẽ Khi Thấy", &IgnoreInvisible);

ImGui::Checkbox("Đường Kẻ", &PlayerLine);
PlayerBox = PlayerLine;   

ImGui::SameLine(125);
ImGui::Checkbox("Bổ Trợ", &PlayerTalent);

ImGui::SameLine(210);
ImGui::Checkbox("Vẽ Icon", &Drawicon);
PlayerName = Drawicon;           

ImGui::SameLine(310);
ImGui::Checkbox("Khoảng Cách", &PlayerDistance);
hiencooldowns = PlayerDistance;  
        ImGui::EndChild();

        ImGui::BeginChild("##khung3", ImVec2(contentWidth, ImGui::GetFrameHeightWithSpacing() * 2.2f), false, ImGuiWindowFlags_NoScrollbar);

        ImGui::Checkbox("Góc Nhìn Tuyển Thủ", &SliderCamera);
        ImGui::SameLine(210);
        ImGui::Checkbox("Khoá Camera", &lockcam);
        ImGui::PushItemWidth(std::max(50.0f,
            ImGui::GetContentRegionAvail().x - ImGui::GetStyle().ItemSpacing.x * 2));
        ImGui::SliderFloat("##SliderView", &Camera, 0.0f, 5.0f);
        ImGui::PopItemWidth();
        ImGui::EndChild();
    }

    // ========================= MONSTER =========================
    if (ESP_Tab == 1) {

        ImGui::BeginChild("##khung2", ImVec2(contentWidth, ImGui::GetFrameHeightWithSpacing() * 2.5f), false, ImGuiWindowFlags_NoScrollbar);

        ImGui::Checkbox("MiniMap", &showMinimapMon);
        ImGui::SameLine(125);
        ImGui::Checkbox("ESP", &EspMonster);
        ImGui::SameLine(210);
        ImGui::Checkbox("Không Vẽ Khi Thấy", &IgnoreInvisibleMon);

        ImGui::Checkbox("Máu", &showMonsterHp);
        ImGui::SameLine(125);
        ImGui::Checkbox("VIP", &VipMon);
        // ImGui::SameLine(210);
        // ImGui::Checkbox("Vòng Tròn 3D", &Circle3D);

        if (showMinimap) {
            ESPEnable = true;
        }
        ImGui::EndChild();
    }
}


else if (tabToRender == 2) {
              CustomTextNeon(ICON_FA_CROSSHAIRS " AIMBOT");  // แสดงข้อความไอคอนเป้า "AIM SKILL"
              ImGui::BeginChild("##khung1", ImVec2(contentWidth, ImGui::GetFrameHeightWithSpacing() * 2.5f), false, ImGuiWindowFlags_NoScrollbar);



//CustomSwitch("BugSkill", &BugSkill);


                            ImGui::Checkbox("Enable", &AimbotEnable);  // เปิด/ปิด Aimbot
    if (AimbotEnable) {
              ImGui::SameLine(135);
              ImGui::Checkbox("Aimbot Xoay", &Aimhook);  // เปิด/ปิด Aim Hook
              ImGui::SameLine(260);
              ImGui::Checkbox("Aimbot Ghim", &MANUALAIM);  // เปิด/ปิดเล็งด้วยตนเอง
             
    if (MANUALAIM) {
            ImGui::Checkbox("Chiêu 1", &enableSkill1);  // เปิด/ปิดทักษะ 1
            ImGui::SameLine(135);
            ImGui::Checkbox("Chiêu 2", &enableSkill2);  // เปิด/ปิดทักษะ 2
            ImGui::SameLine(260);
            ImGui::Checkbox("Chiêu 3", &enableSkill3);  // เปิด/ปิดทักษะ 3);
                        }
                    } else {
                        MANUALAIM = false;
                        enableSkill1 = false;
                        enableSkill2 = false;
                        enableSkill3 = false;
                        RangeSkill = false;
                        Rangeauto = false;
                        AimbotNew = false;
                    }
                    ImGui::EndChild();


                    ImGui::BeginChild("##khung2", ImVec2(contentWidth, ImGui::GetFrameHeightWithSpacing() * 7.5f), true, ImGuiWindowFlags_NoScrollbar);
                    if (MANUALAIM) {
                        float button_height = ImGui::GetFrameHeight();
                        if (enableSkill1) {
                            ImGui::Text("Phạm Vi 1");
                            ImGui::SameLine(60);
                            if (ImGui::Button("-##SpeedSkill1", ImVec2(button_height, button_height))) speedSkill1 = ImClamp(speedSkill1 - 0.01f, 0.0f, 2.0f);
                            ImGui::SameLine();
                            ImGui::PushItemWidth(std::max(50.0f, ImGui::GetContentRegionAvail().x - ImGui::GetStyle().ItemSpacing.x * 3));
                            ImGui::SliderFloat("##SliderSpeedSkill1", &speedSkill1, 0.0f, 2.0f, "%.2f");
                            ImGui::PopItemWidth();
                            ImGui::SameLine();
                            if (ImGui::Button("+##SpeedSkill1", ImVec2(button_height, button_height))) speedSkill1 = ImClamp(speedSkill1 + 0.01f, 0.0f, 2.0f);
                            ImGui::Text("Tốc Độ 1");
                            ImGui::SameLine(60);
                            if (ImGui::Button("-##RangeSkill1", ImVec2(button_height, button_height))) RangeSkill1 = ImClamp(RangeSkill1 - 0.1f, 0.0f, 30.0f);
                            ImGui::SameLine();
                            ImGui::PushItemWidth(std::max(50.0f, ImGui::GetContentRegionAvail().x - ImGui::GetStyle().ItemSpacing.x * 3));
                            ImGui::SliderFloat("##SliderRangeSkill1", &RangeSkill1, 0.0f, 30.0f, "%.2f");
                            ImGui::PopItemWidth();
                            ImGui::SameLine();
                            if (ImGui::Button("+##RangeSkill1", ImVec2(button_height, button_height))) RangeSkill1 = ImClamp(RangeSkill1 + 0.1f, 0.0f, 30.0f);
                        }
                        if (enableSkill2) {
                            ImGui::Text("Phạm Vi 2");
                            ImGui::SameLine(60);
                            if (ImGui::Button("-##SpeedSkill2", ImVec2(button_height, button_height))) speedSkill2 = ImClamp(speedSkill2 - 0.01f, 0.0f, 2.0f);
                            ImGui::SameLine();
                            ImGui::PushItemWidth(std::max(50.0f, ImGui::GetContentRegionAvail().x - ImGui::GetStyle().ItemSpacing.x * 3));
                            ImGui::SliderFloat("##SliderSpeedSkill2", &speedSkill2, 0.0f, 2.0f, "%.2f");
                            ImGui::PopItemWidth();
                            ImGui::SameLine();
                            if (ImGui::Button("+##SpeedSkill2", ImVec2(button_height, button_height))) speedSkill2 = ImClamp(speedSkill2 + 0.01f, 0.0f, 2.0f);
                            ImGui::Text("Tốc Độ 2");
                            ImGui::SameLine(60);
                            if (ImGui::Button("-##RangeSkill2", ImVec2(button_height, button_height))) RangeSkill2 = ImClamp(RangeSkill2 - 0.1f, 0.0f, 30.0f);
                            ImGui::SameLine();
                            ImGui::PushItemWidth(std::max(50.0f, ImGui::GetContentRegionAvail().x - ImGui::GetStyle().ItemSpacing.x * 3));
                            ImGui::SliderFloat("##SliderRangeSkill2", &RangeSkill2, 0.0f, 30.0f, "%.2f");
                            ImGui::PopItemWidth();
                            ImGui::SameLine();
                            if (ImGui::Button("+##RangeSkill2", ImVec2(button_height, button_height))) RangeSkill2 = ImClamp(RangeSkill2 + 0.1f, 0.0f, 30.0f);
                        }
                        if (enableSkill3) {
                            ImGui::Text("Phạm Vi 3");
                            ImGui::SameLine(60);
                            if (ImGui::Button("-##SpeedSkill3", ImVec2(button_height, button_height))) speedSkill3 = ImClamp(speedSkill3 - 0.01f, 0.0f, 2.0f);
                            ImGui::SameLine();
                            ImGui::PushItemWidth(std::max(50.0f, ImGui::GetContentRegionAvail().x - ImGui::GetStyle().ItemSpacing.x * 3));
                            ImGui::SliderFloat("##SliderSpeedSkill3", &speedSkill3, 0.0f, 2.0f, "%.2f");
                            ImGui::PopItemWidth();
                            ImGui::SameLine();
                            if (ImGui::Button("+##SpeedSkill3", ImVec2(button_height, button_height))) speedSkill3 = ImClamp(speedSkill3 + 0.01f, 0.0f, 2.0f);
                            ImGui::Text("Tốc Độ 3");
                            ImGui::SameLine(60);
                            if (ImGui::Button("-##RangeSkill3", ImVec2(button_height, button_height))) RangeSkill3 = ImClamp(RangeSkill3 - 0.1f, 0.0f, 30.0f);
                            ImGui::SameLine();
                            ImGui::PushItemWidth(std::max(50.0f, ImGui::GetContentRegionAvail().x - ImGui::GetStyle().ItemSpacing.x * 3));
                            ImGui::SliderFloat("##SliderRangeSkill3", &RangeSkill3, 0.0f, 30.0f, "%.2f");
                            ImGui::PopItemWidth();
                            ImGui::SameLine();
                            if (ImGui::Button("+##RangeSkill3", ImVec2(button_height, button_height))) RangeSkill3 = ImClamp(RangeSkill3 + 0.1f, 0.0f, 30.0f);
                        }
                    }

                         int selectedAimWhen = aimType;        // เก็บค่าที่เลือกไว้ในตัวแปร aimType
                         int selecteddraw = drawType;          // เก็บค่าที่เลือกไว้ในตัวแปร drawType

                         // ตัวเลือกสำหรับ "Aim Skill" หรือวิธีการเล็ง
                            const char* aimWhenOptions[] = {"Aim Theo Tỉ Lệ Máu Thấp", "Aim Theo Tỉ Lệ % Máu", "Aim Theo Địch Ở Gần Nhất", "Aim Theo Địch Gần Tia Nhất"};

                            ImGui::PushItemWidth(contentWidth * 0.8f);  // กำหนดความกว้างของ Combo Box เป็น 80% ของพื้นที่เนื้อหา
                        if (ImGui::Combo("Aimbot", &selectedAimWhen, aimWhenOptions, IM_ARRAYSIZE(aimWhenOptions))) {
                            aimType = selectedAimWhen;   // บันทึกค่าที่เลือกลงตัวแปร aimType
                           [self saveSetting];          // เรียกเมธอดบันทึกการตั้งค่า (โค้ด Objective-C)
}
                           ImGui::PopItemWidth();  // คืนค่าความกว้างกลับเป็นปกติ

                           // ตัวเลือกสำหรับ "Draw Objects" หรือการแสดงวัตถุ
                           const char* drawOptions[] = {"Không Vẽ", "Luôn Luôn Vẽ", "Vẽ Khi Chiêu"};

                          ImGui::PushItemWidth(contentWidth * 0.8f);  // กำหนดความกว้างของ Combo Box เป็น 80% ของพื้นที่เนื้อหา
                        if (ImGui::Combo("Tuỳ Chọn", &selecteddraw, drawOptions, IM_ARRAYSIZE(drawOptions))) {
                          drawType = selecteddraw;     // บันทึกค่าที่เลือกลงตัวแปร drawType
                         [self saveSetting];          // เรียกเมธอดบันทึกการตั้งค่า
}
                         ImGui::PopItemWidth(); 

ImGui::Text(oxorany("Aimbot Xoay: Xoay Chiêu Đi Đâu Khi Nhả Thì Tự Động Trúng Địch"));

ImGui::Text(oxorany("Aimbot Ghim: Xoay Chiêu Đi Đâu Cũng Tự Ghim Vào Địch"));

ImGui::Text(oxorany("Aim Tướng: Elsu, Grakk, Natalya, Yue, Stuart, Enzo, Raz, Gildur,..."));

ImGui::Text(oxorany("Liên Hệ Admin: Telegram:@zynix32307 || Zalo: 0869641898 || Minh Khang"));
                         ImGui::EndChild();
                }
else if (tabToRender == 3) {

    static int MOD_Tab = 0; // 0 = CUSTOM | 1 = MOD

    CustomTextNeon(ICON_FA_ROCKET " MOD x AUTO");

    // ===== TAB BUTTON =====
    ImGui::BeginChild("##MOD_TAB_BTN", ImVec2(contentWidth, ImGui::GetFrameHeightWithSpacing() * 1.2f), false);


    if (ImGui::Button("CUSTOM", ImVec2(contentWidth * 0.48f, 0)))
        MOD_Tab = 0;
    ImGui::SameLine();
    if (ImGui::Button("MODSKIN", ImVec2(contentWidth * 0.48f, 0)))
        MOD_Tab = 1;
    ImGui::EndChild();

    // ========================= CUSTOM =========================
    if (MOD_Tab == 0) {

        ImGui::BeginChild("##khung1", ImVec2(contentWidth, ImGui::GetFrameHeightWithSpacing() * 5.5f), false, ImGuiWindowFlags_NoScrollbar);

        ImGui::Checkbox("Auto Bộc Phá", &AutoBP);
        ImGui::SameLine(135);
        ImGui::PushItemWidth(std::max(50.0f,
            ImGui::GetContentRegionAvail().x - ImGui::GetStyle().ItemSpacing.x * 2));
        ImGui::SliderFloat("##AutoBP", &AutoBPHp, 0.1f, 20.0f, "%.2f %%HP");


        ImGui::PopItemWidth();

        ImGui::Checkbox("Auto Băng Sương", &AutoBS);
        ImGui::SameLine(135);
        ImGui::PushItemWidth(std::max(50.0f,
            ImGui::GetContentRegionAvail().x - ImGui::GetStyle().ItemSpacing.x * 2));
        ImGui::SliderFloat("##AutoBs", &AutoBSHp, 0.1f, 100.0f, "%.2f %%HP");


        ImGui::PopItemWidth();

        ImGui::Checkbox("Auto Trừng trị", &AutoTT);
        if (AutoTT) {
            ImGui::SameLine(135);
            ImGui::Checkbox("Rồng - Tà Thần", &rongta);
        }

        // ImGui::BeginChild("##khung_custom2", ImVec2(contentWidth, ImGui::GetFrameHeightWithSpacing() * 3.0f), false, ImGuiWindowFlags_NoScrollbar);


        ImGui::Checkbox("Bug Chiêu Xa", &BugSkillDistance);

        int namechange = NameMode;
        const char* nameWhenOptions[] = {"Tên Gốc", "Chiêu Time Tên", "Tên Tuỳ Chỉnh", "Tên Tướng", "Tên Cá Nhân"};
        ImGui::PushItemWidth(contentWidth * 0.5f);
        if (ImGui::Combo("##Display Name", &namechange, nameWhenOptions, IM_ARRAYSIZE(nameWhenOptions))) {
            NameMode = namechange;
            [self saveSetting];
        }
        ImGui::PopItemWidth();
        ImGui::SameLine();
        ImGui::Checkbox("Đổi Tên", &ChangeName);

        ImGui::EndChild();
    }

    // ========================= MOD =========================
    if (MOD_Tab == 1) {

        ImGui::BeginChild("##khung2", ImVec2(contentWidth, ImGui::GetFrameHeightWithSpacing() * 6.0f), false, ImGuiWindowFlags_NoScrollbar);



        ImGui::Checkbox("Mở Khoá Toàn Bộ Skin", &unlockskin);

        ImGui::PushItemWidth(contentWidth * 0.8f);
        DrawModNotify();
        [self saveSetting];
        ImGui::PopItemWidth();

        ImGui::PushItemWidth(contentWidth * 0.8f);
        DrawModButton();
        [self saveSetting];
        ImGui::PopItemWidth();

        const char* LinhWhenOptions[] = {"[ Mặc Định ]", "Skin Lính Conan", "Skin Lính Yêu Tinh"};
        ImGui::PushItemWidth(contentWidth * 0.8f);
        if (ImGui::Combo("Skin Lính", &LinhMode, LinhWhenOptions, IM_ARRAYSIZE(LinhWhenOptions))) {
            [self saveSetting];
        }
        ImGui::PopItemWidth();

        ImGui::EndChild();
    }
}
                else if (tabToRender == 4) {
                    CustomTextNeon(ICON_FA_COGS " MOD RANK");
                    //ImGui::BeginChild("##khung0", ImVec2(contentWidth, ImGui::GetFrameHeightWithSpacing() * 10.0f), false, ImGuiWindowFlags_NoScrollbar);

                    ImGui::Checkbox("Bật Mod", &fakerank);
                    ImGui::SliderInt("Sao", &sosao, 0, 9999);
                    ImGui::SliderInt("Rank", &rankht, 1, 32);
                    ImGui::SliderInt("Top Rank", &topnumber, 0, 100);

ImGui::Text(oxorany("MOD SAO TỪ 1 ĐẾN 9999"));

ImGui::Text(oxorany("MOD RANK TỪ ĐỒNG I ĐẾN CHIẾN THẦN"));

ImGui::Text(oxorany("MOD TOP RANK TỪ TOP 1 BXH ĐẾN TOP 100 BXH"));

ImGui::Text(oxorany("Liên Hệ Admin: Telegram:@zynix32307 || Zalo: 0869641898 || Nguyễn Minh Khang"));


                    //CustomSwitch("BugSkill", &BugSkillDistance);

                    //ImGui::EndChild();
                }
                else if (tabToRender == 5) {
                    CustomTextNeon(ICON_FA_SHOPPING_BAG " Đổi Đồ VIP");

              ImGui::Checkbox("Đổi Đồ Active", &doiitem);

    ImGui::SameLine(150);
    ImGui::Checkbox("Check Full Slot", &fullslot);
    ImGui::SameLine(280);
    ImGui::Checkbox("Đổi Đồ", &muaitem);

    if (muaitem) {
                ImGui::BeginGroupPanel("Chọn Đồ Đổi", ImVec2(-1, 0));
                ImGui::Spacing();
ImGui::PushItemWidth(contentWidth * 0.5f);                           
 ShowSequentialItemCombosWithCheckbox();
ImGui::PopItemWidth();
                ImGui::Spacing();
                ImGui::EndGroupPanel();
                    }

               }
                else if (tabToRender == 6) {
                    CustomTextNeon(ICON_FA_BUG " Custom Icon");
ImGui::BeginChild("##khung1", ImVec2(contentWidth, ImGui::GetFrameHeightWithSpacing() * 5.5f), false, ImGuiWindowFlags_NoScrollbar);


                    //ImGui::BeginChild("##khung0", ImVec2(contentWidth, ImGui::GetFrameHeightWithSpacing() * 11.0f), false, ImGuiWindowFlags_NoScrollbar);
                    //CustomSwitch("MANUAL MINIMAP", &ManualMinimap);

//CustomSwitch("Xoá Lịch Sử Đấu", &HackSao);
/*
    ImGui::Checkbox("Bật Emoij", &spamemoji);
    ImGui::SameLine();

    static const char* OpenSpam[] = { "Spam Emoij Mình", "Spam Emoij Tất Cả", "Spam Emoij Địch"}; 
ImGui::PushItemWidth(150);
ImGui::Combo("##AutoSpamEmoij", &spamMode, OpenSpam, IM_ARRAYSIZE(OpenSpam));
ImGui::PopItemWidth();
//ImGui::SameLine();
//CustomCheckbox("Ẩn Emoij", &HideEmoji);
if(spamMode == 1 || spamMode == 2){
ImGui::SliderInt("Time Delay", &delayspam, 1, 1000);
}
*/

    DrawHeroSkinInfo();
    //CustomSwitch("Mở Khóa Skin", &unlockskin);	
    //ImGui::SameLine(240);
//    ImGui::Checkbox("Fix Skin SSS", &fixskin);

    //CustomSwitch("Mod Nút", &unlocknut);
 

//    static bool prevFixSkin = false;
//    if (fixskin) {               
//        if(!prevFixSkin){
        // RestoreAllThenApplySelected();
//            }
//    } else if (prevFixSkin && !// fixskin) {
//        StartRestoreAllAsync();
//    }
//    prevFixSkin = fixskin;
//    DrawFixPanelImGui();
                                        
//    ImGui::EndChild();

                         // ImGui::BeginChild("##khung2", ImVec2(contentWidth, ImGui::GetFrameHeightWithSpacing() * 3.5f), true, ImGuiWindowFlags_NoScrollbar);

  ImGui::Checkbox("Tuỳ Chỉnh Bổ Trợ", &CustomIconBT);
                    if (CustomIconBT) {
                        ImGui::PushItemWidth(contentWidth * 0.7f);
                        ImGui::SliderFloat("Chiều Ngang", &CustomX, 0.0f, 2000.0f);


                        ImGui::SliderFloat("Chiều Dọc", &CustomY, 0.0f, 2000.0f);


                        ImGui::PopItemWidth();
}

ImGui::Checkbox("Snow Enable", &showSnow);



    ImGui::EndChild();
                }
                ImGui::PopStyleVar();
            }
            ImGui::End();
        }
        ImDrawList* draw_list = ImGui::GetBackgroundDrawList();
        DrawESP(draw_list);
      //  DrawSpamEmoji(draw_list);
        Muabando();//Auto
        ImGui::Render();
        ImDrawData* draw_data = ImGui::GetDrawData();
        ImGui_ImplMetal_RenderDrawData(draw_data, commandBuffer, renderEncoder);
        [renderEncoder popDebugGroup];
        [renderEncoder endEncoding];
        [commandBuffer presentDrawable:view.currentDrawable];
    }
    [commandBuffer commit];
}

- (void)mtkView:(MTKView*)view drawableSizeWillChange:(CGSize)size {
}

- (void)updateIOWithTouchEvent:(UIEvent *)event {
    UITouch *anyTouch = event.allTouches.anyObject;
    CGPoint touchLocation = [anyTouch locationInView:self.view];
    ImGuiIO &io = ImGui::GetIO();
    io.MousePos = ImVec2(touchLocation.x, touchLocation.y);
    BOOL hasActiveTouch = NO;
    for (UITouch *touch in event.allTouches) {
        if (touch.phase != UITouchPhaseEnded && touch.phase != UITouchPhaseCancelled) {
            hasActiveTouch = YES;
            break;
        }
    }
    io.MouseDown[0] = hasActiveTouch;
}
@end