#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <UIKit/UIAlertView.h>
#import <UIKit/UIControl.h>
//#include <JRMemory/MemScan.h>
//Actually if you need JRMemory, just add it back
