#import <Foundation/Foundation.h>
#include <filesystem>
#include "RestoreBackups.h"
#include <string>
#include <system_error>

namespace fs = std::filesystem;

static inline bool endsWithBak(const std::string& s) {
    return s.size() >= 4 && s.rfind(".bak") == s.size() - 4;
}

restore_utils::RestoreStats
restore_utils::RestoreAllBackupsInDir(const fs::path& root) {
    RestoreStats st{};
    if (!fs::exists(root)) return st;

    std::error_code ec;
    fs::directory_options opts = fs::directory_options::skip_permission_denied;

    for (fs::recursive_directory_iterator it(root, opts, ec), end; it != end; it.increment(ec)) {
        if (ec) { ec.clear(); continue; }
        if (!it->is_regular_file()) continue;

        const fs::path bakPath = it->path();
        const std::string s = bakPath.string();
        if (!endsWithBak(s)) continue;

        st.total++;
        fs::path origPath = fs::path(s.substr(0, s.size() - 4));

        std::error_code ec2;
        fs::remove(origPath, ec2);          // ok nếu không tồn tại
        ec2.clear();
        fs::rename(bakPath, origPath, ec2); // .bak -> gốc
        if (!ec2) st.restored++; else st.failed++;
    }
    return st;
}

extern "C" int RestoreAllBackupsInDirC(const char* root_path_utf8) {
    if (!root_path_utf8 || !*root_path_utf8) return 0;
    auto st = restore_utils::RestoreAllBackupsInDir(fs::path(root_path_utf8));
    return st.restored;
}
const std::filesystem::path kResourcesDir = []{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docs = [paths firstObject];         
    std::filesystem::path base([docs fileSystemRepresentation]);
    return base / "Resources/1.59.1/Ages/Prefab_Characters/Prefab_Hero";                  
}();
