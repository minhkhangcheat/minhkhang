// UiFixPanel.mm
#include <fstream> 
#import <Foundation/Foundation.h>
#if __has_include(<filesystem>)
  #include <filesystem>
  namespace fs = std::filesystem;
#elif __has_include(<experimental/filesystem>)
  #include <experimental/filesystem>
  namespace fs = std::experimental::filesystem;
#endif

#include <filesystem>
#include <vector>
#include <string>
#include <thread>
#include <atomic>
#include <regex>
#include "../../imgui/imgui.h"
#import "UiFixPanel.h"
#include <mutex>
#include "RestoreBackups.h"

using namespace restore_utils;
extern "C" void empty_resourceverification_assetbundle(void);
extern "C" void backup_related_files(const char* pkgPath);
extern "C" bool restore_related_files(const char* pkgPath);

static bool g_indexAutoLoaded = false;

static inline bool endsWithBak(const std::string& s) {
    return s.size() >= 4 && s.rfind(".bak") == s.size() - 4;
}

static std::vector<std::string> g_LogLines;
static std::mutex g_LogMutex;
static std::string gSelectedPkgPath;
void AddLog(const std::string &msg) {
    std::lock_guard<std::mutex> lock(g_LogMutex);
    g_LogLines.push_back(msg);
}
extern "C" int processOnePkg_withDict(const char* pkgPath,
                                      const char* rulesPath,
                                      const char* outDir);


#ifndef IMGUI_VERSION_NUM
#define IMGUI_VERSION_NUM 0
#endif

static inline void BeginDisabledCompat(bool disabled) {
#if IMGUI_VERSION_NUM >= 18600
    if (disabled) ImGui::BeginDisabled();
#else
    if (disabled) ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ImGui::GetStyle().Alpha * 0.5f);
#endif
}
static inline void EndDisabledCompat(bool disabled) {
#if IMGUI_VERSION_NUM >= 18600
    if (disabled) ImGui::EndDisabled();
#else
    if (disabled) ImGui::PopStyleVar();
#endif
}
namespace fs = std::filesystem;

// =================== GitHub config ===================
//https://raw.githubusercontent.com/shinplus999/shin/main/rules_index.json

static char g_ghOwner[64]  = "shinplus999";
static char g_ghRepo[64]   = "shin";
static char g_ghPath[128]  = "rules";     // thư mục chứa rules*.json
static char g_ghBranch[64] = "main";
static char g_ghToken[100] = "";          // optional

// =================== State ===================
struct RuleEntry {
    std::string name;         // rules123.json
    std::string download_url; // direct download
};
static std::vector<RuleEntry> g_ruleEntries;
static int  g_ruleIndex = 0;

static bool g_fixToggle = false, g_prevToggle = false;
static std::atomic<bool> g_running{false};
static char g_status[256] = "Idle.";

// =================== Helper HTTP ===================
static NSData* httpGET(NSString* url, NSDictionary<NSString*,NSString*>* headers, NSInteger* httpCodeOut) {
    NSMutableURLRequest* req = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    req.HTTPMethod = @"GET";
    [req setValue:@"Mozilla/5.0 (ImGuiFixer)" forHTTPHeaderField:@"User-Agent"];
    for (NSString* k in headers) [req setValue:headers[k] forHTTPHeaderField:k];

    __block NSData* data = nil;
    __block NSURLResponse* resp = nil;
    __block NSError* err = nil;
    dispatch_semaphore_t sem = dispatch_semaphore_create(0);

    [[[NSURLSession sharedSession] dataTaskWithRequest:req completionHandler:^(NSData* d, NSURLResponse* r, NSError* e){
        data = d; resp = r; err = e;
        dispatch_semaphore_signal(sem);
    }] resume];

    dispatch_semaphore_wait(sem, DISPATCH_TIME_FOREVER);
    if (httpCodeOut) *httpCodeOut = [(NSHTTPURLResponse*)resp statusCode];
    if (err) return nil;
    return data;
}

// =================== Index config (1 file chứa id & name) ===================
static char g_indexJsonName[128] = "rules_index.json"; 

static std::string MakeRawURL(const char* pathFile) {
    char buf[512];
    snprintf(buf,sizeof(buf),
             "https://raw.githubusercontent.com/%s/%s/%s/%s",
             g_ghOwner, g_ghRepo, g_ghBranch, pathFile);
    return buf;
}

// =================== Index state ===================
struct IndexEntry { std::string id3; std::string name; };
static std::vector<IndexEntry> g_indexEntries;
static int g_indexSel = -1;
// =================== Load index (1 file json) ===================
static void ReloadIndexFromGitHub() {
    snprintf(g_status, sizeof(g_status), "Loading index...");
    g_indexEntries.clear();

    // Ghép URL RAW cho file index
    std::string rel = std::string(g_ghPath) + "/" + g_indexJsonName; 
    std::string url = MakeRawURL(rel.c_str());

    NSMutableDictionary* headers = [@{} mutableCopy];
    if (strlen(g_ghToken) > 0) {
        [headers setValue:[NSString stringWithFormat:@"token %s", g_ghToken] forKey:@"Authorization"];
    }

    NSInteger code = 0;
    NSData* data = httpGET([NSString stringWithUTF8String:url.c_str()], headers, &code);
    if (!data || code != 200) { snprintf(g_status,sizeof(g_status),"HTTP %ld", (long)code); return; }

    NSError* jerr = nil;
    id json = [NSJSONSerialization JSONObjectWithData:data options:0 error:&jerr];
    if (jerr || !json) { snprintf(g_status,sizeof(g_status),"Parse error"); return; }

    if ([json isKindOfClass:[NSArray class]]) {
        for (id it in (NSArray*)json) {
            if (![it isKindOfClass:[NSDictionary class]]) continue;
            NSString* sid = ((NSDictionary*)it)[@"id"];
            NSString* sname = ((NSDictionary*)it)[@"name"];
            if (!sid || !sname) continue;

            // Chuẩn hoá id thành 3 ký tự (zero-pad nếu cần)
            std::string id3 = [sid UTF8String];
            if (id3.size() < 3) id3 = std::string(3 - id3.size(), '0') + id3;
            if (id3.size() > 3) id3 = id3.substr(id3.size()-3);

            IndexEntry e; e.id3 = id3; e.name = [sname UTF8String];
            g_indexEntries.push_back(std::move(e));
        }
    } else if ([json isKindOfClass:[NSDictionary class]]) {

        NSDictionary* dict = (NSDictionary*)json;
        for (NSString* key in dict) {
            NSString* sname = dict[key];
            if (![sname isKindOfClass:[NSString class]]) continue;
            std::string id3 = [key UTF8String];
            if (id3.size() < 3) id3 = std::string(3 - id3.size(), '0') + id3;
            if (id3.size() > 3) id3 = id3.substr(id3.size()-3);

            IndexEntry e; e.id3 = id3; e.name = [sname UTF8String];
            g_indexEntries.push_back(std::move(e));
        }
    }

if (g_indexEntries.empty()) {
    snprintf(g_status,sizeof(g_status),"Index empty");
} else {
    if (g_indexSel >= (int)g_indexEntries.size()) g_indexSel = -1;
    snprintf(g_status,sizeof(g_status),"Loaded %zu entries", g_indexEntries.size());
}

}

static fs::path DownloadRuleByIdToTemp(const std::string& id3) {
    std::string filename = std::string("rules") + id3 + ".json";
    std::string rel = std::string(g_ghPath) + "/" + filename;  
    std::string url = MakeRawURL(rel.c_str());

    NSInteger code = 0;
    NSMutableDictionary* headers = [@{} mutableCopy];
    if (strlen(g_ghToken) > 0) {
        [headers setValue:[NSString stringWithFormat:@"token %s", g_ghToken] forKey:@"Authorization"];
    }
    NSData* data = httpGET([NSString stringWithUTF8String:url.c_str()], headers, &code);
    if (!data || code != 200) return {};

    fs::path tmp = fs::temp_directory_path() / filename;
    std::ofstream f(tmp, std::ios::binary);
    f.write((const char*)data.bytes, (std::streamsize)data.length);
    return tmp;
}


// =================== HeroId extract & pkg finder ===================
static std::string HeroIdFromRulesName(const std::string& rulesName) {
    size_t p1 = std::string("rules").size();
    size_t p2 = rulesName.find('.', p1);
    if(p2==std::string::npos) return "";
    return rulesName.substr(p1,p2-p1);
}


static fs::path FindPkgByHero(const std::string& heroId) {
    if (!fs::exists(kResourcesDir)) {
        AddLog("[FixRSC] kResourcesDir not found: " + kResourcesDir.string());
        return {};
    }
    for (auto &e: fs::directory_iterator(kResourcesDir)) {
        if (!e.is_regular_file()) continue;
        if (endsWithBak(e.path().string())) continue;
        auto s = e.path().filename().string();
        if (s.rfind("Actor_", 0) == 0 && s.find("_Actions.pkg.bytes") != std::string::npos) {
            auto stem = e.path().stem().stem().string(); // Actor_XXX_Actions
            auto p1 = stem.find('_'); auto p2 = stem.find('_', p1 + 1);
            if (p1 != std::string::npos && p2 != std::string::npos) {
                auto id = stem.substr(p1 + 1, p2 - p1 - 1);
                if (id == heroId) {
                    AddLog(std::string("[FixRSC] Found pkg for hero ") + heroId + ": " + e.path().string());
                    // Gán cho global để nút Restore dùng
                    gSelectedPkgPath = e.path().string();
                    return e.path();
                }
            }
        }
    }
    AddLog(std::string("[FixRSC] No pkg found for hero ") + heroId +
           " under " + kResourcesDir.string());
    return {};
}


static void RunFixOnceFromGitHub() {
    if (g_indexEntries.empty()) { snprintf(g_status,sizeof(g_status),"Loading Failed!"); g_running=false; return; }
    IndexEntry e = g_indexEntries[g_indexSel];

    snprintf(g_status,sizeof(g_status),"Loading %s ...", e.id3.c_str());
    fs::path ruleTmp = DownloadRuleByIdToTemp(e.id3);
    if (ruleTmp.empty()) { snprintf(g_status,sizeof(g_status),"Failed!"); g_running=false; return; }

    // Tìm pkg theo heroId = id3
    std::string heroId = e.id3;
    fs::path pkg = FindPkgByHero(heroId);
    if (pkg.empty()) { snprintf(g_status,sizeof(g_status),"Not found"); g_running=false; return; }

    empty_resourceverification_assetbundle();
    int changed = processOnePkg_withDict(pkg.string().c_str(),
                                         ruleTmp.string().c_str(),
                                         kResourcesDir.string().c_str());
if (changed > 0) snprintf(g_status,sizeof(g_status),"Success %s (changes=%d)", e.id3.c_str(), changed);
else snprintf(g_status,sizeof(g_status),"Success %s (no changes)", e.id3.c_str());
    g_fixToggle = false; g_running = false;
}

void RestoreAllThenApplySelected() {
    // 0) Kiểm tra danh sách index
    if (g_indexEntries.empty()) {
        snprintf(g_status, sizeof(g_status), "No index.");
        g_running = false;
        return;
    }

    // 1) RESTORE TẤT CẢ trước
    //snprintf(g_status, sizeof(g_status), "Restoring ALL backups...");
    auto st = restore_utils::RestoreAllBackupsInDir(kResourcesDir);
    AddLog("[FixRSC] RestoreAll: total=" + std::to_string(st.total) +
           " restored=" + std::to_string(st.restored) +
           " failed=" + std::to_string(st.failed));
    // (khuyến nghị) dọn cache sau restore
    empty_resourceverification_assetbundle();

    // 2) APPLY rules theo id đang chọn
    //snprintf(g_status, sizeof(g_status), "Applying selected rules...");
    RunFixOnceFromGitHub();   // hàm này tải rulesXXX.json theo mục đang chọn & xử lý

    // 3) Hạ cờ chạy
    g_running = false;
}

static bool g_autoApplyOnSelect = true;
extern "C" void DrawFixPanelImGui(void) {
    // ---- Auto-load index đúng 1 lần khi mở panel ----
    if (!g_indexAutoLoaded && !g_running.load()) {
        g_running = true;
        g_indexAutoLoaded = true;
        std::thread([]{
            @autoreleasepool{
                ReloadIndexFromGitHub();
                g_running = false;   // hạ flag sau khi load xong
            }
        }).detach();
    }

    ImGui::Text("Cấu Hình Fix Skin:");

    const char* preview = (g_indexSel >= 0 && g_indexSel < (int)g_indexEntries.size())
        ? g_indexEntries[g_indexSel].name.c_str()
        : u8"___ Chọn skin ___";

    bool changed = false;
    if (ImGui::BeginCombo("Select Skin", preview)) {
        for (int i = 0; i < (int)g_indexEntries.size(); ++i) {
            bool is_selected = (g_indexSel == i);
            if (ImGui::Selectable(g_indexEntries[i].name.c_str(), is_selected)) {
                g_indexSel = i;
                changed = true; // người dùng vừa chọn
            }
            if (is_selected) ImGui::SetItemDefaultFocus();
        }
        ImGui::EndCombo();
    }

    // ---- Tự chạy khi người dùng chọn một skin ----
    if (g_autoApplyOnSelect && changed && g_indexSel >= 0 && !g_running.load()) {
        g_running = true;
        std::thread([]{
            @autoreleasepool{

                RestoreAllThenApplySelected();
                empty_resourceverification_assetbundle();

            }
        }).detach();
    }
}
void StartRestoreAllAsync(void) {
    if (g_running.load()) return;
    g_running = true;
    std::thread([]{
        @autoreleasepool{
            auto st = restore_utils::RestoreAllBackupsInDir(kResourcesDir);
            empty_resourceverification_assetbundle();

            g_running = false;
        }
    }).detach();
}