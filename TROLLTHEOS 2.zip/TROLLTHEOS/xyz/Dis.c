#import "Disz.h"
#import "../mylib/fishhook.h" // Trỏ tới file header của fishhook

#import <dlfcn.h>
#import <stdlib.h>
#import <string.h>
#import <sys/types.h>
#import <mach-o/dyld.h>

// Bạn có thể viết các hàm hook của bạn ở đây
// Ví dụ:
// static int (*orig_close)(int);
// int my_close(int fd) { return orig_close(fd); }

void init_hooks() {
    // Gọi hàm rebind_symbols bình thường vì nó đã được định nghĩa ở file fishhook.c
    // rebind_symbols((struct rebinding[1]){{"close", my_close, (void *)&orig_close}}, 1);
}