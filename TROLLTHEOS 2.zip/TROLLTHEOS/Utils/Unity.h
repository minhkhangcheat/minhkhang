
#include "hack/Vector2.h"
#include "hack/Quaternion.h"
#include "hack/Color.h"
#include "hack/VInt3.h"
#define LOG_TAG  "PusexPrivate.xyz"
float NormalizeAngle(float angle) {
    while (angle > 360)
        angle -= 360;
    while (angle < 0)
        angle += 360;
    return angle;
}

Vector3 NormalizeAngles(Vector3 angles) {
    angles.x = NormalizeAngle(angles.x);
    angles.y = NormalizeAngle(angles.y);
    angles.z = NormalizeAngle(angles.z);
    return angles;
}
Vector3 Lerp(Vector3 &a,const Vector3 &b, float t) {
    if(Vector3::Distance(a,b) > 1) a = b;
    return Vector3{
        a.x + (b.x - a.x) * t,
        a.y + (b.y - a.y) * t,
        a.z + (b.z - a.z) * t
    };
}
int dem(int num) {
    return (num == 0) ? 1 : (int)pow(10, (int)log10(num) + 1);
}
Vector3 VInt2Vector(VInt3 location, VInt3 forward){
    float demForwardX = dem(forward.X);
    float demForwardY = dem(forward.Y);
    float demForwardZ = dem(forward.Z);
    return Vector3(
        (float)(location.X * demForwardX + forward.X) / (1000 * demForwardX),
        (float)(location.Y * demForwardY + forward.Y) / (1000 * demForwardY),
        (float)(location.Z * demForwardZ + forward.Z) / (1000 * demForwardZ)
    );
}
Vector3 VIntVector(VInt3 location){
    return Vector3((float)(location.X)/(1000), (float)(location.Y)/(1000), (float)(location.Z)/(1000));
}
Vector3 ToEulerRad(Quaternion q1) {
    constexpr float rad2Deg = 360.0 / (M_PI * 2.0); // Đổi tên hằng số để tránh xung đột

    float sqw = q1.w * q1.w;
    float sqx = q1.x * q1.x;
    float sqy = q1.y * q1.y;
    float sqz = q1.z * q1.z;
    float unit = sqx + sqy + sqz + sqw;
    float test = q1.x * q1.w - q1.y * q1.z;
    Vector3 v;

    if (test > 0.4995 * unit) {
        v.y = 2.0 * atan2f(q1.y, q1.x);
        v.x = M_PI / 2.0;
        v.z = 0;
        return NormalizeAngles(v * rad2Deg);
    }
    if (test < -0.4995 * unit) {
        v.y = -2.0 * atan2f(q1.y, q1.x);
        v.x = -M_PI / 2.0;
        v.z = 0;
        return NormalizeAngles(v * rad2Deg);
    }
    Quaternion q(q1.w, q1.z, q1.x, q1.y);
    v.y = atan2f(2.0 * q.x * q.w + 2.0 * q.y * q.z, 1 - 2.0 * (q.z * q.z + q.w * q.w)); // yaw
    v.x = asinf(2.0 * (q.x * q.z - q.w * q.y)); // pitch
    v.z = atan2f(2.0 * q.x * q.y + 2.0 * q.z * q.w, 1 - 2.0 * (q.y * q.y + q.z * q.z)); // roll
    return NormalizeAngles(v * rad2Deg);
}

Quaternion GetRotationToLocation(Vector3 targetLocation, float y_bias, Vector3 myLoc) {
    return Quaternion::LookRotation((targetLocation + Vector3(0, y_bias, 0)) - myLoc, Vector3(0, 1, 0));
}
Vector3 calculateSkillDirection(Vector3 myPosi, Vector3 enemyPosi, Vector3 moveForward, float currentSpeed, float bullettime, float Ranger) {
    Vector3 futureEnemyPos = Vector3::zero();

    Vector3 toEnemy = enemyPosi - myPosi;
    float distanceToEnemy = Vector3::Magnitude(toEnemy);

    float defaultBulletSpeed = Ranger/bullettime;

    float timeToHit = distanceToEnemy/defaultBulletSpeed;

    futureEnemyPos = enemyPosi + moveForward * currentSpeed * timeToHit;
    Vector3 shootingDirection = futureEnemyPos - myPosi;
    return Vector3::Normalized(shootingDirection);
}
Vector3 calculateSkillPosition(Vector3 myPosi, Vector3 enemyPosi, Vector3 moveForward, float currentSpeed, float bullettime, float Ranger) {
    Vector3 futureEnemyPos = Vector3::zero();

    Vector3 toEnemy = enemyPosi - myPosi;
    float distanceToEnemy = Vector3::Magnitude(toEnemy);

    float defaultBulletSpeed = Ranger/bullettime;

    float timeToHit = distanceToEnemy/defaultBulletSpeed;

    futureEnemyPos = enemyPosi + moveForward * currentSpeed * timeToHit;
    return futureEnemyPos;
}
Vector3 CalculateShootingDirection(Vector3 &futureEnemyPos,Vector3 myPos, Vector3 enemyPos, Vector3 enemyDirection, float enemySpeed, float bulletSpeed) {
    Vector3 toEnemy = enemyPos - myPos;
    float distanceToEnemy = Vector3::Magnitude(toEnemy);
    float timeToHit = distanceToEnemy / bulletSpeed;
    futureEnemyPos = enemyPos + enemyDirection * enemySpeed * timeToHit;
    Vector3 shootingDirection = futureEnemyPos - myPos;
    return Vector3::Normalized(shootingDirection);
}
float ClosestDistanceEnemy(Vector3 myPos, Vector3 enemyPos, Vector3 direction) {
    Vector3 AC = enemyPos - myPos;
    Vector3 AB = direction*-1;
    float t = Vector3::Dot(AC, AB);
    Vector3 projectionPoint = myPos + AB * t;
    return Vector3::Distance(projectionPoint, enemyPos);
}